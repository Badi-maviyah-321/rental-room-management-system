
        // Global variables
        let currentUser = null;
        let tenants = JSON.parse(localStorage.getItem('tenants')) || [];
        
        // Function to increment unread count for a section (will be called from rent.html)
        function incrementUnreadCount(section) {
            // This function will be overridden by the one in rent.html
            // We just need it to exist to avoid errors
        }
        let deletedTenants = JSON.parse(localStorage.getItem('deletedTenants')) || [];
        let currentTenantId = null;
        let tenantDataVersion = 0; // Track data version for tenant dashboard updates
        let tenantRefreshInterval = null; // Interval for checking updates

        // Theme management
        const body = document.body;
        let isDark = localStorage.getItem('theme') === 'dark';

        function toggleTheme() {
            isDark = !isDark;
            if (isDark) {
                body.classList.add('dark');
                // Update icons for light mode
                updateThemeIcons(true);
                localStorage.setItem('theme', 'dark');
            } else {
                body.classList.remove('dark');
                // Update icons for dark mode
                updateThemeIcons(false);
                localStorage.setItem('theme', 'light');
            }
        }

        function updateThemeIcons(isDarkMode) {
            const themeToggles = document.querySelectorAll('#themeToggle');
            const iconHtml = isDarkMode ? 
                `<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>` :
                `<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                </svg>`;
                
            themeToggles.forEach(toggle => {
                toggle.innerHTML = iconHtml;
            });
        }

        // Add event listeners to all theme toggle buttons
        document.addEventListener('DOMContentLoaded', function() {
            const themeToggles = document.querySelectorAll('#themeToggle');
            themeToggles.forEach(toggle => {
                toggle.addEventListener('click', toggleTheme);
            });
            
            // Setup password toggle functionality
            setupPasswordToggle();
            
            // Clean up any existing data with encoding issues
            cleanUpEncodingIssues();
                
            // Add some sample data if none exists
            if (!localStorage.getItem('tenants')) {
                const today = new Date().toISOString().split('T')[0];
                const lastMonth = new Date();
                lastMonth.setMonth(lastMonth.getMonth() - 1);
                const lastMonthDate = lastMonth.toISOString().split('T')[0];
                
                // Sample tenant who joined last month (has paid last month, current month pending)
                const sampleTenant1 = {
                    id: generateTenantId(),
                    name: 'John Doe',
                    room: 'A101',
                    rent: 15000,
                    phone: '9876543210',
                    joinDate: lastMonthDate, // Joined last month
                    payments: [
                        {
                            id: 1,
                            type: 'rent',
                            amount: 15000,
                            method: 'cash',
                            notes: 'Last month rent payment',
                            date: lastMonthDate,
                            timestamp: new Date().toISOString()
                        }
                    ],
                    otherBills: [
                        {
                            id: 1001,
                            type: 'electricity',
                            amount: 2500,
                            description: 'Electricity bill for current month',
                            dueDate: today,
                            paid: false,
                            createdDate: today
                        },
                        {
                            id: 1002,
                            type: 'maintenance',
                            amount: 1000,
                            description: 'Monthly maintenance charges',
                            dueDate: today,
                            paid: false,
                            createdDate: today
                        }
                    ],
                    reminderCount: 1,
                    reminderHistory: [],
                    adminActivity: [
                        {
                            id: 101,
                            timestamp: new Date().toISOString(),
                            date: lastMonthDate,
                            time: '10:30:00',
                            action: 'Initial rent payment recorded - ₹15000',
                            type: 'payment',
                            admin: 'admin'
                        },
                        {
                            id: 102,
                            timestamp: new Date().toISOString(),
                            date: today,
                            time: '09:15:00',
                            action: 'Electricity bill added - ₹2500',
                            type: 'bill',
                            admin: 'admin'
                        }
                    ]
                };
                
                // Sample tenant who joined this month (no payments yet)
                const sampleTenant2 = {
                    id: generateTenantId(),
                    name: 'Jane Smith',
                    room: 'A102',
                    rent: 12000,
                    phone: '9876543211',
                    joinDate: today, // Joined this month
                    payments: [],
                    otherBills: [],
                    reminderCount: 0,
                    reminderHistory: [],
                    adminActivity: [
                        {
                            id: 103,
                            timestamp: new Date().toISOString(),
                            date: today,
                            time: '11:45:00',
                            action: 'Tenant added',
                            type: 'tenant',
                            admin: 'admin'
                        }
                    ]
                };
                
                // Sample tenant with current month paid
                const sampleTenant3 = {
                    id: generateTenantId(),
                    name: 'Mike Johnson',
                    room: 'C303',
                    rent: 18000,
                    phone: '9876543212',
                    joinDate: lastMonthDate,
                    payments: [
                        {
                            id: 2,
                            type: 'rent',
                            amount: 18000,
                            method: 'online',
                            notes: 'Last month rent',
                            date: lastMonthDate,
                            timestamp: new Date().toISOString()
                        },
                        {
                            id: 3,
                            type: 'rent',
                            amount: 18000,
                            method: 'online',
                            notes: 'Current month rent',
                            date: today,
                            timestamp: new Date().toISOString()
                        }
                    ],
                    otherBills: [],
                    reminderCount: 0,
                    reminderHistory: [],
                    adminActivity: [
                        {
                            id: 301,
                            timestamp: new Date().toISOString(),
                            date: lastMonthDate,
                            time: '14:20:00',
                            action: 'Last month rent payment recorded - ₹18000',
                            type: 'payment',
                            admin: 'admin'
                        },
                        {
                            id: 302,
                            timestamp: new Date().toISOString(),
                            date: today,
                            time: '08:30:00',
                            action: 'Current month rent payment recorded - ₹18000',
                            type: 'payment',
                            admin: 'admin'
                        }
                    ]
                };
                
                tenants.push(sampleTenant1, sampleTenant2, sampleTenant3);
                localStorage.setItem('tenants', JSON.stringify(tenants));
            } else {
                // Load tenants from localStorage if they already exist
                tenants = JSON.parse(localStorage.getItem('tenants')) || [];
            }
            
            // Set tenant as default user type and show tenant login
            const userTypeSelect = document.getElementById('userType');
            const adminLogin = document.getElementById('adminLogin');
            const tenantLogin = document.getElementById('tenantLogin');
            
            // Set default to tenant
            userTypeSelect.value = 'tenant';
            
            // Show tenant login section by default
            adminLogin.classList.add('hidden');
            tenantLogin.classList.remove('hidden');
            
            // Check for existing session in sessionStorage (tab-specific)
            const session = sessionStorage.getItem('currentUser');
            
            if (session) {
                currentUser = JSON.parse(session);
                document.getElementById('loginScreen').classList.add('hidden');
                
                if (currentUser.type === 'admin') {
                    document.getElementById('adminDashboard').classList.remove('hidden');
                    loadAdminData();
                } else if (currentUser.type === 'tenant') {
                    document.getElementById('tenantDashboard').classList.remove('hidden');
                    loadTenantData();
                    // Start checking for updates every 5 seconds
                    startTenantDataRefresh();
                }
            }
            
            // Trigger staggered animations for login form
            setTimeout(() => {
                const loginForm = document.getElementById('loginForm');
                const loginFormElements = document.getElementById('loginFormElements');
                const adminLogin = document.getElementById('adminLogin');
                const tenantLogin = document.getElementById('tenantLogin');
                
                if (loginForm) {
                    loginForm.classList.add('animate');
                }
                
                if (loginFormElements) {
                    loginFormElements.classList.add('animate');
                }
                
                // Show animations for currently visible login form
                const userType = document.getElementById('userType').value;
                if (userType === 'admin' && adminLogin) {
                    adminLogin.classList.add('animate');
                } else if (tenantLogin) {
                    tenantLogin.classList.add('animate');
                }
            }, 100);
        });

        // Initialize theme
        if (isDark) {
            body.classList.add('dark');
            // Update icons for light mode
            updateThemeIcons(true);
        } else {
            // Update icons for dark mode
            updateThemeIcons(false);
        }

        // Generate unique tenant ID
        function generateTenantId() {
            const now = new Date();
            const year = now.getFullYear();
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const day = String(now.getDate()).padStart(2, '0');
            
            // Find the next sequential number for today
            const datePrefix = `${year}${month}${day}`;
            const existingIds = tenants
                .map(t => t.id)
                .filter(id => id.startsWith(datePrefix))
                .map(id => parseInt(id.slice(-3)))
                .sort((a, b) => b - a);
            
            const nextNumber = existingIds.length > 0 ? existingIds[0] + 1 : 1;
            return `${datePrefix}${String(nextNumber).padStart(3, '0')}`;
        }

        // User type toggle
        document.getElementById('userType').addEventListener('change', function() {
            const adminLogin = document.getElementById('adminLogin');
            const tenantLogin = document.getElementById('tenantLogin');
            
            if (this.value === 'admin') {
                adminLogin.classList.remove('hidden');
                tenantLogin.classList.add('hidden');
                // Trigger animations for admin login form
                setTimeout(() => {
                    adminLogin.classList.add('animate');
                }, 100);
            } else {
                adminLogin.classList.add('hidden');
                tenantLogin.classList.remove('hidden');
                // Trigger animations for tenant login form
                setTimeout(() => {
                    tenantLogin.classList.add('animate');
                }, 100);
            }
        });

        // Password toggle functionality
        function setupPasswordToggle() {
            const togglePassword = document.getElementById('togglePassword');
            const adminPassword = document.getElementById('adminPassword');
            
            if (togglePassword && adminPassword) {
                togglePassword.addEventListener('click', function() {
                    // Toggle the type attribute
                    const type = adminPassword.getAttribute('type') === 'password' ? 'text' : 'password';
                    adminPassword.setAttribute('type', type);
                    
                    // Toggle the eye icon
                    if (type === 'password') {
                        // Show password - display eye slash icon
                        this.innerHTML = `
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21" />
                            </svg>
                        `;
                    } else {
                        // Hide password - display eye icon
                        this.innerHTML = `
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        `;
                    }
                });
            }
        }

        // Login function
        function login() {
            const userType = document.getElementById('userType').value;
            
            if (userType === 'admin') {
                const username = document.getElementById('adminUsername').value;
                const password = document.getElementById('adminPassword').value;
                
                if (username === 'admin' && password === 'admin123') {
                    currentUser = { type: 'admin', username: 'admin' };
                    // Store admin session in sessionStorage (tab-specific)
                    sessionStorage.setItem('currentUser', JSON.stringify(currentUser));
                    showDashboard('admin');
                } else {
                    customAlert('Invalid admin credentials!', 'Login Error');
                }
            } else {
                const tenantId = document.getElementById('tenantId').value;
                const tenant = tenants.find(t => t.id === tenantId);
                
                if (tenant) {
                    currentUser = { type: 'tenant', data: tenant };
                    // Store tenant session in sessionStorage (tab-specific)
                    sessionStorage.setItem('currentUser', JSON.stringify(currentUser));
                    // Initialize tenant data version for tracking changes
                    tenantDataVersion = JSON.stringify(tenant).split('').reduce((a,b) => (((a << 5) - a) + b.charCodeAt(0))|0, 0);
                    showDashboard('tenant');
                } else {
                    customAlert('Invalid tenant ID!', 'Login Error');
                }
            }
        }

        // Show dashboard
        function showDashboard(type) {
            document.getElementById('loginScreen').classList.add('hidden');
            
            if (type === 'admin') {
                document.getElementById('adminDashboard').classList.remove('hidden');
                loadAdminData();
                
                // Trigger animations for admin dashboard
                setTimeout(() => {
                    const adminNavButtons = document.getElementById('adminNavButtons');
                    const reportsGrid = document.getElementById('reportsGrid');
                    
                    if (adminNavButtons) {
                        adminNavButtons.classList.add('animate');
                    }
                    
                    if (reportsGrid) {
                        reportsGrid.classList.add('animate');
                    }
                }, 100);
            } else {
                document.getElementById('tenantDashboard').classList.remove('hidden');
                loadTenantData();
                // Start checking for updates every 5 seconds
                startTenantDataRefresh();
            }
        }

        // Start checking for tenant data updates
        function startTenantDataRefresh() {
            // Clear any existing interval
            if (tenantRefreshInterval) {
                clearInterval(tenantRefreshInterval);
            }
            
            // Set up interval to check for updates
            tenantRefreshInterval = setInterval(checkForTenantDataUpdates, 5000); // Check every 5 seconds
        }

        // Stop checking for tenant data updates
        function stopTenantDataRefresh() {
            if (tenantRefreshInterval) {
                clearInterval(tenantRefreshInterval);
                tenantRefreshInterval = null;
            }
        }

        // Check for tenant data updates
        function checkForTenantDataUpdates() {
            // Only check if we're on the tenant dashboard
            if (currentUser && currentUser.type === 'tenant' && 
                !document.getElementById('tenantDashboard').classList.contains('hidden')) {
                
                // Get current data version from localStorage
                const currentTenants = JSON.parse(localStorage.getItem('tenants')) || [];
                const tenant = currentTenants.find(t => t.id === currentUser.data.id);
                
                if (tenant) {
                    // Create a simple hash of the tenant data to detect changes
                    const newDataVersion = JSON.stringify(tenant).split('').reduce((a,b) => (((a << 5) - a) + b.charCodeAt(0))|0, 0);
                    
                    // If data has changed, refresh the dashboard
                    if (newDataVersion !== tenantDataVersion) {
                        tenantDataVersion = newDataVersion;
                        currentUser.data = tenant; // Update current user data
                        loadTenantData(); // Refresh the tenant dashboard
                        
                        // Show a subtle notification that data was updated
                        showDataUpdateNotification();
                    }
                }
            }
        }

        // Automatically update tenant dashboard for bill changes
        function updateTenantDashboardForBills(tenantId) {
            // Check if this tenant is currently logged in
            if (currentUser && currentUser.type === 'tenant' && currentUser.data.id === tenantId) {
                // Update the current user data
                const updatedTenant = tenants.find(t => t.id === tenantId);
                if (updatedTenant) {
                    currentUser.data = updatedTenant;
                    // Update the tenant dashboard display
                    loadTenantData();
                }
            }
            
            // Also update the admin dashboard tenant list if it's visible
            if (document.getElementById('adminDashboard') && !document.getElementById('adminDashboard').classList.contains('hidden')) {
                loadTenants();
            }
        }

        // Show data update notification
        function showDataUpdateNotification(message = 'Data updated') {
            // Remove any existing notification
            const existingNotification = document.getElementById('dataUpdateNotification');
            if (existingNotification) {
                existingNotification.remove();
            }
            
            // Create notification element
            const notification = document.createElement('div');
            notification.id = 'dataUpdateNotification';
            notification.className = 'fixed top-4 right-4 bg-primary text-white px-4 py-2 rounded-lg shadow-lg z-60';
            notification.innerHTML = `
                <div class="flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span>${message}</span>
                </div>
            `;
            
            // Add to document
            document.body.appendChild(notification);
            
            // Remove after 3 seconds
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 3000);
        }

        // Custom alert function
        function customAlert(message, title = 'Information') {
            const alertModal = document.getElementById('customAlertModal');
            const alertTitle = document.getElementById('customAlertTitle');
            const alertMessage = document.getElementById('customAlertMessage');
            
            if (alertModal && alertTitle && alertMessage) {
                alertTitle.textContent = title;
                alertMessage.textContent = message;
                alertModal.classList.remove('hidden');
            } else {
                // Fallback to browser alert if elements not found
                alert(`${title}: ${message}`);
            }
        }

        // Logout function
        function logout() {
            // Clear the session from sessionStorage
            sessionStorage.removeItem('currentUser');
            
            currentUser = null;
            document.getElementById('adminDashboard').classList.add('hidden');
            document.getElementById('tenantDashboard').classList.add('hidden');
            document.getElementById('loginScreen').classList.remove('hidden');
            
            // Stop tenant data refresh if it was running
            stopTenantDataRefresh();
            
            // Clear form fields
            document.getElementById('adminUsername').value = '';
            document.getElementById('adminPassword').value = '';
            document.getElementById('tenantId').value = '';
        }

        // Admin section navigation
        function showAdminSection(section, event) {
            // Hide all sections
            document.querySelectorAll('.admin-section').forEach(s => s.classList.add('hidden'));
            
            // Show selected section
            const sectionElement = document.getElementById(`admin${section.charAt(0).toUpperCase() + section.slice(1)}`);
            sectionElement.classList.remove('hidden');
            
            // Update navigation
            document.querySelectorAll('.admin-nav-btn').forEach(btn => {
                btn.classList.remove('border-primary', 'text-primary');
                btn.classList.add('border-transparent', 'text-gray-500');
                btn.classList.add('dark:text-gray-300');
            });
            
            if (event && event.target) {
                event.target.classList.remove('border-transparent', 'text-gray-500', 'dark:text-gray-300');
                event.target.classList.add('border-primary', 'text-primary');
            }
            
            // Trigger animations for the section
            setTimeout(() => {
                sectionElement.classList.add('animate');
                
                // For specific sections, trigger child animations
                if (section === 'reports') {
                    const reportsGrid = document.getElementById('reportsGrid');
                    if (reportsGrid) {
                        reportsGrid.classList.add('animate');
                    }
                }
            }, 100);
            
            // Load section-specific data
            if (section === 'reports') {
                updateReportsData();
            } else if (section === 'reminders') {
                loadReminders();
            } else if (section === 'deleted') {
                loadDeletedTenants();
            }
        }

        // Load admin data
        function loadAdminData() {
            // Always fetch the latest data from localStorage
            tenants = JSON.parse(localStorage.getItem('tenants')) || [];
            deletedTenants = JSON.parse(localStorage.getItem('deletedTenants')) || [];
            
            loadTenants();
            updateReportsData();
        }

        // Load tenants table
        function loadTenants(searchTerm = '') {
            // Always fetch the latest data from localStorage
            tenants = JSON.parse(localStorage.getItem('tenants')) || [];
            
            const tbody = document.getElementById('tenantsTable');
            tbody.innerHTML = '';
            
            // Filter tenants based on search term
            let filteredTenants = tenants;
            if (searchTerm) {
                filteredTenants = tenants.filter(tenant => 
                    tenant.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    tenant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    tenant.room.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    (tenant.phone && tenant.phone.includes(searchTerm))
                );
            }
            
            filteredTenants.forEach(tenant => {
                const row = document.createElement('tr');
                row.className = 'hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors';
                const dueAmount = calculateDueAmount(tenant);
                const isOverdue = tenant.reminderCount >= 3;
                
                // Check if tenant is new (joined this month)
                const currentDate = new Date();
                const joinDate = new Date(tenant.joinDate);
                const isNewTenant = (currentDate.getFullYear() === joinDate.getFullYear() && 
                                   currentDate.getMonth() === joinDate.getMonth());
                
                // Check if current month rent is paid
                const currMonth = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;
                const currMonthPayment = tenant.payments?.find(p => 
                    p.date.startsWith(currMonth) && p.type === 'rent'
                );
                const isCurrMonthPaid = !!currMonthPayment;
                
                let statusBadge, statusText;
                if (isNewTenant && !isCurrMonthPaid) {
                    // New tenants without payment should show as PENDING
                    statusBadge = 'bg-yellow-300 text-gray-900 dark:bg-yellow-700/30 dark:text-yellow-300';
                    statusText = '<span style="color: #111827; font-weight: bold;">⚠️ PENDING</span>';
                } else if (dueAmount > 0) {
                    if (isOverdue) {
                        statusBadge = 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
                        statusText = '🚨 OVERDUE';
                    } else {
                        statusBadge = 'bg-yellow-300 text-gray-900 dark:bg-yellow-700/30 dark:text-yellow-300';
                        statusText = '<span style="color: #111827; font-weight: bold;">⚠️ PENDING</span>';
                    }
                } else {
                    statusBadge = 'bg-primary/10 text-primary dark:bg-primary-dark/20 dark:text-primary';
                    statusText = '✅ PAID';
                }
                
                const otherBillsCount = tenant.otherBills ? tenant.otherBills.filter(b => !b.paid).length : 0;
                const otherBillsAmount = tenant.otherBills ? tenant.otherBills.filter(b => !b.paid).reduce((sum, b) => sum + b.amount, 0) : 0;
                
                // Check if current month rent is paid
                const now = new Date();
                const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
                const currentMonthPayment = tenant.payments?.find(p => 
                    p.date.startsWith(currentMonth) && p.type === 'rent'
                );
                const isCurrentMonthPaid = !!currentMonthPayment;
                
                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap">
                        <input type="checkbox" class="tenant-checkbox h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500" data-tenant-id="${tenant.id}">
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="flex items-center">
                            <div class="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mr-3 cursor-pointer tenant-profile-icon" onclick="showTenantProfile('${tenant.id}')">
                                <span class="text-blue-600 dark:text-blue-400 text-xs">👤</span>
                            </div>
                            <div>
                                <div class="text-sm font-medium text-gray-900 dark:text-white cursor-pointer" onclick="showTenantProfile('${tenant.id}')">${tenant.id}</div>
                                <div class="text-xs text-gray-500 dark:text-gray-400">Since ${tenant.joinDate}</div>
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm font-medium text-gray-900 dark:text-white">${tenant.name}</div>
                        <div class="text-xs text-gray-500 dark:text-gray-400">${tenant.phone}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm font-medium text-gray-900 dark:text-white">${tenant.room}</div>
                        <div class="text-xs text-gray-500 dark:text-gray-400">₹${tenant.rent}/month</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="status-badge ${statusBadge}">${statusText}</span>
                        ${tenant.reminderCount ? `<div class="text-xs text-gray-500 dark:text-gray-400 mt-1">Reminders: ${tenant.reminderCount}/3</div>` : ''}
                        ${isCurrentMonthPaid ? `<div class="text-xs text-primary dark:text-primary mt-1">Paid on: ${currentMonthPayment.date}</div>` : ''}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm font-bold ${dueAmount > 0 ? 'text-red-600 dark:text-red-400' : 'text-primary dark:text-primary'}">
                            ${dueAmount > 0 ? `₹${dueAmount}` : '₹0'}
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm">
                            ${otherBillsCount > 0 ? 
                                `<div class="text-orange-600 dark:text-orange-400 font-medium">${otherBillsCount} Bills</div>
                                 <div class="text-xs text-orange-500 dark:text-orange-300">₹${otherBillsAmount}</div>` : 
                                `<div class="text-gray-500 dark:text-gray-400">No Bills</div>`
                            }
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div class="flex space-x-2">
                            <button onclick="updatePayment('${tenant.id}')" class="bg-primary/10 hover:bg-primary/20 dark:bg-primary-dark/20 dark:hover:bg-primary-dark/40 text-primary dark:text-primary px-3 py-1 rounded-full text-xs transition-colors" style="color: #005a8a;">
                                💰 Payment
                            </button>
                            ${isCurrentMonthPaid ? 
                                `<button onclick="markAsUnpaid('${tenant.id}')" class="bg-orange-100 hover:bg-orange-200 dark:bg-orange-900/20 dark:hover:bg-orange-900/40 text-orange-700 dark:text-orange-400 px-3 py-1 rounded-full text-xs transition-colors" style="color: #c2410c;">
                                    🔁 Unpaid
                                </button>` : ''}
                            <button onclick="deleteTenant('${tenant.id}')" class="bg-red-100 hover:bg-red-200 dark:bg-red-900/20 dark:hover:bg-red-900/40 text-red-700 dark:text-red-400 px-3 py-1 rounded-full text-xs transition-colors" style="color: #dc2626;">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 inline mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                                Delete
                            </button>
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });
            
            // Add event listeners for checkboxes
            setTimeout(() => {
                setupTenantCheckboxEventListeners();
            }, 0);
        }

        // Permanently delete tenant
        function permanentlyDeleteTenant(tenantId) {
            // Use the HTML version of customConfirm explicitly
            if (typeof customConfirm !== 'undefined' && document.getElementById('customConfirmModal')) {
                customConfirm('Are you sure you want to permanently delete this tenant? This action cannot be undone.', 'Confirm Permanent Delete', function() {
                    deletedTenants = deletedTenants.filter(t => t.id !== tenantId);
                    localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
                    loadDeletedTenants();
                    customAlert('Tenant permanently deleted!', 'Success');
                });
            } else {
                // Fallback to the app.js version if HTML version is not available
                customConfirm('Are you sure you want to permanently delete this tenant? This action cannot be undone.', 'Confirm Permanent Delete', function() {
                    deletedTenants = deletedTenants.filter(t => t.id !== tenantId);
                    localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
                    loadDeletedTenants();
                    customAlert('Tenant permanently deleted!', 'Success');
                });
            }
        }
        
        // Set up event listeners for tenant checkboxes
        function setupTenantCheckboxEventListeners() {
            // Select All checkbox
            const selectAllCheckbox = document.getElementById('selectAllCheckbox');
            const tenantCheckboxes = document.querySelectorAll('.tenant-checkbox');
            const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
            
            // Remove any existing event listeners to prevent duplicates
            if (selectAllCheckbox) {
                selectAllCheckbox.removeEventListener('change', handleSelectAllChange);
                selectAllCheckbox.addEventListener('change', handleSelectAllChange);
            }
            
            // Remove any existing event listeners from individual checkboxes
            tenantCheckboxes.forEach(checkbox => {
                checkbox.removeEventListener('change', handleTenantCheckboxChange);
                checkbox.addEventListener('change', handleTenantCheckboxChange);
            });
            
            // Bulk delete button
            if (bulkDeleteBtn) {
                bulkDeleteBtn.removeEventListener('click', bulkDeleteTenants);
                bulkDeleteBtn.addEventListener('click', bulkDeleteTenants);
            }
        }
        
        // Handle Select All checkbox change
        function handleSelectAllChange(event) {
            const tenantCheckboxes = document.querySelectorAll('.tenant-checkbox');
            
            tenantCheckboxes.forEach(checkbox => {
                checkbox.checked = event.target.checked;
            });
            
            // Reset indeterminate state when user explicitly checks/unchecks select all
            event.target.indeterminate = false;
            toggleBulkDeleteButton();
        }
        
        // Handle individual tenant checkbox change
        function handleTenantCheckboxChange() {
            const selectAllCheckbox = document.getElementById('selectAllCheckbox');
            const tenantCheckboxes = document.querySelectorAll('.tenant-checkbox');
            
            // Update select all checkbox state
            if (selectAllCheckbox) {
                const allChecked = Array.from(tenantCheckboxes).every(cb => cb.checked);
                const anyChecked = Array.from(tenantCheckboxes).some(cb => cb.checked);
                selectAllCheckbox.checked = allChecked;
                // Set indeterminate state when some but not all checkboxes are checked
                selectAllCheckbox.indeterminate = !allChecked && anyChecked;
            }
            
            toggleBulkDeleteButton();
        }
        
        // Handle select all for active tenants
        function handleSelectAll(isChecked) {
            const tenantCheckboxes = document.querySelectorAll('.tenant-checkbox');
            tenantCheckboxes.forEach(checkbox => {
                checkbox.checked = isChecked;
            });
            toggleBulkDeleteButton();
        }

        // Handle select all for deleted tenants
        function handleSelectAllDeleted(isChecked) {
            const deletedTenantCheckboxes = document.querySelectorAll('.deleted-tenant-checkbox');
            deletedTenantCheckboxes.forEach(checkbox => {
                checkbox.checked = isChecked;
            });
            toggleBulkDeletedButtons();
        }
        
        // Toggle bulk delete button visibility
        function toggleBulkDeleteButton() {
            const tenantCheckboxes = document.querySelectorAll('.tenant-checkbox');
            const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
            
            if (bulkDeleteBtn) {
                const anyChecked = Array.from(tenantCheckboxes).some(cb => cb.checked);
                bulkDeleteBtn.classList.toggle('hidden', !anyChecked);
            }
        }
        
        // Bulk delete tenants
        function bulkDeleteTenants() {
            const tenantCheckboxes = document.querySelectorAll('.tenant-checkbox:checked');
            const tenantIds = Array.from(tenantCheckboxes).map(cb => cb.dataset.tenantId);
            
            if (tenantIds.length === 0) {
                customAlert('Please select at least one tenant to delete.', 'No Tenants Selected');
                return;
            }
            
            // Use the HTML version of customConfirm explicitly
            if (typeof customConfirm !== 'undefined' && document.getElementById('customConfirmModal')) {
                customConfirm(`Are you sure you want to delete ${tenantIds.length} tenant(s)? This action cannot be undone.`, 'Confirm Bulk Delete', function() {
                    tenantIds.forEach(tenantId => {
                        const tenant = tenants.find(t => t.id === tenantId);
                        if (tenant) {
                            // Create a deep copy of the tenant object to avoid reference issues
                            const tenantCopy = JSON.parse(JSON.stringify(tenant));
                            tenantCopy.deletedDate = new Date().toISOString().split('T')[0];
                            
                            deletedTenants.push(tenantCopy);
                            tenants = tenants.filter(t => t.id !== tenantId);
                            
                            // Log admin activity
                            logAdminActivity(tenantId, `Tenant deleted by admin`, 'tenant_deletion');
                            
                            // Notify tenant of deletion with specific information
                            notifyTenantOfUpdate(tenant, `Your tenant profile has been deleted by admin. Tenant ID: ${tenant.id}, Name: ${tenant.name}`);
                        }
                    });
                    
                    localStorage.setItem('tenants', JSON.stringify(tenants));
                    localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
                    
                    loadTenants();
                    customAlert(`${tenantIds.length} tenant(s) deleted successfully!`, 'Success');
                    
                    // Reset select all checkbox
                    const selectAllCheckbox = document.getElementById('selectAllCheckbox');
                    if (selectAllCheckbox) {
                        selectAllCheckbox.checked = false;
                        selectAllCheckbox.indeterminate = false;
                    }
                    
                    toggleBulkDeleteButton();
                });
            } else {
                // Fallback to the app.js version if HTML version is not available
                customConfirm(`Are you sure you want to delete ${tenantIds.length} tenant(s)? This action cannot be undone.`, 'Confirm Bulk Delete', function() {
                    tenantIds.forEach(tenantId => {
                        const tenant = tenants.find(t => t.id === tenantId);
                        if (tenant) {
                            // Create a deep copy of the tenant object to avoid reference issues
                            const tenantCopy = JSON.parse(JSON.stringify(tenant));
                            tenantCopy.deletedDate = new Date().toISOString().split('T')[0];
                            
                            deletedTenants.push(tenantCopy);
                            tenants = tenants.filter(t => t.id !== tenantId);
                            
                            // Log admin activity
                            logAdminActivity(tenantId, `Tenant deleted by admin`, 'tenant_deletion');
                            
                            // Notify tenant of deletion with specific information
                            notifyTenantOfUpdate(tenant, `Your tenant profile has been deleted by admin. Tenant ID: ${tenant.id}, Name: ${tenant.name}`);
                        }
                    });
                    
                    localStorage.setItem('tenants', JSON.stringify(tenants));
                    localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
                    
                    loadTenants();
                    customAlert(`${tenantIds.length} tenant(s) deleted successfully!`, 'Success');
                    
                    // Reset select all checkbox
                    const selectAllCheckbox = document.getElementById('selectAllCheckbox');
                    if (selectAllCheckbox) {
                        selectAllCheckbox.checked = false;
                        selectAllCheckbox.indeterminate = false;
                    }
                    
                    toggleBulkDeleteButton();
                });
            }
        }

        // Calculate due amount
        function calculateDueAmount(tenant) {
            const now = new Date();
            const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
            const joinDate = new Date(tenant.joinDate);
            
            let totalDue = 0;
            
            // Calculate months since joining
            const monthsSinceJoin = (now.getFullYear() - joinDate.getFullYear()) * 12 + 
                                   (now.getMonth() - joinDate.getMonth());
            
            // Only calculate rent if tenant has been here for more than current month
            // New tenants who joined this month should not be charged for the current month
            const shouldCalculateRent = monthsSinceJoin > 0;
            
            if (!shouldCalculateRent) {
                // New tenant - no rent due yet
                return 0;
            }
            
            // Check current month rent (only if rent should be calculated)
            if (shouldCalculateRent) {
                const currentMonthPayment = tenant.payments?.find(p => 
                    p.date.startsWith(currentMonth) && p.type === 'rent'
                );
                
                if (!currentMonthPayment) {
                    totalDue += tenant.rent;
                }
            }
            
            // Check all previous months since joining (excluding join month if joined this month)
            if (monthsSinceJoin > 0) {
                for (let i = 1; i <= monthsSinceJoin; i++) {
                    const checkDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
                    const checkMonth = `${checkDate.getFullYear()}-${String(checkDate.getMonth() + 1).padStart(2, '0')}`;
                    
                    // Only check months after join date
                    if (checkDate >= new Date(joinDate.getFullYear(), joinDate.getMonth(), 1)) {
                        const monthPayment = tenant.payments?.find(p => 
                            p.date.startsWith(checkMonth) && p.type === 'rent'
                        );
                        
                        if (!monthPayment) {
                            totalDue += tenant.rent;
                        }
                    }
                }
            }
            
            // Add other pending bills
            if (tenant.otherBills) {
                tenant.otherBills.forEach(bill => {
                    if (!bill.paid) {
                        totalDue += bill.amount;
                    }
                });
            }
            
            return totalDue;
        }

        // Update dashboard statistics
        function updateDashboardStats() {
            // Total tenants
            const totalTenants = tenants.length;
            document.getElementById('dashboardTotalTenants').textContent = totalTenants;
            
            // Monthly revenue (current month payments)
            const now = new Date();
            const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
            let monthlyRevenue = 0;
            
            tenants.forEach(tenant => {
                if (tenant.payments) {
                    tenant.payments.forEach(payment => {
                        if (payment.date.startsWith(currentMonth) && payment.type === 'rent') {
                            monthlyRevenue += payment.amount;
                        }
                    });
                }
            });
            
            document.getElementById('dashboardMonthlyRevenue').textContent = `₹${monthlyRevenue.toLocaleString()}`;
            
            // Pending payments (total due amount)
            let pendingPayments = 0;
            tenants.forEach(tenant => {
                pendingPayments += calculateDueAmount(tenant);
            });
            
            document.getElementById('dashboardPendingPayments').textContent = `₹${pendingPayments.toLocaleString()}`;
            
            // Overdue tenants (those with 3 reminders)
            const overdueTenants = tenants.filter(tenant => tenant.reminderCount >= 3).length;
            document.getElementById('dashboardOverdueTenants').textContent = overdueTenants;
        }

        // Load recent payments
        function loadRecentPayments() {
            const paymentHistoryDiv = document.getElementById('dashboardPaymentHistory');
            
            // Collect all payments with tenant info
            let allPayments = [];
            tenants.forEach(tenant => {
                if (tenant.payments && tenant.payments.length > 0) {
                    tenant.payments.forEach(payment => {
                        allPayments.push({
                            tenantId: tenant.id,
                            tenantName: tenant.name,
                            ...payment
                        });
                    });
                }
            });
            
            // Sort by date (newest first)
            allPayments.sort((a, b) => new Date(b.date) - new Date(a.date));
            
            // Take only the 10 most recent payments
            const recentPayments = allPayments.slice(0, 10);
            
            if (recentPayments.length === 0) {
                paymentHistoryDiv.innerHTML = `
                    <div class="text-center py-8 text-gray-500 dark:text-gray-400">
                        <p>No payment history yet</p>
                    </div>
                `;
                return;
            }
            
            // Generate HTML for recent payments
            let paymentsHTML = '';
            recentPayments.forEach(payment => {
                const paymentDate = new Date(payment.date).toLocaleDateString();
                paymentsHTML += `
                    <div class="border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 rounded-lg p-3 mb-3 card-hover">
                        <div class="flex justify-between items-center">
                            <div>
                                <div class="flex items-center space-x-2">
                                    <span class="w-2 h-2 bg-primary rounded-full"></span>
                                    <p class="font-medium text-gray-900 dark:text-white">${payment.type.charAt(0).toUpperCase() + payment.type.slice(1)}</p>
                                </div>
                                <p class="text-sm text-gray-600 dark:text-gray-300">${paymentDate}</p>
                                <p class="text-xs text-gray-500 dark:text-gray-400">${payment.tenantName} (${payment.tenantId})</p>
                                ${payment.notes ? `<p class="text-sm text-gray-500 dark:text-gray-400">${payment.notes}</p>` : ''}
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-primary dark:text-primary">₹${payment.amount.toLocaleString()}</p>
                                <p class="text-sm text-gray-500 dark:text-gray-400">${payment.method}</p>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            paymentHistoryDiv.innerHTML = paymentsHTML;
        }

        // Load recent notifications
        function loadRecentNotifications() {
            const notificationsDiv = document.getElementById('dashboardNotifications');
            
            // Collect all notifications
            let allNotifications = [];
            tenants.forEach(tenant => {
                if (tenant.notifications && tenant.notifications.length > 0) {
                    tenant.notifications.forEach(notification => {
                        allNotifications.push({
                            tenantId: tenant.id,
                            tenantName: tenant.name,
                            ...notification
                        });
                    });
                }
            });
            
            // Sort by date (newest first)
            allNotifications.sort((a, b) => {
                const dateA = new Date(`${a.date} ${a.time}`);
                const dateB = new Date(`${b.date} ${b.time}`);
                return dateB - dateA;
            });
            
            // Take only the 10 most recent notifications
            const recentNotifications = allNotifications.slice(0, 10);
            
            if (recentNotifications.length === 0) {
                notificationsDiv.innerHTML = `
                    <div class="text-center py-8 text-gray-500 dark:text-gray-400">
                        <p>No notifications yet</p>
                    </div>
                `;
                return;
            }
            
            // Generate HTML for recent notifications
            let notificationsHTML = '';
            recentNotifications.forEach(notification => {
                notificationsHTML += `
                    <div class="border border-purple-400 dark:border-purple-500 bg-purple-200 dark:bg-purple-800/40 rounded-lg p-3 mb-3">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="font-medium text-purple-950 dark:text-purple-50">${notification.message}</p>
                                <p class="text-xs text-purple-800 dark:text-purple-100">${notification.date} at ${notification.time}</p>
                                <p class="text-xs text-purple-700 dark:text-purple-200">${notification.tenantName} (${notification.tenantId})</p>
                            </div>
                            <span class="text-purple-800 dark:text-purple-100 font-bold">🔔</span>
                        </div>
                    </div>
                `;
            });
            
            notificationsDiv.innerHTML = notificationsHTML;
        }

        // Load recent admin activities
        function loadRecentAdminActivities() {
            const activitiesDiv = document.getElementById('dashboardAdminActivities');
            
            // Collect all admin activities
            let allActivities = [];
            tenants.forEach(tenant => {
                if (tenant.adminActivity && tenant.adminActivity.length > 0) {
                    tenant.adminActivity.forEach(activity => {
                        allActivities.push({
                            tenantId: tenant.id,
                            tenantName: tenant.name,
                            ...activity
                        });
                    });
                }
            });
            
            // Sort by date (newest first)
            allActivities.sort((a, b) => {
                const dateA = new Date(`${a.date} ${a.time}`);
                const dateB = new Date(`${b.date} ${b.time}`);
                return dateB - dateA;
            });
            
            // Take only the 10 most recent activities
            const recentActivities = allActivities.slice(0, 10);
            
            if (recentActivities.length === 0) {
                activitiesDiv.innerHTML = `
                    <div class="text-center py-8 text-gray-500 dark:text-gray-400">
                        <p>No admin activities yet</p>
                    </div>
                `;
                return;
            }
            
            // Generate HTML for recent activities
            let activitiesHTML = '';
            recentActivities.forEach(activity => {
                const icon = activity.type === 'payment' ? '💰' : 
                             activity.type === 'bill' ? '📋' : 
                             activity.type === 'reversal' ? '↩️' : '📋';
                
                activitiesHTML += `
                    <div class="border border-blue-400 dark:border-blue-500 bg-blue-200 dark:bg-blue-800/40 rounded-lg p-3 mb-3">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="font-medium text-blue-950 dark:text-blue-50">${activity.action}</p>
                                <p class="text-xs text-blue-800 dark:text-blue-100">${activity.date} at ${activity.time}</p>
                                <p class="text-xs text-blue-700 dark:text-blue-200">${activity.tenantName} (${activity.tenantId})</p>
                            </div>
                            <span class="text-blue-800 dark:text-blue-100 font-bold">${icon}</span>
                        </div>
                    </div>
                `;
            });
            
            activitiesDiv.innerHTML = activitiesHTML;
        }

        // Get list of unpaid months
        function getUnpaidMonths(tenant) {
            const now = new Date();
            const joinDate = new Date(tenant.joinDate);
            const unpaidMonths = [];
            
            // Calculate months since joining
            const monthsSinceJoin = (now.getFullYear() - joinDate.getFullYear()) * 12 + 
                                   (now.getMonth() - joinDate.getMonth());
            
            // Only calculate rent if tenant has been here for more than current month
            // New tenants who joined this month should not be charged for the current month
            const shouldCalculateRent = monthsSinceJoin > 0;
            
            if (!shouldCalculateRent) {
                // New tenant - no unpaid months yet
                return [];
            }
            
            // Check current month rent (only if rent should be calculated)
            if (shouldCalculateRent) {
                const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
                const currentMonthPayment = tenant.payments?.find(p => 
                    p.date.startsWith(currentMonth) && p.type === 'rent'
                );
                
                if (!currentMonthPayment) {
                    unpaidMonths.push(currentMonth);
                }
            }
            
            // Check all previous months since joining (excluding join month if joined this month)
            if (monthsSinceJoin > 0) {
                for (let i = 1; i <= monthsSinceJoin; i++) {
                    const checkDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
                    const checkMonth = `${checkDate.getFullYear()}-${String(checkDate.getMonth() + 1).padStart(2, '0')}`;
                    
                    // Only check months after join date
                    if (checkDate >= new Date(joinDate.getFullYear(), joinDate.getMonth(), 1)) {
                        const monthPayment = tenant.payments?.find(p => 
                            p.date.startsWith(checkMonth) && p.type === 'rent'
                        );
                        
                        if (!monthPayment) {
                            unpaidMonths.push(checkMonth);
                        }
                    }
                }
            }
            
            return unpaidMonths;
        }

        // Show add tenant modal
        function showAddTenantModal() {
            document.getElementById('addTenantModal').classList.remove('hidden');
        }



        // Load reminders table
        function loadReminders() {
            const tbody = document.getElementById('remindersTable');
            tbody.innerHTML = '';
            
            if (reminders.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" class="px-6 py-4 text-center text-gray-500">No reminders found</td></tr>';
                return;
            }
            
            reminders.forEach(reminder => {
                const row = document.createElement('tr');
                row.className = 'hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors';
                
                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                        ${reminder.tenantId}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                        ${reminder.name}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                        ${reminder.room}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button onclick="sendReminder('${reminder.tenantId}')" class="bg-blue-100 hover:bg-blue-200 dark:bg-blue-900/20 dark:hover:bg-blue-900/40 text-blue-700 dark:text-blue-400 px-3 py-1 rounded-full text-xs transition-colors">
                            🔔 Send Reminder
                        </button>
                        <button onclick="deleteReminder('${reminder.tenantId}')" class="bg-red-100 hover:bg-red-200 dark:bg-red-900/20 dark:hover:bg-red-900/40 text-red-700 dark:text-red-400 px-3 py-1 rounded-full text-xs transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 inline mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                            Delete
                        </button>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }

        // Load deleted tenants table
        function loadDeletedTenants() {
            const tbody = document.getElementById('deletedTenantsTable');
            tbody.innerHTML = '';
            
            if (deletedTenants.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="px-6 py-4 text-center text-gray-500">No deleted tenants found</td></tr>';
                return;
            }
            
            deletedTenants.forEach(tenant => {
                const row = document.createElement('tr');
                row.className = 'hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors';
                
                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap">
                        <input type="checkbox" class="deleted-tenant-checkbox h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500" data-tenant-id="${tenant.id}">
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="flex items-center">
                            <div class="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mr-3 cursor-pointer deleted-tenant-profile-icon">
                                <span class="text-blue-600 dark:text-blue-400 text-xs">👤</span>
                            </div>
                            <div>
                                <div class="text-sm font-medium text-gray-900 dark:text-white">${tenant.id}</div>
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                        ${tenant.name}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                        ${tenant.room}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                        ${tenant.deletedDate || 'N/A'}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button onclick="downloadDeletedTenantReport('${tenant.id}')" class="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-3">
                            📄 Download
                        </button>
                        <button onclick="restoreTenant('${tenant.id}')" class="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-3">
                            🔄 Restore
                        </button>
                        <button onclick="permanentlyDeleteTenant('${tenant.id}')" class="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 inline mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                            Delete Permanently
                        </button>
                    </td>
                `;
                tbody.appendChild(row);
            });
            
            // Add event listeners for deleted tenant checkboxes
            setTimeout(() => {
                setupDeletedTenantCheckboxEventListeners();
            }, 0);
        }

        // Add event listeners for deleted tenant checkboxes
        function addDeletedCheckboxEventListeners() {
            // Select All checkbox for deleted tenants
            const selectAllDeletedCheckbox = document.getElementById('selectAllDeletedCheckbox');
            const deletedTenantCheckboxes = document.querySelectorAll('.deleted-tenant-checkbox');
            const bulkRestoreBtn = document.getElementById('bulkRestoreBtn');
            const bulkPermanentDeleteBtn = document.getElementById('bulkPermanentDeleteBtn');
            
            if (selectAllDeletedCheckbox) {
                selectAllDeletedCheckbox.addEventListener('change', function() {
                    deletedTenantCheckboxes.forEach(checkbox => {
                        checkbox.checked = this.checked;
                    });
                    toggleBulkDeletedButtons();
                });
            }
            
            // Individual checkboxes for deleted tenants
            deletedTenantCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    // Update select all checkbox state
                    if (selectAllDeletedCheckbox) {
                        const allChecked = Array.from(deletedTenantCheckboxes).every(cb => cb.checked);
                        selectAllDeletedCheckbox.checked = allChecked;
                        selectAllDeletedCheckbox.indeterminate = !allChecked && Array.from(deletedTenantCheckboxes).some(cb => cb.checked);
                    }
                    toggleBulkDeletedButtons();
                });
            });
            
            // Bulk restore button
            if (bulkRestoreBtn) {
                bulkRestoreBtn.addEventListener('click', bulkRestoreTenants);
            }
            
            // Bulk permanent delete button
            if (bulkPermanentDeleteBtn) {
                bulkPermanentDeleteBtn.addEventListener('click', bulkPermanentlyDeleteTenants);
            }
        }
        
        // Set up event listeners for deleted tenant checkboxes
        function setupDeletedTenantCheckboxEventListeners() {
            // Select All checkbox for deleted tenants
            const selectAllDeletedCheckbox = document.getElementById('selectAllDeletedCheckbox');
            const deletedTenantCheckboxes = document.querySelectorAll('.deleted-tenant-checkbox');
            const bulkRestoreBtn = document.getElementById('bulkRestoreBtn');
            const bulkPermanentDeleteBtn = document.getElementById('bulkPermanentDeleteBtn');
            
            // Remove any existing event listeners to prevent duplicates
            if (selectAllDeletedCheckbox) {
                selectAllDeletedCheckbox.removeEventListener('change', handleSelectAllDeletedChange);
                selectAllDeletedCheckbox.addEventListener('change', handleSelectAllDeletedChange);
            }
            
            // Remove any existing event listeners from individual checkboxes
            deletedTenantCheckboxes.forEach(checkbox => {
                checkbox.removeEventListener('change', handleDeletedTenantCheckboxChange);
                checkbox.addEventListener('change', handleDeletedTenantCheckboxChange);
            });
            
            // Bulk restore button
            if (bulkRestoreBtn) {
                bulkRestoreBtn.removeEventListener('click', bulkRestoreTenants);
                bulkRestoreBtn.addEventListener('click', bulkRestoreTenants);
            }
            
            // Bulk permanent delete button
            if (bulkPermanentDeleteBtn) {
                bulkPermanentDeleteBtn.removeEventListener('click', bulkPermanentlyDeleteTenants);
                bulkPermanentDeleteBtn.addEventListener('click', bulkPermanentlyDeleteTenants);
            }
        }
        
        // Handle Select All deleted checkbox change
        function handleSelectAllDeletedChange(event) {
            const deletedTenantCheckboxes = document.querySelectorAll('.deleted-tenant-checkbox');
            
            deletedTenantCheckboxes.forEach(checkbox => {
                checkbox.checked = event.target.checked;
            });
            
            // Reset indeterminate state when user explicitly checks/unchecks select all
            event.target.indeterminate = false;
            toggleBulkDeletedButtons();
        }
        
        // Handle individual deleted tenant checkbox change
        function handleDeletedTenantCheckboxChange() {
            const selectAllDeletedCheckbox = document.getElementById('selectAllDeletedCheckbox');
            const deletedTenantCheckboxes = document.querySelectorAll('.deleted-tenant-checkbox');
            
            // Update select all checkbox state
            if (selectAllDeletedCheckbox) {
                const allChecked = Array.from(deletedTenantCheckboxes).every(cb => cb.checked);
                const anyChecked = Array.from(deletedTenantCheckboxes).some(cb => cb.checked);
                selectAllDeletedCheckbox.checked = allChecked;
                // Set indeterminate state when some but not all checkboxes are checked
                selectAllDeletedCheckbox.indeterminate = !allChecked && anyChecked;
            }
            
            toggleBulkDeletedButtons();
        }
        
        // Toggle bulk buttons visibility for deleted tenants
        function toggleBulkDeletedButtons() {
            const deletedTenantCheckboxes = document.querySelectorAll('.deleted-tenant-checkbox');
            const bulkRestoreBtn = document.getElementById('bulkRestoreBtn');
            const bulkPermanentDeleteBtn = document.getElementById('bulkPermanentDeleteBtn');
            
            if (bulkRestoreBtn && bulkPermanentDeleteBtn) {
                const anyChecked = Array.from(deletedTenantCheckboxes).some(cb => cb.checked);
                bulkRestoreBtn.classList.toggle('hidden', !anyChecked);
                bulkPermanentDeleteBtn.classList.toggle('hidden', !anyChecked);
            }
        }
        
        // Bulk restore tenants
        function bulkRestoreTenants() {
            const deletedTenantCheckboxes = document.querySelectorAll('.deleted-tenant-checkbox:checked');
            const tenantIds = Array.from(deletedTenantCheckboxes).map(cb => cb.dataset.tenantId);
            
            if (tenantIds.length === 0) {
                customAlert('Please select at least one tenant to restore.', 'No Tenants Selected');
                return;
            }
            
            // Use the HTML version of customConfirm explicitly
            if (typeof customConfirm !== 'undefined' && document.getElementById('customConfirmModal')) {
                customConfirm(`Are you sure you want to restore ${tenantIds.length} tenant(s)?`, 'Confirm Bulk Restore', function() {
                    tenantIds.forEach(tenantId => {
                        const tenantIndex = deletedTenants.findIndex(t => t.id === tenantId);
                        if (tenantIndex !== -1) {
                            const tenant = deletedTenants[tenantIndex];
                            
                            // Remove deletedDate property
                            delete tenant.deletedDate;
                            
                            // Move tenant back to active tenants
                            tenants.push(tenant);
                            deletedTenants.splice(tenantIndex, 1);
                            
                            // Notify tenant of restoration with specific information
                            notifyTenantOfUpdate(tenant, `Your tenant profile has been restored by admin. Tenant ID: ${tenant.id}, Name: ${tenant.name}`);
                        }
                    });
                    
                    // Save to localStorage
                    localStorage.setItem('tenants', JSON.stringify(tenants));
                    localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
                    
                    // Reload sections
                    loadDeletedTenants();
                    loadTenants();
                    
                    customAlert(`${tenantIds.length} tenant(s) restored successfully!`, 'Success');
                    
                    // Reset select all checkbox
                    const selectAllDeletedCheckbox = document.getElementById('selectAllDeletedCheckbox');
                    if (selectAllDeletedCheckbox) {
                        selectAllDeletedCheckbox.checked = false;
                        selectAllDeletedCheckbox.indeterminate = false;
                    }
                    
                    toggleBulkDeletedButtons();
                });
            } else {
                // Fallback to the app.js version if HTML version is not available
                customConfirm(`Are you sure you want to restore ${tenantIds.length} tenant(s)?`, 'Confirm Bulk Restore', function() {
                    tenantIds.forEach(tenantId => {
                        const tenantIndex = deletedTenants.findIndex(t => t.id === tenantId);
                        if (tenantIndex !== -1) {
                            const tenant = deletedTenants[tenantIndex];
                            
                            // Remove deletedDate property
                            delete tenant.deletedDate;
                            
                            // Move tenant back to active tenants
                            tenants.push(tenant);
                            deletedTenants.splice(tenantIndex, 1);
                            
                            // Notify tenant of restoration with specific information
                            notifyTenantOfUpdate(tenant, `Your tenant profile has been restored by admin. Tenant ID: ${tenant.id}, Name: ${tenant.name}`);
                        }
                    });
                    
                    // Save to localStorage
                    localStorage.setItem('tenants', JSON.stringify(tenants));
                    localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
                    
                    // Reload sections
                    loadDeletedTenants();
                    loadTenants();
                    
                    customAlert(`${tenantIds.length} tenant(s) restored successfully!`, 'Success');
                    
                    // Reset select all checkbox
                    const selectAllDeletedCheckbox = document.getElementById('selectAllDeletedCheckbox');
                    if (selectAllDeletedCheckbox) {
                        selectAllDeletedCheckbox.checked = false;
                        selectAllDeletedCheckbox.indeterminate = false;
                    }
                    
                    toggleBulkDeletedButtons();
                });
            }
        }
        
        // Bulk permanently delete tenants
        function bulkPermanentlyDeleteTenants() {
            const deletedTenantCheckboxes = document.querySelectorAll('.deleted-tenant-checkbox:checked');
            const tenantIds = Array.from(deletedTenantCheckboxes).map(cb => cb.dataset.tenantId);
            
            if (tenantIds.length === 0) {
                customAlert('Please select at least one tenant to permanently delete.', 'No Tenants Selected');
                return;
            }
            
            // Use the HTML version of customConfirm explicitly
            if (typeof customConfirm !== 'undefined' && document.getElementById('customConfirmModal')) {
                customConfirm(`Are you sure you want to permanently delete ${tenantIds.length} tenant(s)? This action cannot be undone.`, 'Confirm Bulk Permanent Delete', function() {
                    tenantIds.forEach(tenantId => {
                        const tenant = deletedTenants.find(t => t.id === tenantId);
                        deletedTenants = deletedTenants.filter(t => t.id !== tenantId);
                        
                        // Log admin activity
                        logAdminActivity(tenantId, `Tenant permanently deleted by admin`, 'tenant_permanent_deletion');
                        
                        // Notify tenant of permanent deletion if tenant exists
                        if (tenant) {
                            notifyTenantOfUpdate(tenant, `Your tenant profile has been permanently deleted by admin. Tenant ID: ${tenant.id}, Name: ${tenant.name}`);
                        }
                    });
                    
                    localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
                    loadDeletedTenants();
                    customAlert(`${tenantIds.length} tenant(s) permanently deleted!`, 'Success');
                    
                    // Reset select all checkbox
                    const selectAllDeletedCheckbox = document.getElementById('selectAllDeletedCheckbox');
                    if (selectAllDeletedCheckbox) {
                        selectAllDeletedCheckbox.checked = false;
                        selectAllDeletedCheckbox.indeterminate = false;
                    }
                    
                    toggleBulkDeletedButtons();
                });
            } else {
                // Fallback to the app.js version if HTML version is not available
                customConfirm(`Are you sure you want to permanently delete ${tenantIds.length} tenant(s)? This action cannot be undone.`, 'Confirm Bulk Permanent Delete', function() {
                    tenantIds.forEach(tenantId => {
                        const tenant = deletedTenants.find(t => t.id === tenantId);
                        deletedTenants = deletedTenants.filter(t => t.id !== tenantId);
                        
                        // Log admin activity
                        logAdminActivity(tenantId, `Tenant permanently deleted by admin`, 'tenant_permanent_deletion');
                        
                        // Notify tenant of permanent deletion if tenant exists
                        if (tenant) {
                            notifyTenantOfUpdate(tenant, `Your tenant profile has been permanently deleted by admin. Tenant ID: ${tenant.id}, Name: ${tenant.name}`);
                        }
                    });
                    
                    localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
                    loadDeletedTenants();
                    customAlert(`${tenantIds.length} tenant(s) permanently deleted!`, 'Success');
                    
                    // Reset select all checkbox
                    const selectAllDeletedCheckbox = document.getElementById('selectAllDeletedCheckbox');
                    if (selectAllDeletedCheckbox) {
                        selectAllDeletedCheckbox.checked = false;
                        selectAllDeletedCheckbox.indeterminate = false;
                    }
                    
                    toggleBulkDeletedButtons();
                });
            }
        }

        // Restore deleted tenant
        function restoreTenant(tenantId) {
            // Debug log to check if function is called
            console.log('restoreTenant called with tenantId:', tenantId);
            
            // Use the HTML version of customConfirm explicitly
            if (typeof customConfirm !== 'undefined' && document.getElementById('customConfirmModal')) {
                customConfirm('Are you sure you want to restore this tenant? This will move the tenant back to the active tenants list.', 'Confirm Restore Tenant', function() {
                    console.log('Custom confirm callback executed');
                    const tenantIndex = deletedTenants.findIndex(t => t.id === tenantId);
                    if (tenantIndex !== -1) {
                        const tenant = deletedTenants[tenantIndex];
                        
                        // Remove deletedDate property
                        delete tenant.deletedDate;
                        
                        // Move tenant back to active tenants
                        tenants.push(tenant);
                        deletedTenants.splice(tenantIndex, 1);
                        
                        // Notify tenant of restoration with specific information
                        notifyTenantOfUpdate(tenant, `Your tenant profile has been restored by admin. Tenant ID: ${tenant.id}, Name: ${tenant.name}`);
                        
                        // Save to localStorage
                        localStorage.setItem('tenants', JSON.stringify(tenants));
                        localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
                        
                        // Reload sections
                        loadDeletedTenants();
                        loadTenants();
                        
                        customAlert('Tenant restored successfully!', 'Success');
                    } else {
                        console.log('Tenant not found in deletedTenants array');
                    }
                });
            } else {
                // Fallback to the app.js version if HTML version is not available
                customConfirm('Are you sure you want to restore this tenant? This will move the tenant back to the active tenants list.', 'Confirm Restore Tenant', function() {
                    console.log('Custom confirm callback executed');
                    const tenantIndex = deletedTenants.findIndex(t => t.id === tenantId);
                    if (tenantIndex !== -1) {
                        const tenant = deletedTenants[tenantIndex];
                        
                        // Remove deletedDate property
                        delete tenant.deletedDate;
                        
                        // Move tenant back to active tenants
                        tenants.push(tenant);
                        deletedTenants.splice(tenantIndex, 1);
                        
                        // Notify tenant of restoration with specific information
                        notifyTenantOfUpdate(tenant, `Your tenant profile has been restored by admin. Tenant ID: ${tenant.id}, Name: ${tenant.name}`);
                        
                        // Save to localStorage
                        localStorage.setItem('tenants', JSON.stringify(tenants));
                        localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
                        
                        // Reload sections
                        loadDeletedTenants();
                        loadTenants();
                        
                        customAlert('Tenant restored successfully!', 'Success');
                    } else {
                        console.log('Tenant not found in deletedTenants array');
                    }
                });
            }
        }

        // Permanently delete tenant
        // Add event listeners for tenant checkboxes
        function addCheckboxEventListeners() {
            const checkboxes = document.querySelectorAll('.tenant-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    const tenantId = this.getAttribute('data-tenant-id');
                    const tenantIndex = tenants.findIndex(t => t.id === tenantId);
                    if (tenantIndex !== -1) {
                        tenants[tenantIndex].selected = this.checked;
                    }
                });
            });
        }



        // Custom alert function
        function customAlert(message, title) {
            alert(`${title}: ${message}`);
        }

        // Custom confirm function (deprecated - using modal version from HTML)
        // function customConfirm(message, title, callback) {
        //     if (confirm(`${title}: ${message}`)) {
        //         callback();
        //     }
        // }

        // Initialize the application
        function init() {
            loadTenants();
            loadDeletedTenants();
        }




        // Close add tenant modal
        function closeAddTenantModal() {
            document.getElementById('addTenantModal').classList.add('hidden');
            document.getElementById('addTenantForm').reset();
        }

        // Calculate total due for a tenant
        function calculateTotalDue(tenant) {
            let totalDue = 0;

            // Add rent
            if (tenant.rent) {
                const rentDue = tenant.rentDue || 0;
                totalDue += rentDue;

                // Add late fees
                if (tenant.lateFee) {
                    const lateFeeDue = tenant.lateFeeDue || 0;
                    totalDue += lateFeeDue;
                }

                // Add monthly payments
                if (tenant.monthlyPayments) {
                    for (let month in tenant.monthlyPayments) {
                        const monthPayment = tenant.monthlyPayments[month];
                        if (!monthPayment) {
                            totalDue += tenant.rent;
                        }
                    }
                }
            }
            
            // Add other pending bills
            if (tenant.otherBills) {
                tenant.otherBills.forEach(bill => {
                    if (!bill.paid) {
                        totalDue += bill.amount;
                    }
                });
            }
            
            return totalDue;
        }

        // Add tenant form submission
        document.getElementById('addTenantForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const tenant = {
                id: generateTenantId(),
                name: document.getElementById('tenantName').value,
                room: document.getElementById('roomNumber').value,
                rent: parseInt(document.getElementById('monthlyRent').value),
                securityDeposit: parseInt(document.getElementById('securityDeposit').value) || 0,
                phone: document.getElementById('phoneNumber').value,
                joinDate: new Date().toISOString().split('T')[0],
                payments: [],
                otherBills: [],
                documents: []
            };
            
            // Handle document uploads
            const fileInput = document.getElementById('tenantDocuments');
            if (fileInput.files.length > 0) {
                // For document uploads, we need to wait for the async operation to complete
                handleDocumentUploads(tenant, fileInput.files, function() {
                    // This callback is called after all documents are processed and saved
                    tenants.push(tenant);
                    localStorage.setItem('tenants', JSON.stringify(tenants));
                    
                    customAlert(`Tenant added successfully!\nTenant ID: ${tenant.id}\nPlease share this ID with the tenant for login.`, 'Success');
                    
                    closeAddTenantModal();
                    loadTenants();
                });
            } else {
                // No documents to upload, save immediately
                tenants.push(tenant);
                localStorage.setItem('tenants', JSON.stringify(tenants));
                
                customAlert(`Tenant added successfully!\nTenant ID: ${tenant.id}\nPlease share this ID with the tenant for login.`, 'Success');
                
                closeAddTenantModal();
                loadTenants();
            }
        });

        // Update payment
        function updatePayment(tenantId) {
            currentTenantId = tenantId;
            const tenant = tenants.find(t => t.id === tenantId);
            
            // Pre-fill with rent amount
            document.getElementById('paymentAmount').value = tenant.rent;
            
            // Reset to payment tab
            showPaymentTab('payment');
            
            document.getElementById('paymentModal').classList.remove('hidden');
        }

        // Close payment modal
        function closePaymentModal() {
            document.getElementById('paymentModal').classList.add('hidden');
            currentTenantId = null;
        }

    if (!localStorage.getItem('tenants')) {
        fetch('tenants.json')
        .then(response => response.json())
        .then(data => {
            if (data && data.length > 0) {
                const sampleTenant1 = data[0];
                const sampleTenant2 = data[1];
                const sampleTenant3 = data[2];
                tenants.push(sampleTenant1, sampleTenant2, sampleTenant3);
                localStorage.setItem('tenants', JSON.stringify(tenants));
            }
        });
    }

    // Edit tenant
        function editTenant(tenantId) {
            const tenant = tenants.find(t => t.id === tenantId);
            if (!tenant) {
                customAlert('Tenant not found.', 'Error');
                return;
            }
            
            currentTenantId = tenantId;
            
            // Populate form with current data
            document.getElementById('editTenantName').value = tenant.name;
            document.getElementById('editRoomNumber').value = tenant.room;
            document.getElementById('editMonthlyRent').value = tenant.rent;
            document.getElementById('editSecurityDeposit').value = tenant.securityDeposit || 0;
            document.getElementById('editPhoneNumber').value = tenant.phone;
            
            document.getElementById('editTenantModal').classList.remove('hidden');
        }

        // Close edit tenant modal
        function closeEditTenantModal() {
            document.getElementById('editTenantModal').classList.add('hidden');
            currentTenantId = null;
        }

        // Custom Alert Function
        function customAlert(message, title = 'Information') {
            document.getElementById('customAlertTitle').textContent = title;
            document.getElementById('customAlertMessage').textContent = message;
            document.getElementById('customAlertModal').classList.remove('hidden');
        }

        // Close custom alert
        function closeCustomAlert() {
            document.getElementById('customAlertModal').classList.add('hidden');
        }

        // Custom Confirm Function
        function customConfirm(message, title = 'Confirm', callback) {
            document.getElementById('customConfirmTitle').textContent = title;
            document.getElementById('customConfirmMessage').textContent = message;
            window.customConfirmCallback = callback;
            document.getElementById('customConfirmModal').classList.remove('hidden');
        }

        // Confirm custom confirm
        function confirmCustomConfirm() {
            document.getElementById('customConfirmModal').classList.add('hidden');
            if (window.customConfirmCallback) {
                window.customConfirmCallback();
            }
        }

        // Close custom confirm
        function closeCustomConfirm() {
            document.getElementById('customConfirmModal').classList.add('hidden');
        }

        // Show Tenant Profile
        function showTenantProfile(tenantId) {
            // First check if it's an active tenant
            let tenant = tenants.find(t => t.id === tenantId);
            let isDeleted = false;
            
            // If not found in active tenants, check deleted tenants
            if (!tenant) {
                tenant = deletedTenants.find(t => t.id === tenantId);
                isDeleted = true;
            }
            
            if (!tenant) return;
            
            const dueAmount = calculateDueAmount(tenant);
            const otherBillsCount = tenant.otherBills ? tenant.otherBills.filter(b => !b.paid).length : 0;
            const otherBillsAmount = tenant.otherBills ? tenant.otherBills.filter(b => !b.paid).reduce((sum, b) => sum + b.amount, 0) : 0;
            
            // Check if current month rent is paid
            const now = new Date();
            const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
            const currentMonthPayment = tenant.payments?.find(p => 
                p.date.startsWith(currentMonth) && p.type === 'rent'
            );
            const isCurrentMonthPaid = !!currentMonthPayment;
            
            const profileContent = document.getElementById('tenantProfileContent');
            profileContent.innerHTML = `
                <div class="bg-white dark:bg-gray-700 rounded-lg shadow p-6">
                    <div class="flex items-center space-x-4 mb-6">
                        <div class="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center ${isDeleted ? 'deleted-tenant-profile-icon' : 'tenant-profile-icon'}">
                            <span class="text-blue-600 dark:text-blue-400 text-2xl">👤</span>
                        </div>
                        <div>
                            <h2 class="text-2xl font-bold text-gray-900 dark:text-white">${tenant.name}</h2>
                            <p class="text-gray-600 dark:text-gray-300">Tenant ID: ${tenant.id}</p>
                        </div>
                        <div class="ml-auto flex space-x-2">
                            <button onclick="downloadTenantProfileReport('${tenant.id}')" class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark transition-colors">
                                📄 Download Report
                            </button>
                            <button onclick="openEditFromProfile('${tenant.id}')" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                                ✏️ Edit Profile
                            </button>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div class="bg-gray-50 dark:bg-gray-600 rounded-lg p-4">
                            <h3 class="font-medium text-gray-900 dark:text-white mb-2">Personal Information</h3>
                            <div class="space-y-2">
                                <p class="text-sm"><span class="font-medium">Phone:</span> ${tenant.phone || 'N/A'}</p>
                                <p class="text-sm"><span class="font-medium">Room:</span> ${tenant.room}</p>
                                <p class="text-sm"><span class="font-medium">Join Date:</span> ${tenant.joinDate}</p>
                                ${tenant.securityDeposit ? `<p class="text-sm"><span class="font-medium">Security Deposit:</span> ₹${tenant.securityDeposit}</p>` : ''}
                            </div>
                        </div>
                        
                        <div class="bg-gray-50 dark:bg-gray-600 rounded-lg p-4">
                            <h3 class="font-medium text-gray-900 dark:text-white mb-2">Financial Information</h3>
                            <div class="space-y-2">
                                <p class="text-sm"><span class="font-medium">Monthly Rent:</span> ₹${tenant.rent}</p>
                                ${tenant.securityDeposit ? `<p class="text-sm"><span class="font-medium">Security Deposit:</span> ₹${tenant.securityDeposit}</p>` : ''}
                                <p class="text-sm"><span class="font-medium">Current Status:</span> 
                                    <span class="${dueAmount > 0 ? 'text-red-600 dark:text-red-400' : 'text-primary dark:text-primary'}">
                                        ${dueAmount > 0 ? 'Pending' : 'Paid'}
                                    </span>
                                </p>
                                <p class="text-sm"><span class="font-medium">Due Amount:</span> 
                                    <span class="${dueAmount > 0 ? 'text-red-600 dark:text-red-400' : 'text-primary dark:text-primary'}">
                                        ₹${dueAmount}
                                    </span>
                                </p>
                                <p class="text-sm"><span class="font-medium">Other Bills:</span> 
                                    <span class="${otherBillsCount > 0 ? 'text-orange-600 dark:text-orange-400' : 'text-gray-600 dark:text-gray-300'}">
                                        ${otherBillsCount} (₹${otherBillsAmount})
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    ${isCurrentMonthPaid ? 
                        `<div class="bg-primary/5 dark:bg-primary-dark/20 border border-primary/20 dark:border-primary rounded-lg p-4 mb-6">
                            <p class="text-primary dark:text-primary">
                                <span class="font-medium">Payment Status:</span> Current month rent paid on ${currentMonthPayment.date}
                            </p>
                        </div>` : 
                        `<div class="bg-yellow-300 dark:bg-yellow-700/30 border border-yellow-500 dark:border-yellow-500 rounded-lg p-4 mb-6">
                            <p class="text-gray-900 dark:text-yellow-200 font-medium">
                                <span class="font-medium">Payment Status:</span> Current month rent not paid yet
                            </p>
                        </div>`}
                    
                    <div class="bg-gray-50 dark:bg-gray-600 rounded-lg p-4">
                        <h3 class="font-medium text-gray-900 dark:text-white mb-3">Other Bills</h3>
                        ${tenant.otherBills && tenant.otherBills.length > 0 ? 
                            `<div class="space-y-3">
                                ${tenant.otherBills.map(bill => {
                                    const isPaid = bill.paid;
                                    const isOverdue = !isPaid && bill.dueDate && new Date(bill.dueDate) < new Date();
                                    return `
                                        <div class="flex justify-between items-center p-3 rounded-lg ${isPaid ? 'bg-primary/5 dark:bg-primary-dark/20 border border-primary/20 dark:border-primary' : isOverdue ? 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700' : 'bg-yellow-300 dark:bg-gray-700 border border-yellow-500 dark:border-gray-500'}">
                                            <div>
                                                <p class="font-medium ${isPaid ? 'text-gray-900' : 'text-gray-900'} dark:text-white">${bill.description}</p>
                                                <p class="text-sm ${isPaid ? 'text-gray-600' : 'text-gray-700'} dark:text-gray-300">Type: ${bill.type.charAt(0).toUpperCase() + bill.type.slice(1)} | Amount: ₹${bill.amount}</p>
                                                ${bill.dueDate ? `<p class="text-xs ${isPaid ? 'text-primary' : isOverdue ? 'text-red-600' : 'text-gray-700'} dark:text-gray-500">Due: ${bill.dueDate}</p>` : ''}
                                            </div>
                                            <span class="text-xs font-medium px-2 py-1 rounded-full ${isPaid ? 'bg-primary/10 text-primary dark:bg-primary-dark/20 dark:text-primary' : isOverdue ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400' : 'bg-yellow-300 text-gray-900 dark:bg-yellow-900/20 dark:text-yellow-400'}">
                                                ${isPaid ? '✅ Paid' : isOverdue ? '🚨 Overdue' : '⏳ Pending'}
                                            </span>
                                        </div>
                                    `;
                                }).join('')}
                            </div>` : 
                            `<p class="text-gray-600 dark:text-gray-300 text-center py-4">No other bills</p>`}
                    </div>
                    
                    <!-- Rebuilt Uploaded Documents Section -->
                    <div class="bg-gray-50 dark:bg-gray-600 rounded-lg p-4 mt-6">
                        <div class="flex justify-between items-center mb-3">
                            <h3 class="font-medium text-gray-900 dark:text-white">📁 Uploaded Documents</h3>
                            <button onclick="openDocumentUploadModal('${tenant.id}')" class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm transition-colors duration-200 flex items-center">
                                <span class="mr-1">📤</span> Upload
                            </button>
                        </div>
                        ${tenant.documents && tenant.documents.length > 0 ? 
                            `<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                ${tenant.documents.map(doc => {
                                    const fileExtension = doc.name.split('.').pop().toLowerCase();
                                    const isImage = doc.type.startsWith('image/');
                                    const fileSize = formatFileSize(doc.size);
                                    const uploadDate = new Date(doc.uploadDate).toLocaleDateString();
                                    
                                    return `
                                        <div class="border border-gray-200 dark:border-gray-500 rounded-lg p-3 bg-white dark:bg-gray-700 transition-all duration-200 hover:shadow-md">
                                            <div class="flex justify-between items-start mb-2">
                                                <div class="flex items-start">
                                                    <div class="mr-2 mt-1">
                                                        ${getFileIcon(fileExtension)}
                                                    </div>
                                                    <div>
                                                        <p class="text-sm font-medium text-gray-900 dark:text-white truncate max-w-[180px]" title="${doc.name}">${doc.name}</p>
                                                        <p class="text-xs text-gray-600 dark:text-gray-300">${fileSize} • ${uploadDate}</p>
                                                    </div>
                                                </div>
                                                <div class="flex space-x-1">
                                                    ${isImage ? 
                                                        `<button onclick="viewDocument('${doc.data}')" class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 p-1" title="View Document">
                                                            👁️
                                                        </button>` : 
                                                        `<a href="${doc.data}" download="${doc.name}" class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 p-1" title="Download Document">
                                                            📥
                                                        </a>`}
                                                    <button onclick="deleteDocument('${tenant.id}', '${doc.id}')" class="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 p-1" title="Delete Document">
                                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                        </svg>
                                                    </button>
                                                </div>
                                            </div>
                                            ${isImage ? 
                                                `<div class="mt-2 rounded overflow-hidden max-h-32 flex items-center justify-center bg-gray-100 dark:bg-gray-600">
                                                    <img src="${doc.data}" alt="${doc.name}" class="object-contain max-h-32 max-w-full">
                                                </div>` : ''}
                                        </div>
                                    `;
                                }).join('')}
                            </div>` : 
                            `<div class="text-center py-6">
                                <div class="text-gray-400 dark:text-gray-500 mb-2 text-3xl">📂</div>
                                <p class="text-gray-600 dark:text-gray-300">No documents uploaded yet</p>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">Click "Upload" to add documents</p>
                            </div>`}
                    </div>
                </div>
            `;
            
            document.getElementById('tenantProfileModal').classList.remove('hidden');
        }

        // Open document upload modal
        function openDocumentUploadModal(tenantId) {
            const tenant = tenants.find(t => t.id === tenantId);
            if (!tenant) return;
            
            currentTenantId = tenantId;
            
            // Create a simple modal for document upload
            const modal = document.createElement('div');
            modal.id = 'documentUploadModal';
            modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
            modal.innerHTML = `
                <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-xl w-full max-w-md">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Upload Document</h3>
                        <button type="button" onclick="closeDocumentUploadModal()" class="text-gray-400 hover:text-gray-600 dark:text-gray-300 dark:hover:text-gray-100">
                            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Select Document</label>
                        <input type="file" id="documentUploadInput" multiple accept="image/*,.pdf,.doc,.docx" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600">
                    </div>
                    <div class="flex justify-end space-x-3">
                        <button type="button" onclick="closeDocumentUploadModal()" class="px-4 py-2 text-gray-600 hover:text-gray-800 dark:text-gray-300 dark:hover:text-gray-100">
                            Cancel
                        </button>
                        <button type="button" onclick="uploadDocuments()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                            Upload
                        </button>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
        }

        // Close document upload modal
        function closeDocumentUploadModal() {
            const modal = document.getElementById('documentUploadModal');
            if (modal) {
                modal.remove();
            }
        }

        // Upload documents
        function uploadDocuments() {
            const tenant = tenants.find(t => t.id === currentTenantId);
            if (!tenant) return;
            
            const fileInput = document.getElementById('documentUploadInput');
            if (fileInput.files.length > 0) {
                // For document uploads, we need to wait for the async operation to complete
                handleDocumentUploads(tenant, fileInput.files, function() {
                    // This callback is called after all documents are processed and saved
                    
                    // Notify tenant of document upload
                    notifyTenantOfUpdate(tenant, `${fileInput.files.length} document(s) uploaded by admin`);
                    
                    // Refresh the tenant profile
                    closeDocumentUploadModal();
                    showTenantProfile(currentTenantId);
                });
            } else {
                customAlert('Please select at least one document to upload.', 'No Document Selected');
            }
        }

        // Helper function to format file size
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
        
        // Helper function to get file icon based on extension
        function getFileIcon(extension) {
            const iconMap = {
                'pdf': '📄',
                'jpg': '🖼️',
                'jpeg': '🖼️',
                'png': '🖼️',
                'gif': '🖼️',
                'doc': '📝',
                'docx': '📝',
                'xls': '📊',
                'xlsx': '📊',
                'ppt': '📽️',
                'pptx': '📽️',
                'txt': '📝',
                'zip': '📦',
                'rar': '📦'
            };
            return iconMap[extension] || '📎';
        }

        // View document
        function viewDocument(dataUrl) {
            // Create a modal to view the document
            const modal = document.createElement('div');
            modal.id = 'documentViewModal';
            modal.className = 'fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4';
            modal.innerHTML = `
                <div class="relative w-full max-w-6xl max-h-full flex flex-col">
                    <div class="flex justify-between items-center mb-4 bg-gray-800 text-white p-4 rounded-t-lg">
                        <h3 class="text-lg font-semibold">Document Preview</h3>
                        <button type="button" onclick="closeDocumentViewModal()" class="text-gray-300 hover:text-white">
                            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                    <div class="flex-1 flex items-center justify-center bg-black overflow-auto rounded-b-lg">
                        <img src="${dataUrl}" alt="Document Preview" class="max-w-full max-h-[80vh] object-contain">
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            // Close modal when clicking outside the image
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closeDocumentViewModal();
                }
            });
        }

        // Close document view modal
        function closeDocumentViewModal() {
            const modal = document.getElementById('documentViewModal');
            if (modal) {
                modal.remove();
            }
        }

        // Delete document
        function deleteDocument(tenantId, documentId) {
            const tenant = tenants.find(t => t.id === tenantId);
            if (!tenant) return;
            
            const document = tenant.documents.find(d => d.id === documentId);
            if (document) {
                tenant.documents = tenant.documents.filter(d => d.id !== documentId);
                localStorage.setItem('tenants', JSON.stringify(tenants));
                
                // Notify tenant of document deletion
                notifyTenantOfUpdate(tenant, `Document \"${document.name}\" deleted by admin`);
                
                // Refresh the tenant profile
                showTenantProfile(tenantId);
            }
        }

        // Open edit tenant modal from profile
        function openEditFromProfile(tenantId) {
            const tenant = tenants.find(t => t.id === tenantId);
            if (!tenant) return;
            
            currentTenantId = tenantId;
            
            // Populate the edit form with tenant data
            document.getElementById('editTenantName').value = tenant.name;
            document.getElementById('editRoomNumber').value = tenant.room;
            document.getElementById('editMonthlyRent').value = tenant.rent;
            document.getElementById('editSecurityDeposit').value = tenant.securityDeposit || '';
            document.getElementById('editPhoneNumber').value = tenant.phone || '';
            
            // Clear document input
            document.getElementById('editTenantDocuments').value = '';
            
            // Close profile modal and open edit modal
            closeTenantProfileModal();
            document.getElementById('editTenantModal').classList.remove('hidden');
        }

        // Notify tenant of profile update
        function notifyTenantOfUpdate(tenant, changes) {
            // In a real application, this would send an SMS or email
            // For now, we'll just add it to the tenant's notification history
            if (!tenant.notifications) {
                tenant.notifications = [];
            }
            
            const notification = {
                id: Date.now(),
                message: `Your profile has been updated by admin. Changes: ${changes}`,
                date: new Date().toISOString().split('T')[0],
                time: new Date().toLocaleTimeString(),
                read: false
            };
            
            tenant.notifications.push(notification);
            
            // Also add to admin activity log
            logAdminActivity(tenant.id, `Profile updated: ${changes}`, 'profile_update');
        }

        // Close Tenant Profile Modal
        function closeTenantProfileModal() {
            document.getElementById('tenantProfileModal').classList.add('hidden');
        }
        
        // Download tenant profile report
        function downloadTenantProfileReport(tenantId) {
            const tenant = tenants.find(t => t.id === tenantId) || deletedTenants.find(t => t.id === tenantId);
            if (!tenant) {
                customAlert('Tenant not found.', 'Error');
                return;
            }
            
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Get website colors
            const primaryColor = [0, 119, 182]; // #0077b6
            const primaryDarkColor = [2, 62, 138]; // #023e8a
            const secondaryColor = [0, 150, 199]; // #0096c7
            const lightBackgroundColor = [229, 221, 213]; // #E5DDD5
            
            // Header
            doc.setFontSize(22);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(...primaryColor);
            doc.text('TENANT PROFILE REPORT', 20, 20);
            
            doc.setFontSize(12);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(0, 0, 0);
            doc.text(`Generated on: ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`, 20, 30);
            
            // Tenant Information Section
            let y = 45;
            doc.setFontSize(16);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(...primaryColor);
            doc.text(`Tenant: ${tenant.name} (${tenant.id})`, 20, y);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(0, 0, 0);
            y += 10;
            
            doc.setFillColor(...primaryColor);
            doc.setDrawColor(...primaryColor);
            doc.setTextColor(255, 255, 255);
            doc.rect(15, y, 180, 40, 'F');            
            doc.setFontSize(12);
            doc.text(`Name: ${tenant.name}`, 20, y + 8);
            doc.text(`ID: ${tenant.id}`, 20, y + 16);
            doc.text(`Room: ${tenant.room}`, 20, y + 24);
            doc.text(`Phone: ${tenant.phone || 'N/A'}`, 20, y + 32);
            
            doc.text(`Monthly Rent: Rs ${tenant.rent.toLocaleString()}`, 120, y + 8);
            doc.text(`Join Date: ${tenant.joinDate}`, 120, y + 16);
            if (tenant.securityDeposit) {
                doc.text(`Security Deposit: Rs ${tenant.securityDeposit.toLocaleString()}`, 120, y + 24);
            }
            if (tenant.deletedDate) {
                doc.text(`Deleted Date: ${tenant.deletedDate}`, 120, y + 32);
            }
            
            // Calculate and display due amount
            const dueAmount = calculateDueAmount(tenant);
            if (dueAmount > 0) {
                doc.text(`Outstanding Due: Rs ${dueAmount.toLocaleString()}`, 20, y + 48);
            }
            
            // Add payment status summary
            const now = new Date();
            const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
            const currentMonthPayment = tenant.payments?.find(p => 
                p.date.startsWith(currentMonth) && p.type === 'rent'
            );
            const isCurrentMonthPaid = !!currentMonthPayment;
            
            doc.text(`Current Month Status: ${isCurrentMonthPaid ? 'Paid' : 'Unpaid'}`, 120, y + 48);
            if (tenant.reminderCount > 0) {
                doc.text(`Reminders Sent: ${tenant.reminderCount}/3`, 20, y + 56);
            }
            
            // Add unpaid months information
            const unpaidMonths = getUnpaidMonths(tenant);
            if (unpaidMonths.length > 0) {
                doc.text(`Unpaid Months: ${unpaidMonths.join(', ')}`, 20, y + 64);
            }
            
            y += 80;
            
            // Payment History Section
            doc.setFontSize(14);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(...primaryColor);
            doc.text('Payment History:', 20, y);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(0, 0, 0);
            y += 15;
            
            if (tenant.payments && tenant.payments.length > 0) {
                // Table headers with better formatting
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Date', 20, y);
                doc.text('Type', 50, y);
                doc.text('Amount (Rs)', 100, y, null, null, 'right');
                doc.text('Method', 130, y);
                doc.text('Notes', 160, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                // Sort payments by date (newest first)
                const sortedPayments = [...tenant.payments].sort((a, b) => new Date(b.date) - new Date(a.date));
                
                // Table data with better alignment
                sortedPayments.forEach((payment, index) => {
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, 8, 'F');
                    }
                    
                    doc.text(payment.date, 20, y);
                    doc.text(payment.type.charAt(0).toUpperCase() + payment.type.slice(1), 50, y);
                    doc.text(payment.amount.toLocaleString(), 100, y, null, null, 'right');
                    doc.text(payment.method, 130, y);
                    doc.text((payment.notes || '').substring(0, 20), 160, y);
                    
                    y += 8;
                    
                    // Check if we need a new page
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Date', 20, y);
                        doc.text('Type', 50, y);
                        doc.text('Amount (Rs)', 100, y, null, null, 'right');
                        doc.text('Method', 130, y);
                        doc.text('Notes', 160, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                    }
                });
                
                // Summary section
                y += 15;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Payment Summary:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 10;
                
                doc.line(20, y, 195, y);
                y += 10;
                
                const totalPaid = tenant.payments.reduce((sum, p) => sum + p.amount, 0);
                const rentPayments = tenant.payments.filter(p => p.type === 'rent');
                const otherPayments = tenant.payments.filter(p => p.type !== 'rent');
                
                doc.setFontSize(12);
                doc.text(`Total Payments Made:`, 20, y);
                doc.text(`Rs ${totalPaid.toLocaleString()}`, 195, y, null, null, 'right');
                y += 10;
                
                doc.text(`Rent Payments:`, 20, y);
                doc.text(`${rentPayments.length} (Rs ${rentPayments.reduce((sum, p) => sum + p.amount, 0).toLocaleString()})`, 195, y, null, null, 'right');
                y += 10;
                
                doc.text(`Other Payments:`, 20, y);
                doc.text(`${otherPayments.length} (Rs ${otherPayments.reduce((sum, p) => sum + p.amount, 0).toLocaleString()})`, 195, y, null, null, 'right');
                
            } else {
                doc.setFontSize(12);
                doc.text('No payment history available', 20, y);
            }
            
            // Other Bills Section
            if (tenant.otherBills && tenant.otherBills.length > 0) {
                y += 30;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Other Bills:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 15;
                
                // Table headers
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Type', 20, y);
                doc.text('Description', 50, y);
                doc.text('Amount (Rs)', 100, y, null, null, 'right');
                doc.text('Status', 130, y);
                doc.text('Due Date', 160, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                // Table data
                tenant.otherBills.forEach((bill, index) => {
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, 8, 'F');
                    }
                    
                    doc.text(bill.type, 20, y);
                    doc.text(bill.description.substring(0, 20), 50, y);
                    doc.text(bill.amount.toLocaleString(), 100, y, null, null, 'right');
                    doc.text(bill.paid ? 'Paid' : 'Pending', 130, y);
                    doc.text(bill.dueDate || 'N/A', 160, y);
                    
                    y += 8;
                    
                    // Check if we need a new page
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Type', 20, y);
                        doc.text('Description', 50, y);
                        doc.text('Amount (Rs)', 100, y, null, null, 'right');
                        doc.text('Status', 130, y);
                        doc.text('Due Date', 160, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                    }
                });
            }
            
            // Admin Activity Section
            if (tenant.adminActivity && tenant.adminActivity.length > 0) {
                y += 30;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Admin Activities:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 15;
                
                // Table headers for admin activities
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Date & Time', 20, y);
                doc.text('Activity', 60, y);
                doc.text('Type', 160, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                // Sort activities by timestamp (newest first)
                const sortedActivities = [...tenant.adminActivity].sort((a, b) => 
                    new Date(b.timestamp) - new Date(a.timestamp)
                );
                
                // List admin activities in a table format
                sortedActivities.forEach((activity, index) => {
                    // Calculate row height based on content
                    let actionText = activity.action;
                    // Remove any accidental duplication in the action text
                    if (actionText.includes('Payment') && actionText.endsWith('Payment')) {
                        actionText = actionText.replace(/ Payment$/, '');
                    }
                    
                    // Fix currency symbol encoding issues
                    actionText = actionText.replace(/â¹/g, 'Rs').replace(/¹/g, 'Rs').replace(/â¹/g, 'Rs').replace(/[â¹¹]/g, 'Rs');
                    
                    let rowHeight = 8; // Base height
                    let extraLines = 0;
                    
                    // Calculate height needed for document upload activities
                    if (activity.type === 'document_upload' && actionText.includes(':')) {
                        const parts = actionText.split(': ');
                        // First line for "label:"
                        extraLines += 1;
                        // Lines needed for filename wrapping
                        const filename = parts[1];
                        if (filename.length > 40) {
                            extraLines += 1;
                            if (filename.length > 80) {
                                extraLines += 1;
                                if (filename.length > 120) {
                                    extraLines += 1;
                                }
                            }
                        }
                    } else {
                        // Calculate height needed for standard activities
                        if (actionText.length > 40) {
                            extraLines += 1;
                            if (actionText.length > 80) {
                                extraLines += 1;
                                if (actionText.length > 120) {
                                    extraLines += 1;
                                }
                            }
                        }
                    }
                    
                    rowHeight += extraLines * 6; // 6 units per extra line
                    
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, rowHeight, 'F');
                    }
                    
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers on new page
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Date & Time', 20, y);
                        doc.text('Activity', 60, y);
                        doc.text('Type', 160, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                        
                        // Redraw alternating row colors on new page if needed
                        if (index % 2 === 1) {
                            doc.setFillColor(248, 248, 248);
                            doc.rect(15, y - 6, 180, rowHeight, 'F');
                        }
                    }
                    
                    // Format date and time
                    const activityDateTime = `${activity.date} ${activity.time}`;
                    doc.text(activityDateTime, 20, y);
                    
                    // Track initial y position for proper row height calculation
                    const initialY = y;
                    
                    // Format document upload activities to show on multiple lines if needed
                    if (activity.type === 'document_upload' && actionText.includes(':')) {
                        const parts = actionText.split(': ');
                        doc.text(parts[0] + ':', 60, y);
                        y += 6;
                        // Wrap the filename if it's too long
                        const filename = parts[1];
                        if (filename.length > 40) {
                            doc.text(filename.substring(0, 40), 65, y);
                            y += 6;
                            if (filename.length > 80) {
                                doc.text(filename.substring(40, 80), 65, y);
                                y += 6;
                                if (filename.length > 120) {
                                    doc.text(filename.substring(80, 120) + '...', 65, y);
                                } else {
                                    doc.text(filename.substring(80), 65, y);
                                }
                            } else {
                                doc.text(filename.substring(40), 65, y);
                            }
                        } else {
                            doc.text(filename, 65, y);
                        }
                    } else {
                        // Standard activity formatting
                        doc.text(actionText.substring(0, 40), 60, y);
                        
                        y += 6;
                        
                        // If action text is long, add continuation on next line
                        if (actionText.length > 40) {
                            doc.text(actionText.substring(40, 80), 60, y);
                            y += 6;
                            
                            // If still longer, add more continuation
                            if (actionText.length > 80) {
                                doc.text(actionText.substring(80, 120), 60, y);
                                y += 6;
                            }
                        }
                    }
                    
                    doc.text(activity.type.charAt(0).toUpperCase() + activity.type.slice(1), 160, y);
                    
                    // Ensure proper spacing by moving y position by the calculated row height
                    y += Math.max(0, rowHeight - (y - initialY));
                });
            }
            
            // Documents Section
            if (tenant.documents && tenant.documents.length > 0) {
                y += 30;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Uploaded Documents:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 15;
                
                // Table headers for documents
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Document Name', 20, y);
                doc.text('Type', 100, y);
                doc.text('Upload Date', 140, y);
                doc.text('Size', 170, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                tenant.documents.forEach((docItem, index) => {
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, 8, 'F');
                    }
                    
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers on new page
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Document Name', 20, y);
                        doc.text('Type', 100, y);
                        doc.text('Upload Date', 140, y);
                        doc.text('Size', 170, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                    }
                    
                    // Format file size
                    const fileSize = docItem.size ? (docItem.size / 1024).toFixed(1) + ' KB' : 'N/A';
                    
                    doc.text(docItem.name.substring(0, 25), 20, y);
                    doc.text(docItem.type.substring(0, 15), 100, y);
                    doc.text(new Date(docItem.uploadDate).toLocaleDateString(), 140, y);
                    doc.text(fileSize, 170, y);
                    
                    y += 8;
                    
                    // Embed document image if it's an image type
                    if (docItem.type.startsWith('image/') && docItem.data) {
                        try {
                            // Add a new page for the document
                            doc.addPage();
                            y = 20;
                            
                            doc.setFontSize(14);
                            doc.setFont(undefined, 'bold');
                            doc.setTextColor(...primaryColor);
                            doc.text(`Document: ${docItem.name}`, 20, y);
                            doc.setFont(undefined, 'normal');
                            doc.setTextColor(0, 0, 0);
                            y += 10;
                            
                            // Add document details
                            doc.setFontSize(10);
                            doc.text(`Type: ${docItem.type}`, 20, y);
                            y += 6;
                            doc.text(`Upload Date: ${new Date(docItem.uploadDate).toLocaleDateString()}`, 20, y);
                            y += 10;
                            
                            // Try to embed the image
                            const imgData = docItem.data;
                            const imgProps = doc.getImageProperties(imgData);
                            const pdfWidth = doc.internal.pageSize.getWidth() - 40;
                            const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
                            
                            // Check if image fits on current page
                            if (pdfHeight > (doc.internal.pageSize.getHeight() - y - 20)) {
                                // Scale to fit page
                                const maxHeight = doc.internal.pageSize.getHeight() - y - 20;
                                const maxWidth = doc.internal.pageSize.getWidth() - 40;
                                const ratio = Math.min(maxWidth/imgProps.width, maxHeight/imgProps.height);
                                const width = imgProps.width * ratio;
                                const height = imgProps.height * ratio;
                                doc.addImage(imgData, 20, y, width, height);
                            } else {
                                doc.addImage(imgData, 20, y, pdfWidth, pdfHeight);
                            }
                        } catch (error) {
                            // If image embedding fails, add error note
                            doc.text('Error embedding image: ' + docItem.name, 20, y);
                        }
                    }
                });
            }
            
            doc.save(`tenant-profile-report-${tenant.id}-${new Date().toISOString().split('T')[0]}.pdf`);
        }
        // Edit tenant form submission
        document.getElementById('editTenantForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const tenant = tenants.find(t => t.id === currentTenantId);
            const oldRent = tenant.rent;
            const oldSecurityDeposit = tenant.securityDeposit || 0;
            const oldName = tenant.name;
            const oldRoom = tenant.room;
            const oldPhone = tenant.phone;
            
            tenant.name = document.getElementById('editTenantName').value;
            tenant.room = document.getElementById('editRoomNumber').value;
            tenant.rent = parseInt(document.getElementById('editMonthlyRent').value);
            tenant.securityDeposit = parseInt(document.getElementById('editSecurityDeposit').value) || 0;
            tenant.phone = document.getElementById('editPhoneNumber').value;
            
            // Prepare notification message
            let changes = [];
            if (oldName !== tenant.name) changes.push(`Name: ${oldName} → ${tenant.name}`);
            if (oldRoom !== tenant.room) changes.push(`Room: ${oldRoom} → ${tenant.room}`);
            if (oldRent !== tenant.rent) changes.push(`Rent: Rs ${oldRent} → Rs ${tenant.rent}`);
            if (oldSecurityDeposit !== tenant.securityDeposit) changes.push(`Security Deposit: Rs ${oldSecurityDeposit} → Rs ${tenant.securityDeposit}`);
            if (oldPhone !== tenant.phone) changes.push(`Phone: ${oldPhone || 'N/A'} → ${tenant.phone || 'N/A'}`);
            
            // Handle document uploads
            const fileInput = document.getElementById('editTenantDocuments');
            if (fileInput.files.length > 0) {
                // For document uploads, we need to wait for the async operation to complete
                handleDocumentUploads(tenant, fileInput.files, function() {
                    // This callback is called after all documents are processed and saved
                    
                    // Create notification message
                    let notificationMessage = '';
                    if (changes.length > 0) {
                        notificationMessage = changes.join(', ');
                    } else {
                        notificationMessage = 'Profile information updated';
                    }
                    
                    // Notify tenant of changes
                    notifyTenantOfUpdate(tenant, notificationMessage);
                    
                    // Log rent change if it changed
                    if (oldRent !== tenant.rent) {
                        logAdminActivity(tenant.id, `Rent amount changed from Rs ${oldRent} to Rs ${tenant.rent}`, 'rent_change');
                    }
                    
                    closeEditTenantModal();
                    loadTenants();
                    customAlert('Tenant updated successfully!');
                    
                    // Refresh tenant profile if it's open
                    if (document.getElementById('tenantProfileModal') && !document.getElementById('tenantProfileModal').classList.contains('hidden')) {
                        showTenantProfile(currentTenantId);
                    }
                });
                changes.push(`${fileInput.files.length} document(s) uploaded`);
            } else {
                // No documents to upload, save immediately
                localStorage.setItem('tenants', JSON.stringify(tenants));
                
                // Create notification message
                let notificationMessage = '';
                if (changes.length > 0) {
                    notificationMessage = changes.join(', ');
                } else {
                    notificationMessage = 'Profile information updated';
                }
                
                // Notify tenant of changes
                notifyTenantOfUpdate(tenant, notificationMessage);
                
                // Log rent change if it changed
                if (oldRent !== tenant.rent) {
                    logAdminActivity(tenant.id, `Rent amount changed from Rs ${oldRent} to Rs ${tenant.rent}`, 'rent_change');
                }
                
                closeEditTenantModal();
                loadTenants();
                customAlert('Tenant updated successfully!');
                
                // Refresh tenant profile if it's open
                if (document.getElementById('tenantProfileModal') && !document.getElementById('tenantProfileModal').classList.contains('hidden')) {
                    showTenantProfile(currentTenantId);
                }
            }
        });

        // Delete tenant
        function deleteTenant(tenantId) {
            const tenant = tenants.find(t => t.id === tenantId);
            currentTenantId = tenantId;
            
            document.getElementById('deleteConfirmContent').innerHTML = `
                <p class="text-gray-700 mb-4">Are you sure you want to delete this tenant?</p>
                <div class="bg-gray-50 p-4 rounded-lg">
                    <p><strong>Name:</strong> ${tenant.name}</p>
                    <p><strong>ID:</strong> ${tenant.id}</p>
                    <p><strong>Room:</strong> ${tenant.room}</p>
                    <p><strong>Monthly Rent:</strong> ₹${tenant.rent}</p>
                </div>
                <p class="text-sm text-gray-600 mt-4">This action cannot be undone. The tenant data will be moved to deleted history.</p>
            `;
            
            document.getElementById('deleteConfirmModal').classList.remove('hidden');
        }

        // Close delete confirmation modal
        function closeDeleteConfirmModal() {
            document.getElementById('deleteConfirmModal').classList.add('hidden');
            currentTenantId = null;
        }

        // Confirm delete
        function confirmDelete() {
            const tenant = tenants.find(t => t.id === currentTenantId);
            // Create a deep copy of the tenant object to avoid reference issues
            const tenantCopy = JSON.parse(JSON.stringify(tenant));
            tenantCopy.deletedDate = new Date().toISOString().split('T')[0];
            
            deletedTenants.push(tenantCopy);
            tenants = tenants.filter(t => t.id !== currentTenantId);
            
            // Notify tenant of deletion
            notifyTenantOfUpdate(tenant, 'Your tenant profile has been deleted by admin');
            
            // Log admin activity
            logAdminActivity(tenant.id, `Tenant deleted by admin`, 'tenant_deletion');
            
            localStorage.setItem('tenants', JSON.stringify(tenants));
            localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
            
            closeDeleteConfirmModal();
            loadTenants();
            customAlert('Tenant deleted successfully!', 'Success');
        }

        // Update reports data
        function updateReportsData() {
            document.getElementById('totalTenants').textContent = tenants.length;
            
            const monthlyRevenue = tenants.reduce((sum, tenant) => {
                const currentMonth = new Date().toISOString().slice(0, 7);
                const monthlyPayments = tenant.payments?.filter(p => 
                    p.date.startsWith(currentMonth)
                ) || [];
                return sum + monthlyPayments.reduce((pSum, p) => pSum + p.amount, 0);
            }, 0);
            
            document.getElementById('monthlyRevenue').textContent = `₹${monthlyRevenue}`;
            
            const pendingAmount = tenants.reduce((sum, tenant) => sum + calculateDueAmount(tenant), 0);
            document.getElementById('pendingPayments').textContent = `₹${pendingAmount}`;
            
            // Update dashboard statistics and load recent data
            updateDashboardStats();
            loadRecentPayments();
            loadRecentNotifications();
            loadRecentAdminActivities();
        }

        // Download reports
        function downloadReport(format) {
            const period = document.getElementById('reportPeriod').value;
            const reportData = generateReportData(period);
            
            if (format === 'pdf') {
                downloadPDFReport(reportData, period);
            } else {
                downloadExcelReport(reportData, period);
            }
        }

        // Generate report data
        function generateReportData(period) {
            const now = new Date();
            let startDate, endDate;
            
            if (period === 'current') {
                startDate = new Date(now.getFullYear(), now.getMonth(), 1);
                endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
            } else if (period === 'last') {
                startDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
                endDate = new Date(now.getFullYear(), now.getMonth(), 0);
            } else {
                startDate = new Date(now.getFullYear(), 0, 1);
                endDate = new Date(now.getFullYear(), 11, 31);
            }
            
            const data = [];
            tenants.forEach(tenant => {
                const payments = tenant.payments?.filter(p => {
                    const paymentDate = new Date(p.date);
                    return paymentDate >= startDate && paymentDate <= endDate;
                }) || [];
                
                data.push({
                    id: tenant.id,
                    name: tenant.name,
                    room: tenant.room,
                    rent: tenant.rent,
                    totalPaid: payments.reduce((sum, p) => sum + p.amount, 0),
                    payments: payments
                });
            });
            
            return data;
        }

        // Download PDF report
        function downloadPDFReport(data, period) {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Get website colors
            const primaryColor = [0, 119, 182]; // #0077b6
            const primaryDarkColor = [2, 62, 138]; // #023e8a
            const secondaryColor = [0, 150, 199]; // #0096c7
            const lightBackgroundColor = [229, 221, 213]; // #E5DDD5
            
            // Header
            doc.setFontSize(20);
            doc.setTextColor(...primaryColor);
            doc.text('Rental Management Report', 20, 20);
            
            doc.setFontSize(12);
            doc.setTextColor(0, 0, 0);
            doc.text(`Period: ${period.charAt(0).toUpperCase() + period.slice(1)}`, 20, 35);
            doc.text(`Generated: ${new Date().toLocaleDateString()}`, 20, 45);
            
            // Table headers with better formatting
            let y = 65;
            doc.setFontSize(10);
            doc.setFillColor(...primaryColor); // Primary color background
            doc.setTextColor(255, 255, 255); // White text
            doc.rect(15, y - 7, 180, 10, 'F'); // Background rectangle
            
            doc.setFont(undefined, 'bold');
            doc.text('ID', 20, y);
            doc.text('Name', 45, y);
            doc.text('Room', 85, y);
            doc.text('Rent (Rs)', 110, y, null, null, 'right');
            doc.text('Paid (Rs)', 135, y, null, null, 'right');
            doc.text('Other Bills', 160, y);
            
            doc.setFont(undefined, 'normal');
            doc.setTextColor(0, 0, 0); // Black text
            doc.line(15, y + 3, 195, y + 3);
            y += 12;            
            // Table data with better alignment
            data.forEach((tenant, index) => {
                // Alternate row colors for better readability
                if (index % 2 === 1) {
                    doc.setFillColor(248, 248, 248); // Very light gray
                    doc.rect(15, y - 6, 180, 8, 'F');
                }
                
                const otherBillsAmount = tenant.otherBills ? tenant.otherBills.filter(b => !b.paid).reduce((sum, b) => sum + b.amount, 0) : 0;
                const otherBillsCount = tenant.otherBills ? tenant.otherBills.filter(b => !b.paid).length : 0;
                
                doc.text(tenant.id, 20, y);
                doc.text(tenant.name.substring(0, 15), 45, y);
                doc.text(tenant.room, 85, y);
                doc.text(tenant.rent.toString(), 110, y, null, null, 'right');
                doc.text(tenant.totalPaid.toString(), 135, y, null, null, 'right');
                doc.text(otherBillsCount > 0 ? `${otherBillsCount} (Rs ${otherBillsAmount.toLocaleString()})` : 'None', 160, y);
                
                y += 8;
                
                // Check if we need a new page
                if (y > 270) {
                    doc.addPage();
                    y = 20;
                    
                    // Repeat headers on new page
                    doc.setFillColor(...primaryColor);
                    doc.setTextColor(255, 255, 255);
                    doc.rect(15, y - 7, 180, 10, 'F');
                    
                    doc.setFont(undefined, 'bold');
                    doc.text('ID', 20, y);
                    doc.text('Name', 45, y);
                    doc.text('Room', 85, y);
                    doc.text('Rent (Rs)', 110, y, null, null, 'right');
                    doc.text('Paid (Rs)', 135, y, null, null, 'right');
                    doc.text('Other Bills', 160, y);
                    
                    doc.setFont(undefined, 'normal');
                    doc.setTextColor(0, 0, 0);
                    doc.line(15, y + 3, 195, y + 3);
                    y += 12;
                }
            });
            
            // Summary section with better formatting
            y += 15;
            if (y > 250) {
                doc.addPage();
                y = 20;
            }
            
            doc.setFontSize(14);
            doc.setFont(undefined, 'bold');
            doc.text('Summary', 20, y);
            doc.setFont(undefined, 'normal');
            y += 10;
            
            doc.line(20, y, 195, y);
            y += 10;
            
            const totalRent = data.reduce((sum, t) => sum + t.rent, 0);
            const totalPaid = data.reduce((sum, t) => sum + t.totalPaid, 0);
            const totalOtherBills = data.reduce((sum, t) => {
                return sum + (t.otherBills ? t.otherBills.filter(b => !b.paid).reduce((bSum, b) => bSum + b.amount, 0) : 0);
            }, 0);
            
            doc.setFontSize(12);
            doc.text(`Total Expected Rent:`, 20, y);
            doc.text(`Rs ${totalRent.toLocaleString()}`, 195, y, null, null, 'right');
            y += 10;
            
            doc.text(`Total Collected:`, 20, y);
            doc.text(`Rs ${totalPaid.toLocaleString()}`, 195, y, null, null, 'right');
            y += 10;
            
            doc.text(`Pending Other Bills:`, 20, y);
            doc.text(`Rs ${totalOtherBills.toLocaleString()}`, 195, y, null, null, 'right');
            y += 10;
            
            const collectionRate = totalRent > 0 ? Math.round((totalPaid / totalRent) * 100) : 0;
            doc.text(`Collection Rate:`, 20, y);
            doc.text(`${collectionRate}%`, 195, y, null, null, 'right');
            
            doc.save(`rental-report-${period}-${new Date().toISOString().split('T')[0]}.pdf`);
        }

        // Download Excel report
        function downloadExcelReport(data, period) {
            const ws_data = [
                ['Tenant ID', 'Name', 'Room', 'Monthly Rent', 'Total Paid', 'Other Bills Count', 'Other Bills Amount', 'Total Due', 'Status', 'Phone', 'Join Date', 'Reminders Sent']
            ];
            
            data.forEach(tenant => {
                const otherBillsCount = tenant.otherBills ? tenant.otherBills.filter(b => !b.paid).length : 0;
                const otherBillsAmount = tenant.otherBills ? tenant.otherBills.filter(b => !b.paid).reduce((sum, b) => sum + b.amount, 0) : 0;
                const totalDue = calculateDueAmount(tenants.find(t => t.id === tenant.id));
                
                ws_data.push([
                    tenant.id,
                    tenant.name,
                    tenant.room,
                    tenant.rent,
                    tenant.totalPaid,
                    otherBillsCount,
                    otherBillsAmount,
                    totalDue,
                    totalDue > 0 ? 'Pending' : 'Paid',
                    tenant.phone || 'N/A',
                    tenant.joinDate || 'N/A',
                    tenant.reminderCount || 0
                ]);
            });
            
            // Add summary row
            ws_data.push([]);
            ws_data.push(['SUMMARY']);
            ws_data.push(['Total Tenants', data.length]);
            ws_data.push(['Total Expected Rent', data.reduce((sum, t) => sum + t.rent, 0)]);
            ws_data.push(['Total Collected', data.reduce((sum, t) => sum + t.totalPaid, 0)]);
            ws_data.push(['Total Other Bills Pending', data.reduce((sum, t) => {
                return sum + (t.otherBills ? t.otherBills.filter(b => !b.paid).reduce((bSum, b) => bSum + b.amount, 0) : 0);
            }, 0)]);
            
            const ws = XLSX.utils.aoa_to_sheet(ws_data);
            
            // Set column widths
            ws['!cols'] = [
                {wch: 15}, // Tenant ID
                {wch: 20}, // Name
                {wch: 10}, // Room
                {wch: 12}, // Monthly Rent
                {wch: 12}, // Total Paid
                {wch: 15}, // Other Bills Count
                {wch: 18}, // Other Bills Amount
                {wch: 12}, // Total Due
                {wch: 10}, // Status
                {wch: 15}, // Phone
                {wch: 12}, // Join Date
                {wch: 15}  // Reminders Sent
            ];
            
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Rental Report');
            
            XLSX.writeFile(wb, `rental-report-${period}-${new Date().toISOString().split('T')[0]}.xlsx`);
        }

        // Load reminders
        function loadReminders() {
            const remindersList = document.getElementById('remindersList');
            remindersList.innerHTML = '';
            
            tenants.forEach(tenant => {
                const dueAmount = calculateDueAmount(tenant);
                
                // Check if tenant is new (joined this month)
                const currentDate = new Date();
                const joinDate = new Date(tenant.joinDate);
                const isNewTenant = (currentDate.getFullYear() === joinDate.getFullYear() && 
                                   currentDate.getMonth() === joinDate.getMonth());
                
                // Check if current month rent is paid
                const currMonth = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;
                const currMonthPayment = tenant.payments?.find(p => 
                    p.date.startsWith(currMonth) && p.type === 'rent'
                );
                const isCurrMonthPaid = !!currMonthPayment;
                
                // Show in reminders if dueAmount > 0 OR if new tenant hasn't paid yet
                if (dueAmount > 0 || (isNewTenant && !isCurrMonthPaid)) {
                    // Initialize reminder count if not exists
                    if (!tenant.reminderCount) {
                        tenant.reminderCount = 0;
                    }
                    
                    // For new tenants with 0 due amount, we still show them as pending
                    const effectiveDueAmount = dueAmount > 0 ? dueAmount : tenant.rent;
                    const isOverdue = tenant.reminderCount >= 3;
                    const cardClass = isOverdue ? 'bg-red-100 border border-red-300 dark:bg-red-900/30 dark:border-red-600' : 'bg-yellow-100 border border-yellow-300 dark:bg-yellow-900/30 dark:border-yellow-600';
                    const statusText = isOverdue ? '🚨 OVERDUE' : '⚠️ PENDING';
                    const statusColor = isOverdue ? 'text-red-700 dark:text-red-300' : 'text-gray-900 dark:text-gray-300';
                    
                    const reminderCard = document.createElement('div');
                    reminderCard.className = `${cardClass} rounded-lg p-4`;
                    reminderCard.innerHTML = `
                        <div class="flex justify-between items-center">
                            <div>
                                <div class="flex items-center space-x-2">
                                    <h4 class="font-medium text-gray-900 dark:text-white">${tenant.name} (${tenant.id})</h4>
                                    <span class="text-xs font-medium ${statusColor}">${statusText}</span>
                                </div>
                                <p class="text-sm text-gray-900 dark:text-gray-300">Room: ${tenant.room} | Due: Rs ${effectiveDueAmount}</p>
                                <p class="text-sm text-gray-900 dark:text-gray-300">Phone: ${tenant.phone}</p>
                                <p class="text-xs text-gray-900 dark:text-gray-300">Reminders sent: ${tenant.reminderCount}/3</p>
                            </div>
                            <div class="flex space-x-2">
                                <button onclick="sendReminder('${tenant.id}')" class="${isOverdue ? 'bg-red-700 hover:bg-red-800 dark:bg-red-800 dark:hover:bg-red-900' : 'bg-yellow-700 hover:bg-yellow-800 dark:bg-yellow-800 dark:hover:bg-yellow-900'} text-white px-3 py-1 rounded text-sm transition-colors">
                                    📱 Send Reminder
                                </button>
                                <button onclick="updatePayment('${tenant.id}')" class="bg-primary text-white px-3 py-1 rounded text-sm hover:bg-primary-dark transition-colors dark:bg-primary-dark dark:hover:bg-primary">
                                    💰 Mark Paid
                                </button>
                            </div>
                        </div>
                    `;
                    remindersList.appendChild(reminderCard);
                }
            });
            
            if (remindersList.children.length === 0) {
                remindersList.innerHTML = '<p class="text-gray-500 text-center py-8">No pending payments! 🎉</p>';
            }
        }

        // Send reminder
        function sendReminder(tenantId) {
            const tenant = tenants.find(t => t.id === tenantId);
            const dueAmount = calculateDueAmount(tenant);
            
            // Initialize reminder count if not exists
            if (!tenant.reminderCount) {
                tenant.reminderCount = 0;
            }
            
            const reminderType = tenant.reminderCount >= 2 ? 'FINAL NOTICE' : `Reminder #${tenant.reminderCount + 1}`;
            const message = `Dear ${tenant.name}, your rent payment of Rs ${dueAmount} is pending. Please make the payment at your earliest convenience.${tenant.reminderCount >= 2 ? ' This is your final notice.' : ''}`;
            
            // Show SMS confirmation modal
            document.getElementById('smsConfirmContent').innerHTML = `
                <div class="space-y-3">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                            <span class="text-white">👤</span>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900 dark:text-white">${tenant.name}</p>
                            <p class="text-sm text-gray-600 dark:text-gray-300">ID: ${tenant.id} | Room: ${tenant.room}</p>
                            <p class="text-sm text-gray-600 dark:text-gray-300">Phone: ${tenant.phone}</p>
                        </div>
                    </div>
                    <div class="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-lg p-3">
                        <p class="text-sm text-red-800 dark:text-red-200">
                            <strong>Due Amount:</strong> ₹${dueAmount}
                        </p>
                        <p class="text-sm text-red-600 dark:text-red-300">
                            <strong>Reminder Type:</strong> ${reminderType}
                        </p>
                        <p class="text-xs text-red-500 dark:text-red-400">
                            Previous reminders sent: ${tenant.reminderCount}/3
                        </p>
                    </div>
                </div>
            `;
            
            document.getElementById('smsMessagePreview').textContent = message;
            
            // Store tenant ID for confirmation
            window.currentReminderTenantId = tenantId;
            
            document.getElementById('smsConfirmModal').classList.remove('hidden');
        }
        
        // Close SMS confirmation modal
        function closeSMSConfirmModal() {
            document.getElementById('smsConfirmModal').classList.add('hidden');
            window.currentReminderTenantId = null;
        }
        
        // Confirm send SMS
        function confirmSendSMS() {
            const tenantId = window.currentReminderTenantId;
            const tenant = tenants.find(t => t.id === tenantId);
            const dueAmount = calculateDueAmount(tenant);
            
            // Increment reminder count
            tenant.reminderCount++;
            
            // Add to reminder history
            if (!tenant.reminderHistory) {
                tenant.reminderHistory = [];
            }
            
            const reminderType = tenant.reminderCount >= 3 ? 'FINAL NOTICE' : `Reminder #${tenant.reminderCount}`;
            const message = document.getElementById('smsMessagePreview').textContent;
            
            const reminderRecord = {
                id: Date.now(),
                type: reminderType,
                message: message,
                amount: dueAmount,
                sentDate: new Date().toISOString().split('T')[0],
                sentTime: new Date().toLocaleTimeString(),
                phone: tenant.phone
            };
            
            tenant.reminderHistory.push(reminderRecord);
            
            // Save updated data
            localStorage.setItem('tenants', JSON.stringify(tenants));
            
            // Close modal
            closeSMSConfirmModal();
            
            // Show SMS notification
            showSMSNotification(tenant.name, tenant.phone, message, reminderType);
            
            // Reload reminders to update the display
            loadReminders();
        }
        
        // Show SMS notification
        function showSMSNotification(name, phone, message, type) {
            const notification = document.createElement('div');
            notification.className = 'sms-notification bg-white dark:bg-gray-800 border border-primary/20 dark:border-primary rounded-lg shadow-lg p-4';
            notification.innerHTML = `
                <div class="flex items-start space-x-3">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-primary/10 dark:bg-primary-dark rounded-full flex items-center justify-center">
                            <span class="text-primary dark:text-primary">📱</span>
                        </div>
                    </div>
                    <div class="flex-1">
                        <div class="flex items-center justify-between">
                            <h4 class="text-sm font-medium text-gray-900 dark:text-white">${type} Sent</h4>
                            <button onclick="this.parentElement.parentElement.parentElement.remove()" class="text-gray-400 hover:text-gray-600">
                                <span class="sr-only">Close</span>
                                <svg class="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                                </svg>
                            </button>
                        </div>
                        <p class="text-sm text-gray-600 dark:text-gray-300">To: ${name} (${phone})</p>
                        <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">${message.substring(0, 100)}...</p>
                        <p class="text-xs text-primary dark:text-primary mt-2">✓ SMS sent successfully</p>
                    </div>
                </div>
            `;
            
            document.body.appendChild(notification);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                if (notification.parentElement) {
                    notification.remove();
                }
            }, 5000);
        }

        // Payment tab management
        function showPaymentTab(tab) {
            // Hide all sections
            document.querySelectorAll('.payment-section').forEach(section => {
                section.classList.add('hidden');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.payment-tab').forEach(tabBtn => {
                tabBtn.classList.remove('border-blue-500', 'text-blue-600');
                tabBtn.classList.add('border-transparent', 'text-gray-500');
            });
            
            // Show selected section and activate tab
            if (tab === 'payment') {
                document.getElementById('paymentSection').classList.remove('hidden');
                document.getElementById('paymentTab').classList.remove('border-transparent', 'text-gray-500');
                document.getElementById('paymentTab').classList.add('border-blue-500', 'text-blue-600');
                document.getElementById('processPaymentBtn').classList.remove('hidden');
            } else {
                document.getElementById('billsSection').classList.remove('hidden');
                document.getElementById('billsTab').classList.remove('border-transparent', 'text-gray-500');
                document.getElementById('billsTab').classList.add('border-blue-500', 'text-blue-600');
                document.getElementById('processPaymentBtn').classList.add('hidden');
                loadCurrentBills(); // Make sure to load bills when switching to bills tab
            }
        }

        // Process payment
        function processPayment() {
            const tenant = tenants.find(t => t.id === currentTenantId);
            const paymentType = document.getElementById('paymentType').value;
            const amount = parseInt(document.getElementById('paymentAmount').value);
            const method = document.getElementById('paymentMethod').value;
            const notes = document.getElementById('paymentNotes').value;
            
            const payment = {
                id: Date.now(),
                type: paymentType,
                amount: amount,
                method: method,
                notes: notes,
                date: new Date().toISOString().split('T')[0],
                timestamp: new Date().toISOString()
            };
            
            if (!tenant.payments) {
                tenant.payments = [];
            }
            
            tenant.payments.push(payment);
            
            // Log admin activity
            logAdminActivity(tenant.id, `Payment of Rs ${amount} recorded for ${paymentType}`, 'payment');
            
            // If it's an other bill, mark it as paid
            if (paymentType !== 'rent' && tenant.otherBills) {
                const bill = tenant.otherBills.find(b => b.type === paymentType && !b.paid);
                if (bill) {
                    bill.paid = true;
                    bill.paidDate = new Date().toISOString().split('T')[0];
                    logAdminActivity(tenant.id, `Bill '${bill.description}' marked as paid`, 'bill');
                }
            }
            
            localStorage.setItem('tenants', JSON.stringify(tenants));
            
            // Notify tenant of payment update
            notifyTenantOfUpdate(tenant, `Payment of Rs ${amount} recorded for ${paymentType}`);
            
            customAlert('Payment updated successfully!', 'Success');
            closePaymentModal();
            loadTenants();
        }

        // Mark current month rent as unpaid
        function markAsUnpaid(tenantId) {
            customConfirm('Are you sure you want to mark this month\'s rent as unpaid? This will remove the payment record for the current month.', 'Confirm Unpaid Status', function() {
                markAsUnpaidConfirmed(tenantId);
            });
        }

        // Confirmed mark as unpaid
        function markAsUnpaidConfirmed(tenantId) {
            const tenant = tenants.find(t => t.id === tenantId);
            if (!tenant) return;
            
            // Get current month
            const now = new Date();
            const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
            
            // Find and remove current month rent payment
            const paymentIndex = tenant.payments?.findIndex(p => 
                p.date.startsWith(currentMonth) && p.type === 'rent'
            );
            
            if (paymentIndex !== -1 && paymentIndex !== undefined) {
                const paymentAmount = tenant.payments[paymentIndex].amount;
                tenant.payments.splice(paymentIndex, 1);
                localStorage.setItem('tenants', JSON.stringify(tenants));
                
                // Log admin activity
                logAdminActivity(tenantId, `Payment of Rs ${paymentAmount} reversed for current month rent`, 'reversal');
                
                // Notify tenant of payment reversal
                notifyTenantOfUpdate(tenant, `Payment of Rs ${paymentAmount} reversed for current month rent`);
                
                loadTenants();
                customAlert('Payment status successfully reverted to unpaid!', 'Success');
            } else {
                customAlert('No payment record found for current month.', 'Information');
            }
        }

        // Add other bill
        function addOtherBill() {
            const tenant = tenants.find(t => t.id === currentTenantId);
            const billType = document.getElementById('newBillType').value;
            const amount = parseInt(document.getElementById('newBillAmount').value);
            const description = document.getElementById('newBillDescription').value;
            const dueDate = document.getElementById('newBillDueDate').value;
            
            if (!amount || amount <= 0) {
                customAlert('Please enter a valid amount', 'Error');
                return;
            }
            
            if (!tenant.otherBills) {
                tenant.otherBills = [];
            }
            
            const newBill = {
                id: Date.now(),
                type: billType,
                amount: amount,
                description: description || `${billType.charAt(0).toUpperCase() + billType.slice(1)} bill`,
                dueDate: dueDate,
                paid: false,
                createdDate: new Date().toISOString().split('T')[0]
            };
            
            tenant.otherBills.push(newBill);
            
            // Log admin activity
            logAdminActivity(tenant.id, `New bill added: ${description || billType} - Rs ${amount}`, 'bill');
            
            localStorage.setItem('tenants', JSON.stringify(tenants));
            
            // Clear form
            document.getElementById('newBillAmount').value = '';
            document.getElementById('newBillDescription').value = '';
            document.getElementById('newBillDueDate').value = '';
            
            // Automatically update the tenant dashboard if the tenant is currently logged in
            updateTenantDashboardForBills(tenant.id);
            
            loadCurrentBills();
            customAlert('Bill added successfully!', 'Success');
        }

        // Mark bill as paid
        function markBillPaid(billId) {
            const tenant = tenants.find(t => t.id === currentTenantId);
            const bill = tenant.otherBills.find(b => b.id === billId);
            
            if (bill) {
                bill.paid = true;
                bill.paidDate = new Date().toISOString().split('T')[0];
                
                // Add to payment history
                const payment = {
                    id: Date.now(),
                    type: bill.type,
                    amount: bill.amount,
                    method: 'cash',
                    notes: `Payment for: ${bill.description}`,
                    date: new Date().toISOString().split('T')[0],
                    timestamp: new Date().toISOString()
                };
                
                if (!tenant.payments) {
                    tenant.payments = [];
                }
                tenant.payments.push(payment);
                
                // Log admin activity
                logAdminActivity(tenant.id, `Bill '${bill.description}' marked as paid - Rs ${bill.amount}`, 'bill');
                
                // Notify tenant of bill payment
                notifyTenantOfUpdate(tenant, `Bill '${bill.description}' marked as paid - Rs ${bill.amount}`);
                
                localStorage.setItem('tenants', JSON.stringify(tenants));
                
                // Automatically update the tenant dashboard
                updateTenantDashboardForBills(tenant.id);
                
                loadCurrentBills();
                customAlert('Bill marked as paid!', 'Success');
            }
        }

        // Mark bill as unpaid
        function markBillUnpaid(billId) {
            // Use the HTML version of customConfirm explicitly
            if (typeof customConfirm !== 'undefined' && document.getElementById('customConfirmModal')) {
                customConfirm('Are you sure you want to mark this bill as unpaid? This will reverse the payment record.', 'Confirm Unpaid Status', function() {
                    const tenant = tenants.find(t => t.id === currentTenantId);
                    const bill = tenant.otherBills.find(b => b.id === billId);
                    
                    if (bill) {
                        bill.paid = false;
                        bill.paidDate = null;
                        
                        // Remove from payment history
                        if (tenant.payments) {
                            tenant.payments = tenant.payments.filter(p => !(p.type === bill.type && p.amount === bill.amount && p.notes.includes(bill.description)));
                        }
                        
                        // Log admin activity
                        logAdminActivity(tenant.id, `Bill '${bill.description}' marked as unpaid - Rs ${bill.amount}`, 'bill');
                        
                        // Notify tenant of bill reversal
                        notifyTenantOfUpdate(tenant, `Bill '${bill.description}' marked as unpaid - Rs ${bill.amount}`);
                        
                        localStorage.setItem('tenants', JSON.stringify(tenants));
                        
                        // Automatically update the tenant dashboard
                        updateTenantDashboardForBills(tenant.id);
                        
                        loadCurrentBills();
                        customAlert('Bill marked as unpaid!', 'Success');
                    }
                });
            } else {
                // Fallback to the app.js version if HTML version is not available
                customConfirm('Are you sure you want to mark this bill as unpaid? This will reverse the payment record.', 'Confirm Unpaid Status', function() {
                    const tenant = tenants.find(t => t.id === currentTenantId);
                    const bill = tenant.otherBills.find(b => b.id === billId);
                    
                    if (bill) {
                        bill.paid = false;
                        bill.paidDate = null;
                        
                        // Remove from payment history
                        if (tenant.payments) {
                            tenant.payments = tenant.payments.filter(p => !(p.type === bill.type && p.amount === bill.amount && p.notes.includes(bill.description)));
                        }
                        
                        // Log admin activity
                        logAdminActivity(tenant.id, `Bill '${bill.description}' marked as unpaid - Rs ${bill.amount}`, 'bill');
                        
                        // Notify tenant of bill reversal
                        notifyTenantOfUpdate(tenant, `Bill '${bill.description}' marked as unpaid - Rs ${bill.amount}`);
                        
                        localStorage.setItem('tenants', JSON.stringify(tenants));
                        
                        // Automatically update the tenant dashboard
                        updateTenantDashboardForBills(tenant.id);
                        
                        loadCurrentBills();
                        customAlert('Bill marked as unpaid!', 'Success');
                    }
                });
            }
        }

        // Handle document uploads
        function handleDocumentUploads(tenant, files, callback) {
            if (!tenant.documents) {
                tenant.documents = [];
            }
            
            let processedCount = 0;
            const totalFiles = files.length;
            
            // If no files, still save and call callback if provided
            if (files.length === 0) {
                localStorage.setItem('tenants', JSON.stringify(tenants));
                if (callback && typeof callback === 'function') {
                    callback();
                }
                return;
            }
            
            // Process each file
            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    const document = {
                        id: 'doc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9), // Unique ID generation
                        name: file.name,
                        type: file.type,
                        size: file.size,
                        data: e.target.result,
                        uploadDate: new Date().toISOString()
                    };
                    
                    tenant.documents.push(document);
                    
                    // Log admin activity
                    logAdminActivity(tenant.id, `Document uploaded: ${file.name}`, 'document_upload');
                    
                    // Save after all files are processed
                    processedCount++;
                    if (processedCount === totalFiles) {
                        localStorage.setItem('tenants', JSON.stringify(tenants));
                        // Refresh the tenant data display if we're on the tenant dashboard
                        if (currentUser && currentUser.role === 'tenant' && currentUser.data.id === tenant.id) {
                            loadTenantData();
                        }
                        // Call callback if provided
                        if (callback && typeof callback === 'function') {
                            callback();
                        }
                    }
                };
                
                reader.onerror = function(error) {
                    console.error('Error reading file:', file.name, error);
                    // Still increment processed count to ensure save happens even if some files fail
                    processedCount++;
                    if (processedCount === totalFiles) {
                        localStorage.setItem('tenants', JSON.stringify(tenants));
                        // Refresh the tenant data display if we're on the tenant dashboard
                        if (currentUser && currentUser.role === 'tenant' && currentUser.data.id === tenant.id) {
                            loadTenantData();
                        }
                        // Call callback if provided
                        if (callback && typeof callback === 'function') {
                            callback();
                        }
                    }
                };
                
                reader.readAsDataURL(file);
            }
        }

        // Delete bill
        function deleteBill(billId) {
            // Use the HTML version of customConfirm explicitly
            if (typeof customConfirm !== 'undefined' && document.getElementById('customConfirmModal')) {
                customConfirm('Are you sure you want to delete this bill?', 'Confirm Delete Bill', function() {
                    const tenant = tenants.find(t => t.id === currentTenantId);
                    const bill = tenant.otherBills.find(b => b.id === billId);
                    
                    if (bill) {
                        // Log admin activity before deletion
                        logAdminActivity(tenant.id, `Bill '${bill.description}' deleted - Rs ${bill.amount}`, 'bill');
                        
                        // Notify tenant of bill deletion
                        notifyTenantOfUpdate(tenant, `Bill '${bill.description}' deleted - Rs ${bill.amount}`);
                        
                        tenant.otherBills = tenant.otherBills.filter(b => b.id !== billId);
                        localStorage.setItem('tenants', JSON.stringify(tenants));
                        
                        // Automatically update the tenant dashboard
                        updateTenantDashboardForBills(tenant.id);
                        
                        loadCurrentBills();
                        customAlert('Bill deleted successfully!', 'Success');
                    }
                });
            } else {
                // Fallback to the app.js version if HTML version is not available
                customConfirm('Are you sure you want to delete this bill?', 'Confirm Delete Bill', function() {
                    const tenant = tenants.find(t => t.id === currentTenantId);
                    const bill = tenant.otherBills.find(b => b.id === billId);
                    
                    if (bill) {
                        // Log admin activity before deletion
                        logAdminActivity(tenant.id, `Bill '${bill.description}' deleted - Rs ${bill.amount}`, 'bill');
                        
                        // Notify tenant of bill deletion
                        notifyTenantOfUpdate(tenant, `Bill '${bill.description}' deleted - Rs ${bill.amount}`);
                        
                        tenant.otherBills = tenant.otherBills.filter(b => b.id !== billId);
                        localStorage.setItem('tenants', JSON.stringify(tenants));
                        
                        // Automatically update the tenant dashboard
                        updateTenantDashboardForBills(tenant.id);
                        
                        loadCurrentBills();
                        customAlert('Bill deleted successfully!', 'Success');
                    }
                });
            }
        }

        // Load current bills
        function loadCurrentBills() {
            const tenant = tenants.find(t => t.id === currentTenantId);
            const billsList = document.getElementById('currentBillsList');
            billsList.innerHTML = '';
            
            if (!tenant.otherBills || tenant.otherBills.length === 0) {
                billsList.innerHTML = '<p class="text-gray-500 text-center py-4">No bills added yet</p>';
                return;
            }
            
            tenant.otherBills.forEach(bill => {
                const billCard = document.createElement('div');
                const isPaid = bill.paid;
                const isOverdue = !isPaid && bill.dueDate && new Date(bill.dueDate) < new Date();
                
                billCard.className = `border rounded-lg p-3 ${isPaid ? 'bg-primary/5 border-primary/20 dark:bg-primary-dark/20 dark:border-primary' : isOverdue ? 'bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-700' : 'bg-gray-50 border-gray-200 dark:bg-gray-700 dark:border-gray-600'}`;
                billCard.innerHTML = `
                    <div class="flex justify-between items-center">
                        <div>
                            <h5 class="font-medium text-gray-900 dark:text-white">${bill.description}</h5>
                            <p class="text-sm text-gray-600 dark:text-gray-300">Type: ${bill.type.charAt(0).toUpperCase() + bill.type.slice(1)}</p>
                            <p class="text-sm text-gray-600 dark:text-gray-300">Amount: ₹${bill.amount}</p>
                            ${bill.dueDate ? `<p class="text-sm text-gray-600 dark:text-gray-300">Due: ${bill.dueDate}</p>` : ''}
                            <p class="text-xs ${isPaid ? 'text-primary dark:text-primary' : isOverdue ? 'text-red-600 dark:text-red-400' : 'text-yellow-600 dark:text-yellow-400'}">
                                ${isPaid ? '✅ Paid' : isOverdue ? '🚨 Overdue' : '⏳ Pending'}
                            </p>
                        </div>
                        <div class="flex space-x-2">
                            ${!isPaid ? `<button onclick="markBillPaid(${bill.id})" class="bg-primary text-white px-2 py-1 rounded text-xs hover:bg-primary-dark dark:bg-primary-dark dark:hover:bg-primary">Mark Paid</button>` : `<button onclick="markBillUnpaid(${bill.id})" class="bg-yellow-600 text-white px-2 py-1 rounded text-xs hover:bg-yellow-700 dark:bg-yellow-700 dark:hover:bg-yellow-800">Mark Unpaid</button>`}
                            <button onclick="deleteBill(${bill.id})" class="bg-red-600 text-white px-2 py-1 rounded text-xs hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-800">Delete</button>
                        </div>
                    </div>
                `;
                billsList.appendChild(billCard);
            });
        }

        // Log admin activity
        function logAdminActivity(tenantId, action, type) {
            const tenant = tenants.find(t => t.id === tenantId);
            if (!tenant) return;
            
            if (!tenant.adminActivity) {
                tenant.adminActivity = [];
            }
            
            const activity = {
                id: Date.now(),
                timestamp: new Date().toISOString(),
                date: new Date().toISOString().split('T')[0],
                time: new Date().toLocaleTimeString(),
                action: action,
                type: type,
                admin: currentUser?.username || 'Admin'
            };
            
            tenant.adminActivity.push(activity);
        }
        
        // Get tenant ID for localStorage keys
        function getTenantId() {
            if (typeof currentUser !== 'undefined' && currentUser && currentUser.data && currentUser.data.id) {
                return currentUser.data.id;
            }
            return 'unknown';
        }
        
        // Load last seen timestamps from localStorage
        function loadLastSeenTimestamps() {
            const tenantId = getTenantId();
            const timestamps = localStorage.getItem(`tenant_${tenantId}_lastSeen`);
            return timestamps ? JSON.parse(timestamps) : {
                payments: 0,
                notifications: 0,
                activities: 0
            };
        }
        
        // Save last seen timestamps to localStorage
        function saveLastSeenTimestamps(timestamps) {
            const tenantId = getTenantId();
            localStorage.setItem(`tenant_${tenantId}_lastSeen`, JSON.stringify(timestamps));
        }
        
        // Increment unread counts for sections with new data
        function incrementUnreadCountsForNewData(tenant) {
            const lastSeen = loadLastSeenTimestamps();
            const now = Date.now();
            
            // Check for new payments
            if (tenant.payments && tenant.payments.length > 0) {
                // Find the latest payment timestamp
                const latestPayment = tenant.payments.reduce((latest, payment) => {
                    const paymentTime = new Date(payment.date).getTime();
                    return paymentTime > latest ? paymentTime : latest;
                }, 0);
                
                // If there's a new payment since last seen, increment count
                if (latestPayment > lastSeen.payments) {
                    if (typeof incrementUnreadCount === 'function') {
                        incrementUnreadCount('payments');
                    }
                }
            }
            
            // Check for new notifications
            if (tenant.notifications && tenant.notifications.length > 0) {
                // Find the latest notification timestamp
                const latestNotification = tenant.notifications.reduce((latest, notification) => {
                    const notificationTime = new Date(notification.date + 'T' + (notification.time || '00:00:00')).getTime();
                    return notificationTime > latest ? notificationTime : latest;
                }, 0);
                
                // If there's a new notification since last seen, increment count
                if (latestNotification > lastSeen.notifications) {
                    if (typeof incrementUnreadCount === 'function') {
                        incrementUnreadCount('notifications');
                    }
                }
            }
            
            // Check for new admin activities
            if (tenant.adminActivity && tenant.adminActivity.length > 0) {
                // Find the latest activity timestamp
                const latestActivity = tenant.adminActivity.reduce((latest, activity) => {
                    const activityTime = new Date(activity.timestamp).getTime();
                    return activityTime > latest ? activityTime : latest;
                }, 0);
                
                // If there's a new activity since last seen, increment count
                if (latestActivity > lastSeen.activities) {
                    if (typeof incrementUnreadCount === 'function') {
                        incrementUnreadCount('activities');
                    }
                }
            }
            
            // Update last seen timestamps
            saveLastSeenTimestamps({
                payments: now,
                notifications: now,
                activities: now
            });
        }
        
        // Clean up encoding issues in existing data
        function cleanUpEncodingIssues() {
            // Clean up admin activities in tenants
            tenants.forEach(tenant => {
                if (tenant.adminActivity && tenant.adminActivity.length > 0) {
                    tenant.adminActivity.forEach(activity => {
                        if (activity.action) {
                            // Fix currency symbol encoding issues
                            activity.action = activity.action.replace(/â¹/g, 'Rs').replace(/¹/g, 'Rs').replace(/â¹/g, 'Rs').replace(/[â¹¹]/g, 'Rs');
                        }
                    });
                }
            });
            
            // Clean up admin activities in deleted tenants
            if (deletedTenants && deletedTenants.length > 0) {
                deletedTenants.forEach(tenant => {
                    if (tenant.adminActivity && tenant.adminActivity.length > 0) {
                        tenant.adminActivity.forEach(activity => {
                            if (activity.action) {
                                // Fix currency symbol encoding issues
                                activity.action = activity.action.replace(/â¹/g, 'Rs').replace(/¹/g, 'Rs').replace(/â¹/g, 'Rs').replace(/[â¹¹]/g, 'Rs');
                            }
                        });
                    }
                });
            }
            
            // Save cleaned data back to localStorage
            localStorage.setItem('tenants', JSON.stringify(tenants));
            localStorage.setItem('deletedTenants', JSON.stringify(deletedTenants));
        }

        // Load tenant data
        function loadTenantData() {
            const tenant = currentUser.data;
            document.getElementById('tenantWelcome').textContent = `Welcome, ${tenant.name}`;
            
            // Increment unread counts for sections with new data
            incrementUnreadCountsForNewData(tenant);
            
            // Load current status
            const statusDiv = document.getElementById('tenantStatus');
            const dueAmount = calculateDueAmount(tenant);
            
            // Check if tenant is new (joined this month)
            const currentDate = new Date();
            const joinDate = new Date(tenant.joinDate);
            const isNewTenant = (currentDate.getFullYear() === joinDate.getFullYear() && 
                               currentDate.getMonth() === joinDate.getMonth());
            
            // Check if current month rent is paid
            const currMonth = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;
            const currMonthPayment = tenant.payments?.find(p => 
                p.date.startsWith(currMonth) && p.type === 'rent'
            );
            const isCurrMonthPaid = !!currMonthPayment;
            
            // Check if current tenant is deleted
            const currentDeletedTenants = JSON.parse(localStorage.getItem('deletedTenants')) || [];
            const isTenantDeleted = currentDeletedTenants.some(t => t.id === tenant.id);
            
            // Determine display status
            let displayStatus, displayClass, displayText;
            if (isNewTenant && !isCurrMonthPaid) {
                // New tenants without payment should show as PENDING
                displayStatus = 'pending';
                displayClass = 'from-yellow-300 to-yellow-400 dark:from-yellow-700/30 dark:to-yellow-600/30';
                displayText = 'New Tenant - Payment Pending';
            } else if (dueAmount > 0) {
                displayStatus = 'due';
                displayClass = 'from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20';
                displayText = `₹${dueAmount} Due`;
            } else {
                displayStatus = 'paid';
                displayClass = 'from-primary/5 to-primary/10 dark:from-primary-dark/20 dark:to-primary/20';
                displayText = 'All Paid ✅';
            }
            
            statusDiv.innerHTML = `
                <div class="space-y-3">
                    <div class="flex items-center space-x-2">
                        <div class="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center ${isTenantDeleted ? 'deleted-tenant-profile-icon' : 'tenant-profile-icon'}">
                            <span class="text-blue-600 dark:text-blue-400">👤</span>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900 dark:text-white">${tenant.name}</p>
                            <p class="text-sm text-gray-500 dark:text-gray-400">ID: ${tenant.id}</p>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
                            <p class="text-sm text-gray-600 dark:text-gray-300">Room</p>
                            <p class="font-semibold text-gray-900 dark:text-white">${tenant.room}</p>
                        </div>
                        <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
                            <p class="text-sm text-gray-600 dark:text-gray-300">Monthly Rent</p>
                            <p class="font-semibold text-gray-900 dark:text-white">₹${tenant.rent}</p>
                        </div>
                    </div>
                    
                    <div class="bg-gradient-to-r ${displayClass} rounded-lg p-4">
                        <p class="text-sm font-medium ${displayStatus === 'due' ? 'text-red-800 dark:text-red-200' : displayStatus === 'paid' ? 'text-primary dark:text-primary' : 'text-gray-900 dark:text-yellow-200'}">Payment Status</p>
                        <p class="text-lg font-bold ${displayStatus === 'due' ? 'text-red-600 dark:text-red-400' : displayStatus === 'paid' ? 'text-primary dark:text-primary' : 'text-gray-900 dark:text-yellow-300'}">
                            ${displayText}
                        </p>
                    </div>
                    
                    <div class="text-sm text-gray-600 dark:text-gray-300">
                        <p><strong>Join Date:</strong> ${tenant.joinDate}</p>
                        <p><strong>Phone:</strong> ${tenant.phone}</p>
                        ${tenant.reminderCount ? `<p><strong>Reminders Sent:</strong> ${tenant.reminderCount}/3</p>` : ''}
                    </div>
                </div>
            `;
            
            // Load payment history
            const historyDiv = document.getElementById('tenantPaymentHistory');
            historyDiv.innerHTML = '';
            
            // Load notifications
            const notificationsDiv = document.getElementById('tenantNotifications');
            if (notificationsDiv) {
                notificationsDiv.innerHTML = '';
            }
            
            // Load admin activities
            const activitiesDiv = document.getElementById('tenantActivities');
            if (activitiesDiv) {
                activitiesDiv.innerHTML = '';
            }
            
            // Add notifications section
            if (tenant.notifications && tenant.notifications.length > 0) {
                if (notificationsDiv) {
                    notificationsDiv.innerHTML = `
                        <div class="space-y-3">
                            ${tenant.notifications.slice(-5).reverse().map(notification => `
                                <div class="border border-purple-400 dark:border-purple-500 bg-purple-200 dark:bg-purple-800/40 rounded-lg p-3 relative">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <p class="font-medium text-purple-950 dark:text-purple-50">${notification.message}</p>
                                            <p class="text-xs text-purple-800 dark:text-purple-100">${notification.date} at ${notification.time}</p>
                                        </div>
                                        <span class="text-purple-800 dark:text-purple-100 font-bold">🔔</span>
                                    </div>
                                    ${!notification.read ? '<span class="absolute top-2 right-2 w-3 h-3 bg-red-500 rounded-full"></span>' : ''}
                                </div>
                            `).join('')}
                        </div>
                    `;
                } else {
                    const notificationSection = document.createElement('div');
                    notificationSection.className = 'mb-6';
                    notificationSection.innerHTML = `
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-3">🔔 Notifications</h3>
                        <div class="space-y-2">
                            ${tenant.notifications.slice(-5).reverse().map(notification => `
                                <div class="border border-purple-400 dark:border-purple-500 bg-purple-200 dark:bg-purple-800/40 rounded-lg p-3 relative">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <p class="font-medium text-purple-950 dark:text-purple-50">${notification.message}</p>
                                            <p class="text-xs text-purple-800 dark:text-purple-100">${notification.date} at ${notification.time}</p>
                                        </div>
                                        <span class="text-purple-800 dark:text-purple-100 font-bold">🔔</span>
                                    </div>
                                    ${!notification.read ? '<span class="absolute top-2 right-2 w-3 h-3 bg-red-500 rounded-full"></span>' : ''}
                                </div>
                            `).join('')}
                        </div>
                    `;
                    historyDiv.appendChild(notificationSection);
                }
            } else if (notificationsDiv) {
                notificationsDiv.innerHTML = '<p class="text-gray-500 dark:text-gray-400 text-center py-8 bg-gray-50 dark:bg-gray-700 rounded-lg">No notifications yet</p>';
            }
            
            // Add reminder history section
            if (tenant.reminderHistory && tenant.reminderHistory.length > 0) {
                const reminderSection = document.createElement('div');
                reminderSection.className = 'mb-6';
                reminderSection.innerHTML = `
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-3">📱 SMS Reminders Received</h3>
                    <div class="space-y-2">
                        ${tenant.reminderHistory.slice(-3).reverse().map(reminder => `
                            <div class="border border-orange-200 dark:border-orange-700 bg-orange-50 dark:bg-orange-900/20 rounded-lg p-3">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <p class="font-medium text-orange-800 dark:text-orange-200">${reminder.type}</p>
                                        <p class="text-sm text-orange-600 dark:text-orange-300">Amount: ₹${reminder.amount}</p>
                                        <p class="text-xs text-orange-500 dark:text-orange-400">${reminder.sentDate} at ${reminder.sentTime}</p>
                                    </div>
                                    <span class="text-orange-600 dark:text-orange-400">📱</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                `;
                historyDiv.appendChild(reminderSection);
            }
            
            // Add admin activity section
            if (tenant.adminActivity && tenant.adminActivity.length > 0) {
                if (activitiesDiv) {
                    activitiesDiv.innerHTML = `
                        <div class="space-y-3">
                            ${tenant.adminActivity.slice(-5).reverse().map(activity => `
                                <div class="border border-blue-400 dark:border-blue-500 bg-blue-200 dark:bg-blue-800/40 rounded-lg p-3 relative">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <p class="font-medium text-blue-950 dark:text-blue-50">${activity.action}</p>
                                            <p class="text-xs text-blue-800 dark:text-blue-100">${activity.date} at ${activity.time}</p>
                                        </div>
                                        <span class="text-blue-800 dark:text-blue-100 font-bold">
                                            ${activity.type === 'payment' ? '💰' : activity.type === 'bill' ? '📋' : activity.type === 'reversal' ? '↩️' : '📋'}
                                        </span>
                                    </div>
                                    <span class="absolute top-2 right-2 w-3 h-3 bg-red-500 rounded-full"></span>
                                </div>
                            `).join('')}
                        </div>
                    `;
                } else {
                    const activitySection = document.createElement('div');
                    activitySection.className = 'mb-6';
                    activitySection.innerHTML = `
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-3">📋 Admin Activities</h3>
                        <div class="space-y-2">
                            ${tenant.adminActivity.slice(-5).reverse().map(activity => `
                                <div class="border border-blue-400 dark:border-blue-500 bg-blue-200 dark:bg-blue-800/40 rounded-lg p-3 relative">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <p class="font-medium text-blue-950 dark:text-blue-50">${activity.action}</p>
                                            <p class="text-xs text-blue-800 dark:text-blue-100">${activity.date} at ${activity.time}</p>
                                        </div>
                                        <span class="text-blue-800 dark:text-blue-100 font-bold">
                                            ${activity.type === 'payment' ? '💰' : activity.type === 'bill' ? '📋' : activity.type === 'reversal' ? '↩️' : '📋'}
                                        </span>
                                    </div>
                                    <span class="absolute top-2 right-2 w-3 h-3 bg-red-500 rounded-full"></span>
                                </div>
                            `).join('')}
                        </div>
                    `;
                    historyDiv.appendChild(activitySection);
                }
            } else if (activitiesDiv) {
                activitiesDiv.innerHTML = '<p class="text-gray-500 dark:text-gray-400 text-center py-8 bg-gray-50 dark:bg-gray-700 rounded-lg">No admin activities yet</p>';
            }
            
            // Add payment history section
            if (tenant.payments && tenant.payments.length > 0) {
                const paymentsContainer = document.createElement('div');
                paymentsContainer.className = 'space-y-3';
                
                tenant.payments.sort((a, b) => new Date(b.date) - new Date(a.date)).forEach(payment => {
                    const paymentCard = document.createElement('div');
                    paymentCard.className = 'border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 rounded-lg p-3 card-hover relative';
                    paymentCard.innerHTML = `
                        <div class="flex justify-between items-center">
                            <div>
                                <div class="flex items-center space-x-2">
                                    <span class="w-2 h-2 bg-primary rounded-full"></span>
                                    <p class="font-medium text-gray-900 dark:text-white">${payment.type.charAt(0).toUpperCase() + payment.type.slice(1)}</p>
                                </div>
                                <p class="text-sm text-gray-600 dark:text-gray-300">${payment.date}</p>
                                ${payment.notes ? `<p class="text-sm text-gray-500 dark:text-gray-400">${payment.notes}</p>` : ''}
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-primary dark:text-primary">₹${payment.amount}</p>
                                <p class="text-sm text-gray-500 dark:text-gray-400">${payment.method}</p>
                            </div>
                        </div>
                        <span class="absolute top-2 right-2 w-3 h-3 bg-red-500 rounded-full"></span>
                    `;
                    paymentsContainer.appendChild(paymentCard);
                });
                
                historyDiv.appendChild(paymentsContainer);
            } else {
                const noPayments = document.createElement('p');
                noPayments.className = 'text-gray-500 dark:text-gray-400 text-center py-8 bg-gray-50 dark:bg-gray-700 rounded-lg';
                noPayments.textContent = 'No payment history yet';
                historyDiv.appendChild(noPayments);
            }
            
            // Add documents section
            if (tenant.documents && tenant.documents.length > 0) {
                const documentsSection = document.createElement('div');
                documentsSection.className = 'mb-6';
                documentsSection.innerHTML = `
                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-3">📄 Uploaded Documents</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        ${tenant.documents.map(doc => `
                            <div class="border border-gray-200 dark:border-gray-600 rounded-lg p-3 bg-white dark:bg-gray-700">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <p class="font-medium text-gray-900 dark:text-white">${doc.name}</p>
                                        <p class="text-xs text-gray-600 dark:text-gray-300">${doc.type} • ${new Date(doc.uploadDate).toLocaleDateString()}</p>
                                    </div>
                                    ${doc.type.startsWith('image/') ? 
                                        `<button onclick="viewDocument('${doc.data}')" class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 text-sm">
                                            👁️ View
                                        </button>` : 
                                        `<a href="${doc.data}" target="_blank" class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 text-sm">
                                            👁️ View
                                        </a>`}
                                </div>
                                ${doc.type.startsWith('image/') ? 
                                    `<img src="${doc.data}" alt="${doc.name}" class="mt-2 max-h-32 object-contain rounded">` : ''}
                            </div>
                        `).join('')}
                    </div>
                `;
                historyDiv.appendChild(documentsSection);
            }
            
            // Load other bills section
            const otherBillsDiv = document.getElementById('tenantOtherBills');
            if (otherBillsDiv) {
                otherBillsDiv.innerHTML = '';
                
                // Add pending bills section
                if (tenant.otherBills && tenant.otherBills.filter(b => !b.paid).length > 0) {
                    const pendingBillsSection = document.createElement('div');
                    pendingBillsSection.className = 'mb-6';
                    pendingBillsSection.innerHTML = `
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-3">⏳ Pending Bills</h3>
                        <div class="space-y-3">
                            ${tenant.otherBills.filter(b => !b.paid).map(bill => {
                                const isOverdue = bill.dueDate && new Date(bill.dueDate) < new Date();
                                return `
                                    <div class="border ${isOverdue ? 'border-red-200 dark:border-red-700 bg-red-50 dark:bg-red-900/20' : 'border-yellow-500 dark:border-yellow-700 bg-yellow-300 dark:bg-yellow-900/20'} rounded-lg p-3">
                                        <div class="flex justify-between items-center">
                                            <div>
                                                <p class="font-medium ${isOverdue ? 'text-gray-900' : 'text-gray-900'} dark:text-white">${bill.description}</p>
                                                <p class="font-medium ${isOverdue ? 'text-gray-900' : 'text-gray-900'} dark:text-white">Due: ${bill.dueDate || 'N/A'}</p>
                                            </div>
                                            <div class="text-right">
                                                <p class="font-bold ${isOverdue ? 'text-red-600 dark:text-red-400' : 'text-gray-900 dark:text-yellow-400'}">₹${bill.amount}</p>
                                                ${isOverdue ? '<span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full">OVERDUE</span>' : '<span class="text-xs bg-yellow-300 text-gray-900 px-2 py-1 rounded-full">PENDING</span>'}
                                            </div>
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    `;
                    otherBillsDiv.appendChild(pendingBillsSection);
                }
                
                // Add paid bills section
                if (tenant.otherBills && tenant.otherBills.filter(b => b.paid).length > 0) {
                    const paidBillsSection = document.createElement('div');
                    paidBillsSection.className = 'mb-6';
                    paidBillsSection.innerHTML = `
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-3">✅ Paid Bills</h3>
                        <div class="space-y-3">
                            ${tenant.otherBills.filter(b => b.paid).map(bill => `
                                <div class="border border-primary/20 dark:border-primary bg-primary/5 dark:bg-primary-dark/20 rounded-lg p-3">
                                    <div class="flex justify-between items-center">
                                        <div>
                                            <p class="font-medium text-gray-900 dark:text-white">${bill.description}</p>
                                            <p class="text-sm text-gray-600 dark:text-gray-300">Paid: ${bill.paidDate || 'N/A'}</p>
                                        </div>
                                        <div class="text-right">
                                            <p class="font-bold text-primary dark:text-primary">₹${bill.amount}</p>
                                            <span class="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">PAID</span>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    `;
                    otherBillsDiv.appendChild(paidBillsSection);
                }
                
                // Show message if no bills
                if (!tenant.otherBills || tenant.otherBills.length === 0) {
                    const noBillsMessage = document.createElement('p');
                    noBillsMessage.className = 'text-gray-500 dark:text-gray-400 text-center py-8 bg-gray-50 dark:bg-gray-700 rounded-lg';
                    noBillsMessage.textContent = 'No other bills yet';
                    otherBillsDiv.appendChild(noBillsMessage);
                }
            }
            
            // Trigger animations for tenant dashboard sections
            setTimeout(() => {
                const tenantNavButtons = document.getElementById('tenantNavButtons');
                const tenantDashboardSection = document.getElementById('tenantDashboardSection');
                const tenantPaymentsSection = document.getElementById('tenantPaymentsSection');
                const tenantNotificationsSection = document.getElementById('tenantNotificationsSection');
                const tenantActivitiesSection = document.getElementById('tenantActivitiesSection');
                
                if (tenantNavButtons) {
                    tenantNavButtons.classList.add('animate');
                }
                
                if (tenantDashboardSection) {
                    tenantDashboardSection.classList.add('animate');
                }
                
                // Trigger animations for currently visible section
                if (!tenantPaymentsSection.classList.contains('hidden')) {
                    tenantPaymentsSection.classList.add('animate');
                }
                
                if (!tenantNotificationsSection.classList.contains('hidden')) {
                    tenantNotificationsSection.classList.add('animate');
                }
                
                if (!tenantActivitiesSection.classList.contains('hidden')) {
                    tenantActivitiesSection.classList.add('animate');
                }
            }, 100);
        }

        // View document
        function viewDocument(dataUrl) {
            // Create a modal to view the document
            const modal = document.createElement('div');
            modal.id = 'documentViewModal';
            modal.className = 'fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4';
            modal.innerHTML = `
                <div class="relative w-full max-w-6xl max-h-full flex flex-col">
                    <div class="flex justify-between items-center mb-4 bg-gray-800 text-white p-4 rounded-t-lg">
                        <h3 class="text-lg font-semibold">Document Preview</h3>
                        <button type="button" onclick="closeDocumentViewModal()" class="text-gray-300 hover:text-white">
                            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                    <div class="flex-1 flex items-center justify-center bg-black overflow-auto rounded-b-lg">
                        <img src="${dataUrl}" alt="Document Preview" class="max-w-full max-h-[80vh] object-contain">
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            // Close modal when clicking outside the image
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closeDocumentViewModal();
                }
            });
        }

        // Close document view modal
        function closeDocumentViewModal() {
            const modal = document.getElementById('documentViewModal');
            if (modal) {
                modal.remove();
            }
        }

        // Download tenant report
        function downloadTenantReport() {
            const tenant = currentUser.data;
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Get website colors
            const primaryColor = [0, 119, 182]; // #0077b6
            const primaryDarkColor = [2, 62, 138]; // #023e8a
            const secondaryColor = [0, 150, 199]; // #0096c7
            const lightBackgroundColor = [229, 221, 213]; // #E5DDD5
            
            // Header
            doc.setFontSize(22);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(...primaryColor);
            doc.text('TENANT PROFILE REPORT', 20, 20);
            
            doc.setFontSize(12);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(0, 0, 0);
            doc.text(`Generated on: ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`, 20, 30);
            
            // Tenant Information Section
            let y = 45;
            doc.setFontSize(16);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(...primaryColor);
            doc.text(`Tenant: ${tenant.name} (${tenant.id})`, 20, y);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(0, 0, 0);
            y += 10;
            
            doc.setFillColor(...primaryColor);
            doc.setDrawColor(...primaryColor);
            doc.setTextColor(255, 255, 255);
            doc.rect(15, y, 180, 40, 'F');            
            doc.setFontSize(12);
            doc.text(`Name: ${tenant.name}`, 20, y + 8);
            doc.text(`ID: ${tenant.id}`, 20, y + 16);
            doc.text(`Room: ${tenant.room}`, 20, y + 24);
            doc.text(`Phone: ${tenant.phone || 'N/A'}`, 20, y + 32);
            
            doc.text(`Monthly Rent: Rs ${tenant.rent.toLocaleString()}`, 120, y + 8);
            doc.text(`Join Date: ${tenant.joinDate}`, 120, y + 16);
            if (tenant.securityDeposit) {
                doc.text(`Security Deposit: Rs ${tenant.securityDeposit.toLocaleString()}`, 120, y + 24);
            }
            
            // Calculate and display due amount
            const dueAmount = calculateDueAmount(tenant);
            if (dueAmount > 0) {
                doc.text(`Outstanding Due: Rs ${dueAmount.toLocaleString()}`, 20, y + 48);
            }
            
            // Add payment status summary
            const now = new Date();
            const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
            const currentMonthPayment = tenant.payments?.find(p => 
                p.date.startsWith(currentMonth) && p.type === 'rent'
            );
            const isCurrentMonthPaid = !!currentMonthPayment;
            
            doc.text(`Current Month Status: ${isCurrentMonthPaid ? 'Paid' : 'Unpaid'}`, 120, y + 48);
            if (tenant.reminderCount > 0) {
                doc.text(`Reminders Sent: ${tenant.reminderCount}/3`, 20, y + 56);
            }
            
            // Add unpaid months information
            const unpaidMonths = getUnpaidMonths(tenant);
            if (unpaidMonths.length > 0) {
                doc.text(`Unpaid Months: ${unpaidMonths.join(', ')}`, 20, y + 64);
            }
            
            y += 80;
            
            // Payment History Section
            doc.setFontSize(14);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(...primaryColor);
            doc.text('Payment History:', 20, y);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(0, 0, 0);
            y += 15;
            
            if (tenant.payments && tenant.payments.length > 0) {
                // Table headers with better formatting
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Date', 20, y);
                doc.text('Type', 50, y);
                doc.text('Amount (Rs)', 100, y, null, null, 'right');
                doc.text('Method', 130, y);
                doc.text('Notes', 160, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                // Sort payments by date (newest first)
                const sortedPayments = [...tenant.payments].sort((a, b) => new Date(b.date) - new Date(a.date));
                
                // Table data with better alignment
                sortedPayments.forEach((payment, index) => {
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, 8, 'F');
                    }
                    
                    doc.text(payment.date, 20, y);
                    doc.text(payment.type.charAt(0).toUpperCase() + payment.type.slice(1), 50, y);
                    doc.text(payment.amount.toLocaleString(), 100, y, null, null, 'right');
                    doc.text(payment.method, 130, y);
                    doc.text((payment.notes || '').substring(0, 20), 160, y);
                    
                    y += 8;
                    
                    // Check if we need a new page
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Date', 20, y);
                        doc.text('Type', 50, y);
                        doc.text('Amount (Rs)', 100, y, null, null, 'right');
                        doc.text('Method', 130, y);
                        doc.text('Notes', 160, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                    }
                });
                
                // Summary section
                y += 15;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Payment Summary:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 10;
                
                doc.line(20, y, 195, y);
                y += 10;
                
                const totalPaid = tenant.payments.reduce((sum, p) => sum + p.amount, 0);
                const rentPayments = tenant.payments.filter(p => p.type === 'rent');
                const otherPayments = tenant.payments.filter(p => p.type !== 'rent');
                
                doc.setFontSize(12);
                doc.text(`Total Payments Made:`, 20, y);
                doc.text(`Rs ${totalPaid.toLocaleString()}`, 195, y, null, null, 'right');
                y += 10;
                
                doc.text(`Rent Payments:`, 20, y);
                doc.text(`${rentPayments.length} (Rs ${rentPayments.reduce((sum, p) => sum + p.amount, 0).toLocaleString()})`, 195, y, null, null, 'right');
                y += 10;
                
                doc.text(`Other Payments:`, 20, y);
                doc.text(`${otherPayments.length} (Rs ${otherPayments.reduce((sum, p) => sum + p.amount, 0).toLocaleString()})`, 195, y, null, null, 'right');
                
            } else {
                doc.setFontSize(12);
                doc.text('No payment history available', 20, y);
            }
            
            // Other Bills Section
            if (tenant.otherBills && tenant.otherBills.length > 0) {
                y += 30;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Other Bills:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 15;
                
                // Table headers
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Type', 20, y);
                doc.text('Description', 50, y);
                doc.text('Amount (Rs)', 100, y, null, null, 'right');
                doc.text('Status', 130, y);
                doc.text('Due Date', 160, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                // Table data
                tenant.otherBills.forEach((bill, index) => {
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, 8, 'F');
                    }
                    
                    doc.text(bill.type, 20, y);
                    doc.text(bill.description.substring(0, 20), 50, y);
                    doc.text(bill.amount.toLocaleString(), 100, y, null, null, 'right');
                    doc.text(bill.paid ? 'Paid' : 'Pending', 130, y);
                    doc.text(bill.dueDate || 'N/A', 160, y);
                    
                    y += 8;
                    
                    // Check if we need a new page
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Type', 20, y);
                        doc.text('Description', 50, y);
                        doc.text('Amount (Rs)', 100, y, null, null, 'right');
                        doc.text('Status', 130, y);
                        doc.text('Due Date', 160, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                    }
                });
            }
            
            // Admin Activity Section
            if (tenant.adminActivity && tenant.adminActivity.length > 0) {
                y += 30;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Admin Activities:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 15;
                
                // Table headers for admin activities
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Date & Time', 20, y);
                doc.text('Activity', 60, y);
                doc.text('Type', 160, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                // Sort activities by timestamp (newest first)
                const sortedActivities = [...tenant.adminActivity].sort((a, b) => 
                    new Date(b.timestamp) - new Date(a.timestamp)
                );
                
                // List admin activities in a table format
                sortedActivities.forEach((activity, index) => {
                    // Calculate row height based on content
                    let actionText = activity.action;
                    // Remove any accidental duplication in the action text
                    if (actionText.includes('Payment') && actionText.endsWith('Payment')) {
                        actionText = actionText.replace(/ Payment$/, '');
                    }
                    
                    // Fix currency symbol encoding issues
                    actionText = actionText.replace(/â¹/g, 'Rs').replace(/¹/g, 'Rs').replace(/â¹/g, 'Rs').replace(/[â¹¹]/g, 'Rs');
                    
                    let rowHeight = 8; // Base height
                    let extraLines = 0;
                    
                    // Calculate height needed for document upload activities
                    if (activity.type === 'document_upload' && actionText.includes(':')) {
                        const parts = actionText.split(': ');
                        // First line for "label:"
                        extraLines += 1;
                        // Lines needed for filename wrapping
                        const filename = parts[1];
                        if (filename.length > 40) {
                            extraLines += 1;
                            if (filename.length > 80) {
                                extraLines += 1;
                                if (filename.length > 120) {
                                    extraLines += 1;
                                }
                            }
                        }
                    } else {
                        // Calculate height needed for standard activities
                        if (actionText.length > 40) {
                            extraLines += 1;
                            if (actionText.length > 80) {
                                extraLines += 1;
                                if (actionText.length > 120) {
                                    extraLines += 1;
                                }
                            }
                        }
                    }
                    
                    rowHeight += extraLines * 6; // 6 units per extra line
                    
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, rowHeight, 'F');
                    }
                    
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers on new page
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Date & Time', 20, y);
                        doc.text('Activity', 60, y);
                        doc.text('Type', 160, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                        
                        // Redraw alternating row colors on new page if needed
                        if (index % 2 === 1) {
                            doc.setFillColor(248, 248, 248);
                            doc.rect(15, y - 6, 180, rowHeight, 'F');
                        }
                    }
                    
                    // Format date and time
                    const activityDateTime = `${activity.date} ${activity.time}`;
                    doc.text(activityDateTime, 20, y);
                    
                    // Track initial y position for proper row height calculation
                    const initialY = y;
                    
                    // Format document upload activities to show on multiple lines if needed
                    if (activity.type === 'document_upload' && actionText.includes(':')) {
                        const parts = actionText.split(': ');
                        doc.text(parts[0] + ':', 60, y);
                        y += 6;
                        // Wrap the filename if it's too long
                        const filename = parts[1];
                        if (filename.length > 40) {
                            doc.text(filename.substring(0, 40), 65, y);
                            y += 6;
                            if (filename.length > 80) {
                                doc.text(filename.substring(40, 80), 65, y);
                                y += 6;
                                if (filename.length > 120) {
                                    doc.text(filename.substring(80, 120) + '...', 65, y);
                                } else {
                                    doc.text(filename.substring(80), 65, y);
                                }
                            } else {
                                doc.text(filename.substring(40), 65, y);
                            }
                        } else {
                            doc.text(filename, 65, y);
                        }
                    } else {
                        // Standard activity formatting
                        doc.text(actionText.substring(0, 40), 60, y);
                        
                        y += 6;
                        
                        // If action text is long, add continuation on next line
                        if (actionText.length > 40) {
                            doc.text(actionText.substring(40, 80), 60, y);
                            y += 6;
                            
                            // If still longer, add more continuation
                            if (actionText.length > 80) {
                                doc.text(actionText.substring(80, 120), 60, y);
                                y += 6;
                            }
                        }
                    }
                    
                    doc.text(activity.type.charAt(0).toUpperCase() + activity.type.slice(1), 160, y);
                    
                    // Ensure proper spacing by moving y position by the calculated row height
                    y += Math.max(0, rowHeight - (y - initialY));
                });
            }
            
            // Documents Section
            if (tenant.documents && tenant.documents.length > 0) {
                y += 30;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Uploaded Documents:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 15;
                
                // Table headers for documents
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Document Name', 20, y);
                doc.text('Type', 100, y);
                doc.text('Upload Date', 140, y);
                doc.text('Size', 170, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                tenant.documents.forEach((docItem, index) => {
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, 8, 'F');
                    }
                    
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers on new page
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Document Name', 20, y);
                        doc.text('Type', 100, y);
                        doc.text('Upload Date', 140, y);
                        doc.text('Size', 170, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                    }
                    
                    // Format file size
                    const fileSize = docItem.size ? (docItem.size / 1024).toFixed(1) + ' KB' : 'N/A';
                    
                    doc.text(docItem.name.substring(0, 25), 20, y);
                    doc.text(docItem.type.substring(0, 15), 100, y);
                    doc.text(new Date(docItem.uploadDate).toLocaleDateString(), 140, y);
                    doc.text(fileSize, 170, y);
                    
                    y += 8;
                    
                    // Embed document image if it's an image type
                    if (docItem.type.startsWith('image/') && docItem.data) {
                        try {
                            // Add a new page for the document
                            doc.addPage();
                            y = 20;
                            
                            doc.setFontSize(14);
                            doc.setFont(undefined, 'bold');
                            doc.setTextColor(...primaryColor);
                            doc.text(`Document: ${docItem.name}`, 20, y);
                            doc.setFont(undefined, 'normal');
                            doc.setTextColor(0, 0, 0);
                            y += 10;
                            
                            // Add document details
                            doc.setFontSize(10);
                            doc.text(`Type: ${docItem.type}`, 20, y);
                            y += 6;
                            doc.text(`Upload Date: ${new Date(docItem.uploadDate).toLocaleDateString()}`, 20, y);
                            y += 10;
                            
                            // Try to embed the image
                            const imgData = docItem.data;
                            const imgProps = doc.getImageProperties(imgData);
                            const pdfWidth = doc.internal.pageSize.getWidth() - 40;
                            const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
                            
                            // Check if image fits on current page
                            if (pdfHeight > (doc.internal.pageSize.getHeight() - y - 20)) {
                                // Scale to fit page
                                const maxHeight = doc.internal.pageSize.getHeight() - y - 20;
                                const maxWidth = doc.internal.pageSize.getWidth() - 40;
                                const ratio = Math.min(maxWidth/imgProps.width, maxHeight/imgProps.height);
                                const width = imgProps.width * ratio;
                                const height = imgProps.height * ratio;
                                doc.addImage(imgData, 20, y, width, height);
                            } else {
                                doc.addImage(imgData, 20, y, pdfWidth, pdfHeight);
                            }
                        } catch (error) {
                            // If image embedding fails, add error note
                            doc.text('Error embedding image: ' + docItem.name, 20, y);
                        }
                    }
                });
            }
            
            doc.save(`tenant-profile-report-${tenant.id}-${new Date().toISOString().split('T')[0]}.pdf`);
        }        // Download deleted history report
        function downloadDeletedHistoryReport() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Get website colors
            const primaryColor = [0, 119, 182]; // #0077b6
            const primaryDarkColor = [2, 62, 138]; // #023e8a
            const secondaryColor = [0, 150, 199]; // #0096c7
            const lightBackgroundColor = [229, 221, 213]; // #E5DDD5
            
            // Header with better formatting
            doc.setFontSize(22);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(...primaryColor);
            doc.text('DELETED TENANTS HISTORY REPORT', 20, 20);
            
            doc.setFontSize(10);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(0, 0, 0);
            doc.text(`Generated on: ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`, 20, 30);
            
            doc.setFontSize(12);
            doc.text(`Total Deleted Tenants: ${deletedTenants.length}`, 20, 40);
            
            let y = 55;
            
            if (deletedTenants.length === 0) {
                doc.setFontSize(12);
                doc.text('No deleted tenants found', 20, y);
                doc.save(`deleted-history-report-${new Date().toISOString().split('T')[0]}.pdf`);
                return;
            }
            
            // Process each deleted tenant
            deletedTenants.forEach((tenant, index) => {
                // Add a new page for each tenant (except the first one)
                if (index > 0) {
                    doc.addPage();
                    y = 20;
                }
                
                // Tenant Information Section
                doc.setFontSize(16);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text(`Tenant: ${tenant.name} (${tenant.id})`, 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 10;
                
                doc.setFillColor(...primaryColor);
                doc.setDrawColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y, 180, 35, 'F');            
                
                doc.setFontSize(12);
                doc.text(`Name: ${tenant.name}`, 20, y + 8);
                doc.text(`ID: ${tenant.id}`, 20, y + 16);
                doc.text(`Room: ${tenant.room}`, 20, y + 24);
                doc.text(`Phone: ${tenant.phone || 'N/A'}`, 20, y + 32);
                
                doc.text(`Monthly Rent: Rs ${tenant.rent.toLocaleString()}`, 120, y + 8);
                doc.text(`Join Date: ${tenant.joinDate}`, 120, y + 16);
                doc.text(`Deleted Date: ${tenant.deletedDate || 'N/A'}`, 120, y + 24);
                if (tenant.securityDeposit) {
                    doc.text(`Security Deposit: Rs ${tenant.securityDeposit.toLocaleString()}`, 120, y + 32);
                }
                
                // Calculate and display due amount
                const dueAmount = calculateDueAmount(tenant);
                if (dueAmount > 0) {
                    doc.text(`Outstanding Due: Rs ${dueAmount.toLocaleString()}`, 20, y + 40);
                }
                
                // Add payment status summary
                const now = new Date();
                const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
                const currentMonthPayment = tenant.payments?.find(p => 
                    p.date.startsWith(currentMonth) && p.type === 'rent'
                );
                const isCurrentMonthPaid = !!currentMonthPayment;
                
                doc.text(`Current Month Status: ${isCurrentMonthPaid ? 'Paid' : 'Unpaid'}`, 120, y + 40);
                if (tenant.reminderCount > 0) {
                    doc.text(`Reminders Sent: ${tenant.reminderCount}/3`, 20, y + 48);
                }
                
                // Add unpaid months information
                const unpaidMonths = getUnpaidMonths(tenant);
                if (unpaidMonths.length > 0) {
                    doc.text(`Unpaid Months: ${unpaidMonths.join(', ')}`, 20, y + 56);
                }
                
                y += 50;
                
                // Payment History Section
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Payment History:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 15;
                
                if (tenant.payments && tenant.payments.length > 0) {
                    // Table headers with better formatting
                    doc.setFontSize(10);
                    doc.setFillColor(...primaryColor);
                    doc.setTextColor(255, 255, 255);
                    doc.rect(15, y - 7, 180, 10, 'F');
                    
                    doc.setFont(undefined, 'bold');
                    doc.text('Date', 20, y);
                    doc.text('Type', 50, y);
                    doc.text('Amount (Rs)', 100, y, null, null, 'right');
                    doc.text('Method', 130, y);
                    doc.text('Notes', 160, y);
                    
                    doc.setFont(undefined, 'normal');
                    doc.setTextColor(0, 0, 0);
                    doc.line(15, y + 3, 195, y + 3);
                    y += 12;
                    
                    // Sort payments by date (newest first)
                    const sortedPayments = [...tenant.payments].sort((a, b) => new Date(b.date) - new Date(a.date));
                    
                    // Table data with better alignment
                    sortedPayments.forEach((payment, index) => {
                        // Alternate row colors
                        if (index % 2 === 1) {
                            doc.setFillColor(248, 248, 248);
                            doc.rect(15, y - 6, 180, 8, 'F');
                        }
                        
                        doc.text(payment.date, 20, y);
                        doc.text(payment.type.charAt(0).toUpperCase() + payment.type.slice(1), 50, y);
                        doc.text(payment.amount.toLocaleString(), 100, y, null, null, 'right');
                        doc.text(payment.method, 130, y);
                        doc.text((payment.notes || '').substring(0, 20), 160, y);
                        
                        y += 8;
                        
                        // Check if we need a new page
                        if (y > 262) {
                            doc.addPage();
                            y = 20;
                            
                            // Repeat headers
                            doc.setFillColor(...primaryColor);
                            doc.setTextColor(255, 255, 255);
                            doc.rect(15, y - 7, 180, 10, 'F');
                            
                            doc.setFont(undefined, 'bold');
                            doc.text('Date', 20, y);
                            doc.text('Type', 50, y);
                            doc.text('Amount (Rs)', 100, y, null, null, 'right');
                            doc.text('Method', 130, y);
                            doc.text('Notes', 160, y);
                            
                            doc.setFont(undefined, 'normal');
                            doc.setTextColor(0, 0, 0);
                            doc.line(15, y + 3, 195, y + 3);
                            y += 12;
                        }
                    });
                    
                    // Summary section
                    y += 15;
                    if (y > 250) {
                        doc.addPage();
                        y = 20;
                    }
                    
                    doc.setFontSize(14);
                    doc.setFont(undefined, 'bold');
                    doc.setTextColor(...primaryColor);
                    doc.text('Payment Summary:', 20, y);
                    doc.setFont(undefined, 'normal');
                    doc.setTextColor(0, 0, 0);
                    y += 10;
                    
                    doc.line(20, y, 195, y);
                    y += 10;
                    
                    const totalPaid = tenant.payments.reduce((sum, p) => sum + p.amount, 0);
                    const rentPayments = tenant.payments.filter(p => p.type === 'rent');
                    const otherPayments = tenant.payments.filter(p => p.type !== 'rent');
                    
                    doc.setFontSize(12);
                    doc.text(`Total Payments Made:`, 20, y);
                    doc.text(`Rs ${totalPaid.toLocaleString()}`, 195, y, null, null, 'right');
                    y += 10;
                    
                    doc.text(`Rent Payments:`, 20, y);
                    doc.text(`${rentPayments.length} (Rs ${rentPayments.reduce((sum, p) => sum + p.amount, 0).toLocaleString()})`, 195, y, null, null, 'right');
                    y += 10;
                    
                    doc.text(`Other Payments:`, 20, y);
                    doc.text(`${otherPayments.length} (Rs ${otherPayments.reduce((sum, p) => sum + p.amount, 0).toLocaleString()})`, 195, y, null, null, 'right');
                    
                } else {
                    doc.setFontSize(12);
                    doc.text('No payment history available', 20, y);
                }
                
                // Other Bills Section
                if (tenant.otherBills && tenant.otherBills.length > 0) {
                    y += 30;
                    if (y > 250) {
                        doc.addPage();
                        y = 20;
                    }
                    
                    doc.setFontSize(14);
                    doc.setFont(undefined, 'bold');
                    doc.setTextColor(...primaryColor);
                    doc.text('Other Bills:', 20, y);
                    doc.setFont(undefined, 'normal');
                    doc.setTextColor(0, 0, 0);
                    y += 15;
                    
                    // Table headers
                    doc.setFontSize(10);
                    doc.setFillColor(...primaryColor);
                    doc.setTextColor(255, 255, 255);
                    doc.rect(15, y - 7, 180, 10, 'F');
                    
                    doc.setFont(undefined, 'bold');
                    doc.text('Type', 20, y);
                    doc.text('Description', 50, y);
                    doc.text('Amount (Rs)', 100, y, null, null, 'right');
                    doc.text('Status', 130, y);
                    doc.text('Due Date', 160, y);
                    
                    doc.setFont(undefined, 'normal');
                    doc.setTextColor(0, 0, 0);
                    doc.line(15, y + 3, 195, y + 3);
                    y += 12;
                    
                    // Table data
                    tenant.otherBills.forEach((bill, index) => {
                        // Alternate row colors
                        if (index % 2 === 1) {
                            doc.setFillColor(248, 248, 248);
                            doc.rect(15, y - 6, 180, 8, 'F');
                        }
                        
                        doc.text(bill.type, 20, y);
                        doc.text(bill.description.substring(0, 20), 50, y);
                        doc.text(bill.amount.toLocaleString(), 100, y, null, null, 'right');
                        doc.text(bill.paid ? 'Paid' : 'Pending', 130, y);
                        doc.text(bill.dueDate || 'N/A', 160, y);
                        
                        y += 8;
                        
                        // Check if we need a new page
                        if (y > 262) {
                            doc.addPage();
                            y = 20;
                            
                            // Repeat headers
                            doc.setFillColor(...primaryColor);
                            doc.setTextColor(255, 255, 255);
                            doc.rect(15, y - 7, 180, 10, 'F');
                            
                            doc.setFont(undefined, 'bold');
                            doc.text('Type', 20, y);
                            doc.text('Description', 50, y);
                            doc.text('Amount (Rs)', 100, y, null, null, 'right');
                            doc.text('Status', 130, y);
                            doc.text('Due Date', 160, y);
                            
                            doc.setFont(undefined, 'normal');
                            doc.setTextColor(0, 0, 0);
                            doc.line(15, y + 3, 195, y + 3);
                            y += 12;
                        }
                    });
                }
                
                // Admin Activity Section
                if (tenant.adminActivity && tenant.adminActivity.length > 0) {
                    y += 30;
                    if (y > 250) {
                        doc.addPage();
                        y = 20;
                    }
                    
                    doc.setFontSize(14);
                    doc.setFont(undefined, 'bold');
                    doc.setTextColor(...primaryColor);
                    doc.text('Admin Activities:', 20, y);
                    doc.setFont(undefined, 'normal');
                    doc.setTextColor(0, 0, 0);
                    y += 15;
                    
                    // Table headers for admin activities
                    doc.setFontSize(10);
                    doc.setFillColor(...primaryColor);
                    doc.setTextColor(255, 255, 255);
                    doc.rect(15, y - 7, 180, 10, 'F');
                    
                    doc.setFont(undefined, 'bold');
                    doc.text('Date & Time', 20, y);
                    doc.text('Activity', 60, y);
                    doc.text('Type', 160, y);
                    
                    doc.setFont(undefined, 'normal');
                    doc.setTextColor(0, 0, 0);
                    doc.line(15, y + 3, 195, y + 3);
                    y += 12;
                    
                    // Sort activities by timestamp (newest first)
                    const sortedActivities = [...tenant.adminActivity].sort((a, b) => 
                        new Date(b.timestamp) - new Date(a.timestamp)
                    );
                    
                    // List admin activities in a table format
                    sortedActivities.forEach((activity, index) => {
                        // Calculate row height based on content
                        let actionText = activity.action;
                        // Remove any accidental duplication in the action text
                        if (actionText.includes('Payment') && actionText.endsWith('Payment')) {
                            actionText = actionText.replace(/ Payment$/, '');
                        }
                        
                        // Fix currency symbol encoding issues
                        actionText = actionText.replace(/â¹/g, 'Rs').replace(/¹/g, 'Rs').replace(/â¹/g, 'Rs').replace(/[â¹¹]/g, 'Rs');
                        
                        let rowHeight = 8; // Base height
                        let extraLines = 0;
                        
                        // Calculate height needed for document upload activities
                        if (activity.type === 'document_upload' && actionText.includes(':')) {
                            const parts = actionText.split(': ');
                            // First line for "label:"
                            extraLines += 1;
                            // Lines needed for filename wrapping
                            const filename = parts[1];
                            if (filename.length > 40) {
                                extraLines += 1;
                                if (filename.length > 80) {
                                    extraLines += 1;
                                    if (filename.length > 120) {
                                        extraLines += 1;
                                    }
                                }
                            }
                        } else {
                            // Calculate height needed for standard activities
                            if (actionText.length > 40) {
                                extraLines += 1;
                                if (actionText.length > 80) {
                                    extraLines += 1;
                                    if (actionText.length > 120) {
                                        extraLines += 1;
                                    }
                                }
                            }
                        }
                        
                        rowHeight += extraLines * 6; // 6 units per extra line
                        
                        // Alternate row colors
                        if (index % 2 === 1) {
                            doc.setFillColor(248, 248, 248);
                            doc.rect(15, y - 6, 180, rowHeight, 'F');
                        }
                        
                        if (y > 262) {
                            doc.addPage();
                            y = 20;
                            
                            // Repeat headers on new page
                            doc.setFillColor(...primaryColor);
                            doc.setTextColor(255, 255, 255);
                            doc.rect(15, y - 7, 180, 10, 'F');
                            
                            doc.setFont(undefined, 'bold');
                            doc.text('Date & Time', 20, y);
                            doc.text('Activity', 60, y);
                            doc.text('Type', 160, y);
                            
                            doc.setFont(undefined, 'normal');
                            doc.setTextColor(0, 0, 0);
                            doc.line(15, y + 3, 195, y + 3);
                            y += 12;
                            
                            // Redraw alternating row colors on new page if needed
                            if (index % 2 === 1) {
                                doc.setFillColor(248, 248, 248);
                                doc.rect(15, y - 6, 180, rowHeight, 'F');
                            }
                        }
                        
                        // Format date and time
                        const activityDateTime = `${activity.date} ${activity.time}`;
                        doc.text(activityDateTime, 20, y);
                        
                        // Format document upload activities to show on multiple lines if needed
                        if (activity.type === 'document_upload' && actionText.includes(':')) {
                            const parts = actionText.split(': ');
                            doc.text(parts[0] + ':', 60, y);
                            y += 6;
                            // Wrap the filename if it's too long
                            const filename = parts[1];
                            if (filename.length > 40) {
                                doc.text(filename.substring(0, 40), 65, y);
                                y += 6;
                                if (filename.length > 80) {
                                    doc.text(filename.substring(40, 80), 65, y);
                                    y += 6;
                                    if (filename.length > 120) {
                                        doc.text(filename.substring(80, 120) + '...', 65, y);
                                    } else {
                                        doc.text(filename.substring(80), 65, y);
                                    }
                                } else {
                                    doc.text(filename.substring(40), 65, y);
                                }
                            } else {
                                doc.text(filename, 65, y);
                            }
                        } else {
                            // Standard activity formatting
                            doc.text(actionText.substring(0, 40), 60, y);
                            
                            y += 8;
                            
                            // If action text is long, add continuation on next line
                            if (actionText.length > 40) {
                                doc.text(actionText.substring(40, 80), 60, y);
                                y += 6;
                                
                                // If still longer, add more continuation
                                if (actionText.length > 80) {
                                    doc.text(actionText.substring(80, 120), 60, y);
                                    y += 6;
                                }
                            }
                        }
                        
                        doc.text(activity.type.charAt(0).toUpperCase() + activity.type.slice(1), 160, y);
                    });
                }
                
                // Documents Section
                if (tenant.documents && tenant.documents.length > 0) {
                    y += 30;
                    if (y > 250) {
                        doc.addPage();
                        y = 20;
                    }
                    
                    doc.setFontSize(14);
                    doc.setFont(undefined, 'bold');
                    doc.setTextColor(...primaryColor);
                    doc.text('Uploaded Documents:', 20, y);
                    doc.setFont(undefined, 'normal');
                    doc.setTextColor(0, 0, 0);
                    y += 15;
                    
                    // Table headers for documents
                    doc.setFontSize(10);
                    doc.setFillColor(...primaryColor);
                    doc.setTextColor(255, 255, 255);
                    doc.rect(15, y - 7, 180, 10, 'F');
                    
                    doc.setFont(undefined, 'bold');
                    doc.text('Document Name', 20, y);
                    doc.text('Type', 100, y);
                    doc.text('Upload Date', 140, y);
                    doc.text('Size', 170, y);
                    
                    doc.setFont(undefined, 'normal');
                    doc.setTextColor(0, 0, 0);
                    doc.line(15, y + 3, 195, y + 3);
                    y += 12;
                    
                    tenant.documents.forEach((docItem, index) => {
                        // Alternate row colors
                        if (index % 2 === 1) {
                            doc.setFillColor(248, 248, 248);
                            doc.rect(15, y - 6, 180, 8, 'F');
                        }
                        
                        if (y > 262) {
                            doc.addPage();
                            y = 20;
                            
                            // Repeat headers on new page
                            doc.setFillColor(...primaryColor);
                            doc.setTextColor(255, 255, 255);
                            doc.rect(15, y - 7, 180, 10, 'F');
                            
                            doc.setFont(undefined, 'bold');
                            doc.text('Document Name', 20, y);
                            doc.text('Type', 100, y);
                            doc.text('Upload Date', 140, y);
                            doc.text('Size', 170, y);
                            
                            doc.setFont(undefined, 'normal');
                            doc.setTextColor(0, 0, 0);
                            doc.line(15, y + 3, 195, y + 3);
                            y += 12;
                        }
                        
                        // Format file size
                        const fileSize = docItem.size ? (docItem.size / 1024).toFixed(1) + ' KB' : 'N/A';
                        
                        doc.text(docItem.name.substring(0, 25), 20, y);
                        doc.text(docItem.type.substring(0, 15), 100, y);
                        doc.text(new Date(docItem.uploadDate).toLocaleDateString(), 140, y);
                        doc.text(fileSize, 170, y);
                        
                        y += 8;
                        
                        // Embed document image if it's an image type
                        if (docItem.type.startsWith('image/') && docItem.data) {
                            try {
                                // Add a new page for the document
                                doc.addPage();
                                y = 20;
                                
                                doc.setFontSize(14);
                                doc.setFont(undefined, 'bold');
                                doc.setTextColor(...primaryColor);
                                doc.text(`Document: ${docItem.name}`, 20, y);
                                doc.setFont(undefined, 'normal');
                                doc.setTextColor(0, 0, 0);
                                y += 10;
                                
                                // Add document details
                                doc.setFontSize(10);
                                doc.text(`Type: ${docItem.type}`, 20, y);
                                y += 6;
                                doc.text(`Upload Date: ${new Date(docItem.uploadDate).toLocaleDateString()}`, 20, y);
                                y += 10;
                                
                                // Try to embed the image
                                const imgData = docItem.data;
                                const imgProps = doc.getImageProperties(imgData);
                                const pdfWidth = doc.internal.pageSize.getWidth() - 40;
                                const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
                                
                                // Check if image fits on current page
                                if (pdfHeight > (doc.internal.pageSize.getHeight() - y - 20)) {
                                    // Scale to fit page
                                    const maxHeight = doc.internal.pageSize.getHeight() - y - 20;
                                    const maxWidth = doc.internal.pageSize.getWidth() - 40;
                                    const ratio = Math.min(maxWidth/imgProps.width, maxHeight/imgProps.height);
                                    const width = imgProps.width * ratio;
                                    const height = imgProps.height * ratio;
                                    doc.addImage(imgData, 20, y, width, height);
                                } else {
                                    doc.addImage(imgData, 20, y, pdfWidth, pdfHeight);
                                }
                            } catch (error) {
                                // If image embedding fails, add error note
                                doc.text('Error embedding image: ' + docItem.name, 20, y);
                            }
                        }
                    });
                }
            });
            
            doc.save(`deleted-history-report-${new Date().toISOString().split('T')[0]}.pdf`);
        }        // Download individual deleted tenant report
        function downloadDeletedTenantReport(tenantId) {
            const tenant = deletedTenants.find(t => t.id === tenantId);
            if (!tenant) {
                customAlert('Tenant not found.', 'Error');
                return;
            }
            
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Get website colors
            const primaryColor = [0, 119, 182]; // #0077b6
            const primaryDarkColor = [2, 62, 138]; // #023e8a
            const secondaryColor = [0, 150, 199]; // #0096c7
            const lightBackgroundColor = [229, 221, 213]; // #E5DDD5
            
            // Header with better formatting
            doc.setFontSize(22);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(...primaryColor);
            doc.text('DELETED TENANT REPORT', 20, 20);
            
            doc.setFontSize(10);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(0, 0, 0);
            doc.text(`Generated on: ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`, 20, 30);
            
            // Tenant Information Section
            let y = 45;
            doc.setFontSize(16);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(...primaryColor);
            doc.text('Tenant Information', 20, y);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(0, 0, 0);
            y += 10;
            
            doc.setFillColor(...primaryColor);
            doc.setDrawColor(...primaryColor);
            doc.setTextColor(255, 255, 255);
            doc.rect(15, y, 180, 35, 'F');
            
            doc.setFontSize(12);
            doc.text(`Name: ${tenant.name}`, 20, y + 8);
            doc.text(`ID: ${tenant.id}`, 20, y + 16);
            doc.text(`Room: ${tenant.room}`, 20, y + 24);
            doc.text(`Phone: ${tenant.phone || 'N/A'}`, 20, y + 32);
            
            doc.text(`Monthly Rent: Rs ${tenant.rent.toLocaleString()}`, 120, y + 8);
            doc.text(`Join Date: ${tenant.joinDate}`, 120, y + 16);
            doc.text(`Deleted Date: ${tenant.deletedDate || 'N/A'}`, 120, y + 24);
            if (tenant.securityDeposit) {
                doc.text(`Security Deposit: Rs ${tenant.securityDeposit.toLocaleString()}`, 120, y + 32);
            }
            
            // Calculate and display due amount
            const dueAmount = calculateDueAmount(tenant);
            if (dueAmount > 0) {
                doc.text(`Outstanding Due: Rs ${dueAmount.toLocaleString()}`, 20, y + 40);
            }
            
            // Add payment status summary
            const now = new Date();
            const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
            const currentMonthPayment = tenant.payments?.find(p => 
                p.date.startsWith(currentMonth) && p.type === 'rent'
            );
            const isCurrentMonthPaid = !!currentMonthPayment;
            
            doc.text(`Current Month Status: ${isCurrentMonthPaid ? 'Paid' : 'Unpaid'}`, 120, y + 40);
            if (tenant.reminderCount > 0) {
                doc.text(`Reminders Sent: ${tenant.reminderCount}/3`, 20, y + 48);
            }
            
            // Add unpaid months information
            const unpaidMonths = getUnpaidMonths(tenant);
            if (unpaidMonths.length > 0) {
                doc.text(`Unpaid Months: ${unpaidMonths.join(', ')}`, 20, y + 56);
            }
            
            y += 50;
            
            // Payment History Section
            doc.setFontSize(14);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(...primaryColor);
            doc.text('Payment History:', 20, y);
            doc.setFont(undefined, 'normal');
            doc.setTextColor(0, 0, 0);
            y += 15;
            
            if (tenant.payments && tenant.payments.length > 0) {
                // Table headers with better formatting
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Date', 20, y);
                doc.text('Type', 50, y);
                doc.text('Amount (Rs)', 100, y, null, null, 'right');
                doc.text('Method', 130, y);
                doc.text('Notes', 160, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                // Sort payments by date (newest first)
                const sortedPayments = [...tenant.payments].sort((a, b) => new Date(b.date) - new Date(a.date));
                
                // Table data with better alignment
                sortedPayments.forEach((payment, index) => {
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, 8, 'F');
                    }
                    
                    doc.text(payment.date, 20, y);
                    doc.text(payment.type.charAt(0).toUpperCase() + payment.type.slice(1), 50, y);
                    doc.text(payment.amount.toLocaleString(), 100, y, null, null, 'right');
                    doc.text(payment.method, 130, y);
                    doc.text((payment.notes || '').substring(0, 20), 160, y);
                    
                    y += 8;
                    
                    // Check if we need a new page
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Date', 20, y);
                        doc.text('Type', 50, y);
                        doc.text('Amount (Rs)', 100, y, null, null, 'right');
                        doc.text('Method', 130, y);
                        doc.text('Notes', 160, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                    }
                });
                
                // Summary section
                y += 15;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Payment Summary:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 10;
                
                doc.line(20, y, 195, y);
                y += 10;
                
                const totalPaid = tenant.payments.reduce((sum, p) => sum + p.amount, 0);
                const rentPayments = tenant.payments.filter(p => p.type === 'rent');
                const otherPayments = tenant.payments.filter(p => p.type !== 'rent');
                
                doc.setFontSize(12);
                doc.text(`Total Payments Made:`, 20, y);
                doc.text(`Rs ${totalPaid.toLocaleString()}`, 195, y, null, null, 'right');
                y += 10;
                
                doc.text(`Rent Payments:`, 20, y);
                doc.text(`${rentPayments.length} (Rs ${rentPayments.reduce((sum, p) => sum + p.amount, 0).toLocaleString()})`, 195, y, null, null, 'right');
                y += 10;
                
                doc.text(`Other Payments:`, 20, y);
                doc.text(`${otherPayments.length} (Rs ${otherPayments.reduce((sum, p) => sum + p.amount, 0).toLocaleString()})`, 195, y, null, null, 'right');
                
            } else {
                doc.setFontSize(12);
                doc.text('No payment history available', 20, y);
            }
            
            // Other Bills Section
            if (tenant.otherBills && tenant.otherBills.length > 0) {
                y += 30;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Other Bills:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 15;
                
                // Table headers
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Type', 20, y);
                doc.text('Description', 50, y);
                doc.text('Amount (Rs)', 100, y, null, null, 'right');
                doc.text('Status', 130, y);
                doc.text('Due Date', 160, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                // Table data
                tenant.otherBills.forEach((bill, index) => {
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, 8, 'F');
                    }
                    
                    doc.text(bill.type, 20, y);
                    doc.text(bill.description.substring(0, 20), 50, y);
                    doc.text(bill.amount.toLocaleString(), 100, y, null, null, 'right');
                    doc.text(bill.paid ? 'Paid' : 'Pending', 130, y);
                    doc.text(bill.dueDate || 'N/A', 160, y);
                    
                    y += 8;
                    
                    // Check if we need a new page
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Type', 20, y);
                        doc.text('Description', 50, y);
                        doc.text('Amount (Rs)', 100, y, null, null, 'right');
                        doc.text('Status', 130, y);
                        doc.text('Due Date', 160, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                    }
                });
            }
            
            // Admin Activity Section
            if (tenant.adminActivity && tenant.adminActivity.length > 0) {
                y += 30;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Admin Activities:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 15;
                
                // Table headers for admin activities
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Date & Time', 20, y);
                doc.text('Activity', 60, y);
                doc.text('Type', 160, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                // Sort activities by timestamp (newest first)
                const sortedActivities = [...tenant.adminActivity].sort((a, b) => 
                    new Date(b.timestamp) - new Date(a.timestamp)
                );
                
                // List admin activities in a table format
                sortedActivities.forEach((activity, index) => {
                    // Calculate row height based on content
                    let actionText = activity.action;
                    // Remove any accidental duplication in the action text
                    if (actionText.includes('Payment') && actionText.endsWith('Payment')) {
                        actionText = actionText.replace(/ Payment$/, '');
                    }
                    
                    // Fix currency symbol encoding issues
                    actionText = actionText.replace(/â¹/g, 'Rs').replace(/¹/g, 'Rs').replace(/â¹/g, 'Rs').replace(/[â¹¹]/g, 'Rs');
                    
                    let rowHeight = 8; // Base height
                    let extraLines = 0;
                    
                    // Calculate height needed for document upload activities
                    if (activity.type === 'document_upload' && actionText.includes(':')) {
                        const parts = actionText.split(': ');
                        // First line for "label:"
                        extraLines += 1;
                        // Lines needed for filename wrapping
                        const filename = parts[1];
                        if (filename.length > 40) {
                            extraLines += 1;
                            if (filename.length > 80) {
                                extraLines += 1;
                                if (filename.length > 120) {
                                    extraLines += 1;
                                }
                            }
                        }
                    } else {
                        // Calculate height needed for standard activities
                        if (actionText.length > 40) {
                            extraLines += 1;
                            if (actionText.length > 80) {
                                extraLines += 1;
                                if (actionText.length > 120) {
                                    extraLines += 1;
                                }
                            }
                        }
                    }
                    
                    rowHeight += extraLines * 6; // 6 units per extra line
                    
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, rowHeight, 'F');
                    }
                    
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers on new page
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Date & Time', 20, y);
                        doc.text('Activity', 60, y);
                        doc.text('Type', 160, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                        
                        // Redraw alternating row colors on new page if needed
                        if (index % 2 === 1) {
                            doc.setFillColor(248, 248, 248);
                            doc.rect(15, y - 6, 180, rowHeight, 'F');
                        }
                    }
                    
                    // Format date and time
                    const activityDateTime = `${activity.date} ${activity.time}`;
                    doc.text(activityDateTime, 20, y);
                    
                    // Track initial y position for proper row height calculation
                    const initialY = y;
                    
                    // Format document upload activities to show on multiple lines if needed
                    if (activity.type === 'document_upload' && actionText.includes(':')) {
                        const parts = actionText.split(': ');
                        doc.text(parts[0] + ':', 60, y);
                        y += 6;
                        // Wrap the filename if it's too long
                        const filename = parts[1];
                        if (filename.length > 40) {
                            doc.text(filename.substring(0, 40), 65, y);
                            y += 6;
                            if (filename.length > 80) {
                                doc.text(filename.substring(40, 80), 65, y);
                                y += 6;
                                if (filename.length > 120) {
                                    doc.text(filename.substring(80, 120) + '...', 65, y);
                                } else {
                                    doc.text(filename.substring(80), 65, y);
                                }
                            } else {
                                doc.text(filename.substring(40), 65, y);
                            }
                        } else {
                            doc.text(filename, 65, y);
                        }
                    } else {
                        // Standard activity formatting
                        doc.text(actionText.substring(0, 40), 60, y);
                        
                        y += 6;
                        
                        // If action text is long, add continuation on next line
                        if (actionText.length > 40) {
                            doc.text(actionText.substring(40, 80), 60, y);
                            y += 6;
                            
                            // If still longer, add more continuation
                            if (actionText.length > 80) {
                                doc.text(actionText.substring(80, 120), 60, y);
                                y += 6;
                            }
                        }
                    }
                    
                    doc.text(activity.type.charAt(0).toUpperCase() + activity.type.slice(1), 160, y);
                    
                    // Ensure proper spacing by moving y position by the calculated row height
                    y += Math.max(0, rowHeight - (y - initialY));
                });
            }
            
            // Documents Section
            if (tenant.documents && tenant.documents.length > 0) {
                y += 30;
                if (y > 250) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(...primaryColor);
                doc.text('Uploaded Documents:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                y += 15;
                
                // Table headers for documents
                doc.setFontSize(10);
                doc.setFillColor(...primaryColor);
                doc.setTextColor(255, 255, 255);
                doc.rect(15, y - 7, 180, 10, 'F');
                
                doc.setFont(undefined, 'bold');
                doc.text('Document Name', 20, y);
                doc.text('Type', 100, y);
                doc.text('Upload Date', 140, y);
                doc.text('Size', 170, y);
                
                doc.setFont(undefined, 'normal');
                doc.setTextColor(0, 0, 0);
                doc.line(15, y + 3, 195, y + 3);
                y += 12;
                
                tenant.documents.forEach((docItem, index) => {
                    // Alternate row colors
                    if (index % 2 === 1) {
                        doc.setFillColor(248, 248, 248);
                        doc.rect(15, y - 6, 180, 8, 'F');
                    }
                    
                    if (y > 262) {
                        doc.addPage();
                        y = 20;
                        
                        // Repeat headers on new page
                        doc.setFillColor(...primaryColor);
                        doc.setTextColor(255, 255, 255);
                        doc.rect(15, y - 7, 180, 10, 'F');
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Document Name', 20, y);
                        doc.text('Type', 100, y);
                        doc.text('Upload Date', 140, y);
                        doc.text('Size', 170, y);
                        
                        doc.setFont(undefined, 'normal');
                        doc.setTextColor(0, 0, 0);
                        doc.line(15, y + 3, 195, y + 3);
                        y += 12;
                    }
                    
                    // Format file size
                    const fileSize = docItem.size ? (docItem.size / 1024).toFixed(1) + ' KB' : 'N/A';
                    
                    doc.text(docItem.name.substring(0, 25), 20, y);
                    doc.text(docItem.type.substring(0, 15), 100, y);
                    doc.text(new Date(docItem.uploadDate).toLocaleDateString(), 140, y);
                    doc.text(fileSize, 170, y);
                    
                    y += 8;
                    
                    // Embed document image if it's an image type
                    if (docItem.type.startsWith('image/') && docItem.data) {
                        try {
                            // Add a new page for the document
                            doc.addPage();
                            y = 20;
                            
                            doc.setFontSize(14);
                            doc.setFont(undefined, 'bold');
                            doc.setTextColor(...primaryColor);
                            doc.text(`Document: ${docItem.name}`, 20, y);
                            doc.setFont(undefined, 'normal');
                            doc.setTextColor(0, 0, 0);
                            y += 10;
                            
                            // Add document details
                            doc.setFontSize(10);
                            doc.text(`Type: ${docItem.type}`, 20, y);
                            y += 6;
                            doc.text(`Upload Date: ${new Date(docItem.uploadDate).toLocaleDateString()}`, 20, y);
                            y += 10;
                            
                            // Try to embed the image
                            const imgData = docItem.data;
                            const imgProps = doc.getImageProperties(imgData);
                            const pdfWidth = doc.internal.pageSize.getWidth() - 40;
                            const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
                            
                            // Check if image fits on current page
                            if (pdfHeight > (doc.internal.pageSize.getHeight() - y - 20)) {
                                // Scale to fit page
                                const maxHeight = doc.internal.pageSize.getHeight() - y - 20;
                                const maxWidth = doc.internal.pageSize.getWidth() - 40;
                                const ratio = Math.min(maxWidth/imgProps.width, maxHeight/imgProps.height);
                                const width = imgProps.width * ratio;
                                const height = imgProps.height * ratio;
                                doc.addImage(imgData, 20, y, width, height);
                            } else {
                                doc.addImage(imgData, 20, y, pdfWidth, pdfHeight);
                            }
                        } catch (error) {
                            // If image embedding fails, add error note
                            doc.text('Error embedding image: ' + docItem.name, 20, y);
                        }
                    }
                });
            }
            
            doc.save(`deleted-tenant-${tenant.id}-report-${new Date().toISOString().split('T')[0]}.pdf`);
        }
        // Initialize the application
        // Event listener for add tenant form is already attached elsewhere
        
        // Add event listener for tenant search
        const searchInput = document.getElementById('searchTenant');
        if (searchInput) {
            searchInput.addEventListener('input', function(e) {
                loadTenants(e.target.value);
            });
        }
