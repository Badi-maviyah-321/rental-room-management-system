const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Database connection
const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
};

const pool = mysql.createPool(dbConfig);

// Test database connection
async function testConnection() {
    try {
        const connection = await pool.getConnection();
        console.log('Database connected successfully');
        connection.release();
    } catch (error) {
        console.error('Database connection failed:', error);
    }
}

testConnection();

// Auth middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.sendStatus(401);
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Routes

// Login
app.post('/api/login', async (req, res) => {
    try {
        const { userType, username, password, tenantId } = req.body;

        if (userType === 'admin') {
            if (username === 'admin' && password === 'admin123') {
                const token = jwt.sign({ type: 'admin', username: 'admin' }, process.env.JWT_SECRET);
                res.json({ success: true, token, user: { type: 'admin', username: 'admin' } });
            } else {
                res.status(401).json({ success: false, message: 'Invalid admin credentials' });
            }
        } else {
            const [rows] = await pool.execute('SELECT * FROM tenants WHERE id = ? AND deleted_date IS NULL', [tenantId]);
            if (rows.length > 0) {
                const tenant = rows[0];
                const token = jwt.sign({ type: 'tenant', data: tenant }, process.env.JWT_SECRET);
                res.json({ success: true, token, user: { type: 'tenant', data: tenant } });
            } else {
                res.status(401).json({ success: false, message: 'Invalid tenant ID' });
            }
        }
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Get all tenants
app.get('/api/tenants', authenticateToken, async (req, res) => {
    try {
        const [tenants] = await pool.execute('SELECT * FROM tenants WHERE deleted_date IS NULL ORDER BY created_at DESC');
        
        for (let tenant of tenants) {
            // Get payments
            const [payments] = await pool.execute('SELECT * FROM payments WHERE tenant_id = ? ORDER BY date DESC', [tenant.id]);
            tenant.payments = payments;

            // Get other bills
            const [bills] = await pool.execute('SELECT * FROM other_bills WHERE tenant_id = ? ORDER BY created_date DESC', [tenant.id]);
            tenant.otherBills = bills;

            // Get documents
            const [documents] = await pool.execute('SELECT * FROM documents WHERE tenant_id = ? ORDER BY upload_date DESC', [tenant.id]);
            tenant.documents = documents;

            // Get admin activities
            const [activities] = await pool.execute('SELECT * FROM admin_activities WHERE tenant_id = ? ORDER BY timestamp DESC', [tenant.id]);
            tenant.adminActivity = activities;

            // Get notifications
            const [notifications] = await pool.execute('SELECT * FROM notifications WHERE tenant_id = ? ORDER BY date DESC, time DESC', [tenant.id]);
            tenant.notifications = notifications;

            // Get reminder history
            const [reminders] = await pool.execute('SELECT * FROM reminder_history WHERE tenant_id = ? ORDER BY sent_date DESC', [tenant.id]);
            tenant.reminderHistory = reminders;
        }

        res.json(tenants);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch tenants' });
    }
});

// Get single tenant
app.get('/api/tenants/:id', authenticateToken, async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM tenants WHERE id = ? AND deleted_date IS NULL', [req.params.id]);
        
        if (rows.length === 0) {
            return res.status(404).json({ error: 'Tenant not found' });
        }

        const tenant = rows[0];

        // Get all related data
        const [payments] = await pool.execute('SELECT * FROM payments WHERE tenant_id = ? ORDER BY date DESC', [tenant.id]);
        const [bills] = await pool.execute('SELECT * FROM other_bills WHERE tenant_id = ? ORDER BY created_date DESC', [tenant.id]);
        const [documents] = await pool.execute('SELECT * FROM documents WHERE tenant_id = ? ORDER BY upload_date DESC', [tenant.id]);
        const [activities] = await pool.execute('SELECT * FROM admin_activities WHERE tenant_id = ? ORDER BY timestamp DESC', [tenant.id]);
        const [notifications] = await pool.execute('SELECT * FROM notifications WHERE tenant_id = ? ORDER BY date DESC, time DESC', [tenant.id]);
        const [reminders] = await pool.execute('SELECT * FROM reminder_history WHERE tenant_id = ? ORDER BY sent_date DESC', [tenant.id]);

        tenant.payments = payments;
        tenant.otherBills = bills;
        tenant.documents = documents;
        tenant.adminActivity = activities;
        tenant.notifications = notifications;
        tenant.reminderHistory = reminders;

        res.json(tenant);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch tenant' });
    }
});

// Add new tenant
app.post('/api/tenants', authenticateToken, async (req, res) => {
    try {
        const { id, name, room, rent, securityDeposit, phone, joinDate } = req.body;
        
        await pool.execute(
            'INSERT INTO tenants (id, name, room, rent, security_deposit, phone, join_date) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [id, name, room, rent, securityDeposit || 0, phone, joinDate]
        );

        res.json({ success: true, message: 'Tenant added successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to add tenant' });
    }
});

// Update tenant
app.put('/api/tenants/:id', authenticateToken, async (req, res) => {
    try {
        const { name, room, rent, securityDeposit, phone } = req.body;
        
        await pool.execute(
            'UPDATE tenants SET name = ?, room = ?, rent = ?, security_deposit = ?, phone = ? WHERE id = ?',
            [name, room, rent, securityDeposit || 0, phone, req.params.id]
        );

        res.json({ success: true, message: 'Tenant updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update tenant' });
    }
});

// Delete tenant (soft delete)
app.delete('/api/tenants/:id', authenticateToken, async (req, res) => {
    try {
        const connection = await pool.getConnection();
        await connection.beginTransaction();

        try {
            // Get tenant data
            const [tenantRows] = await connection.execute('SELECT * FROM tenants WHERE id = ?', [req.params.id]);
            if (tenantRows.length === 0) {
                await connection.rollback();
                return res.status(404).json({ error: 'Tenant not found' });
            }

            const tenant = tenantRows[0];
            
            // Get all related data
            const [payments] = await connection.execute('SELECT * FROM payments WHERE tenant_id = ?', [req.params.id]);
            const [bills] = await connection.execute('SELECT * FROM other_bills WHERE tenant_id = ?', [req.params.id]);
            const [documents] = await connection.execute('SELECT * FROM documents WHERE tenant_id = ?', [req.params.id]);
            const [activities] = await connection.execute('SELECT * FROM admin_activities WHERE tenant_id = ?', [req.params.id]);
            const [notifications] = await connection.execute('SELECT * FROM notifications WHERE tenant_id = ?', [req.params.id]);
            const [reminders] = await connection.execute('SELECT * FROM reminder_history WHERE tenant_id = ?', [req.params.id]);

            // Create backup in deleted_tenants
            const tenantData = {
                ...tenant,
                payments,
                otherBills: bills,
                documents,
                adminActivity: activities,
                notifications,
                reminderHistory: reminders
            };

            await connection.execute(
                'INSERT INTO deleted_tenants (id, name, room, rent, security_deposit, phone, join_date, deleted_date, tenant_data) VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE(), ?)',
                [tenant.id, tenant.name, tenant.room, tenant.rent, tenant.security_deposit, tenant.phone, tenant.join_date, JSON.stringify(tenantData)]
            );

            // Soft delete tenant
            await connection.execute('UPDATE tenants SET deleted_date = CURDATE() WHERE id = ?', [req.params.id]);

            await connection.commit();
            res.json({ success: true, message: 'Tenant deleted successfully' });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete tenant' });
    }
});

// Add payment
app.post('/api/tenants/:id/payments', authenticateToken, async (req, res) => {
    try {
        const { id, type, amount, method, notes, date } = req.body;
        
        await pool.execute(
            'INSERT INTO payments (id, tenant_id, type, amount, method, notes, date) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [id, req.params.id, type, amount, method, notes, date]
        );

        res.json({ success: true, message: 'Payment added successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to add payment' });
    }
});

// Add other bill
app.post('/api/tenants/:id/bills', authenticateToken, async (req, res) => {
    try {
        const { id, type, amount, description, dueDate, createdDate } = req.body;
        
        await pool.execute(
            'INSERT INTO other_bills (id, tenant_id, type, amount, description, due_date, created_date) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [id, req.params.id, type, amount, description, dueDate, createdDate]
        );

        res.json({ success: true, message: 'Bill added successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to add bill' });
    }
});

// Update bill status
app.put('/api/bills/:id', authenticateToken, async (req, res) => {
    try {
        const { paid, paidDate } = req.body;
        
        await pool.execute(
            'UPDATE other_bills SET paid = ?, paid_date = ? WHERE id = ?',
            [paid, paidDate, req.params.id]
        );

        res.json({ success: true, message: 'Bill updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update bill' });
    }
});

// Delete bill
app.delete('/api/bills/:id', authenticateToken, async (req, res) => {
    try {
        await pool.execute('DELETE FROM other_bills WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'Bill deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete bill' });
    }
});

// Add document
app.post('/api/tenants/:id/documents', authenticateToken, async (req, res) => {
    try {
        const { id, name, type, size, data } = req.body;
        
        await pool.execute(
            'INSERT INTO documents (id, tenant_id, name, type, size, data) VALUES (?, ?, ?, ?, ?, ?)',
            [id, req.params.id, name, type, size, data]
        );

        res.json({ success: true, message: 'Document uploaded successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to upload document' });
    }
});

// Delete document
app.delete('/api/documents/:id', authenticateToken, async (req, res) => {
    try {
        await pool.execute('DELETE FROM documents WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'Document deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete document' });
    }
});

// Add admin activity
app.post('/api/tenants/:id/activities', authenticateToken, async (req, res) => {
    try {
        const { id, action, type, admin, date, time } = req.body;
        
        await pool.execute(
            'INSERT INTO admin_activities (id, tenant_id, action, type, admin, date, time) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [id, req.params.id, action, type, admin, date, time]
        );

        res.json({ success: true, message: 'Activity logged successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to log activity' });
    }
});

// Add notification
app.post('/api/tenants/:id/notifications', authenticateToken, async (req, res) => {
    try {
        const { id, message, date, time } = req.body;
        
        await pool.execute(
            'INSERT INTO notifications (id, tenant_id, message, date, time) VALUES (?, ?, ?, ?, ?)',
            [id, req.params.id, message, date, time]
        );

        res.json({ success: true, message: 'Notification added successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to add notification' });
    }
});

// Update reminder count
app.put('/api/tenants/:id/reminder-count', authenticateToken, async (req, res) => {
    try {
        const { reminderCount } = req.body;
        
        await pool.execute(
            'UPDATE tenants SET reminder_count = ? WHERE id = ?',
            [reminderCount, req.params.id]
        );

        res.json({ success: true, message: 'Reminder count updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update reminder count' });
    }
});

// Add reminder history
app.post('/api/tenants/:id/reminders', authenticateToken, async (req, res) => {
    try {
        const { id, type, message, amount, sentDate, sentTime, phone } = req.body;
        
        await pool.execute(
            'INSERT INTO reminder_history (id, tenant_id, type, message, amount, sent_date, sent_time, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [id, req.params.id, type, message, amount, sentDate, sentTime, phone]
        );

        res.json({ success: true, message: 'Reminder history added successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to add reminder history' });
    }
});

// Get deleted tenants
app.get('/api/deleted-tenants', authenticateToken, async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM deleted_tenants ORDER BY deleted_date DESC');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch deleted tenants' });
    }
});

// Restore tenant
app.post('/api/deleted-tenants/:id/restore', authenticateToken, async (req, res) => {
    try {
        const connection = await pool.getConnection();
        await connection.beginTransaction();

        try {
            // Get deleted tenant data
            const [deletedRows] = await connection.execute('SELECT * FROM deleted_tenants WHERE id = ?', [req.params.id]);
            if (deletedRows.length === 0) {
                await connection.rollback();
                return res.status(404).json({ error: 'Deleted tenant not found' });
            }

            const deletedTenant = deletedRows[0];
            const tenantData = JSON.parse(deletedTenant.tenant_data);

            // Restore tenant
            await connection.execute(
                'UPDATE tenants SET deleted_date = NULL WHERE id = ?',
                [req.params.id]
            );

            // Remove from deleted_tenants
            await connection.execute('DELETE FROM deleted_tenants WHERE id = ?', [req.params.id]);

            await connection.commit();
            res.json({ success: true, message: 'Tenant restored successfully' });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        res.status(500).json({ error: 'Failed to restore tenant' });
    }
});

// Permanently delete tenant
app.delete('/api/deleted-tenants/:id', authenticateToken, async (req, res) => {
    try {
        await pool.execute('DELETE FROM deleted_tenants WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'Tenant permanently deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to permanently delete tenant' });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});