-- Create database
CREATE DATABASE IF NOT EXISTS rental_management;
USE rental_management;

-- Tenants table
CREATE TABLE tenants (
    id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    room VARCHAR(20) NOT NULL,
    rent INT NOT NULL,
    security_deposit INT DEFAULT 0,
    phone VARCHAR(15),
    join_date DATE NOT NULL,
    reminder_count INT DEFAULT 0,
    deleted_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Payments table
CREATE TABLE payments (
    id BIGINT PRIMARY KEY,
    tenant_id VARCHAR(20) NOT NULL,
    type VARCHAR(50) NOT NULL,
    amount INT NOT NULL,
    method VARCHAR(50) NOT NULL,
    notes TEXT,
    date DATE NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

-- Other bills table
CREATE TABLE other_bills (
    id BIGINT PRIMARY KEY,
    tenant_id VARCHAR(20) NOT NULL,
    type VARCHAR(50) NOT NULL,
    amount INT NOT NULL,
    description TEXT NOT NULL,
    due_date DATE,
    paid BOOLEAN DEFAULT FALSE,
    paid_date DATE NULL,
    created_date DATE NOT NULL,
    FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

-- Documents table
CREATE TABLE documents (
    id VARCHAR(50) PRIMARY KEY,
    tenant_id VARCHAR(20) NOT NULL,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    size INT NOT NULL,
    data LONGTEXT NOT NULL,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

-- Admin activities table
CREATE TABLE admin_activities (
    id BIGINT PRIMARY KEY,
    tenant_id VARCHAR(20) NOT NULL,
    action TEXT NOT NULL,
    type VARCHAR(50) NOT NULL,
    admin VARCHAR(50) DEFAULT 'admin',
    date DATE NOT NULL,
    time TIME NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

-- Notifications table
CREATE TABLE notifications (
    id BIGINT PRIMARY KEY,
    tenant_id VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    read_status BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

-- Reminder history table
CREATE TABLE reminder_history (
    id BIGINT PRIMARY KEY,
    tenant_id VARCHAR(20) NOT NULL,
    type VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    amount INT NOT NULL,
    sent_date DATE NOT NULL,
    sent_time TIME NOT NULL,
    phone VARCHAR(15) NOT NULL,
    FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

-- Deleted tenants table (for backup)
CREATE TABLE deleted_tenants (
    id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    room VARCHAR(20) NOT NULL,
    rent INT NOT NULL,
    security_deposit INT DEFAULT 0,
    phone VARCHAR(15),
    join_date DATE NOT NULL,
    deleted_date DATE NOT NULL,
    tenant_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);