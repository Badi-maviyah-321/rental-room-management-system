# Script to fix rent.html by removing duplicate script block

# Read the file
with open('rent.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Find the duplicate script block by looking for the specific pattern
# The duplicate block starts with "// Tenant Management Functions"
if '// Tenant Management Functions' in content:
    # Find the position of the duplicate block
    duplicate_start = content.find('// Tenant Management Functions')
    if duplicate_start > 0:
        # Find the end of the duplicate block (</script> tag)
        duplicate_end = content.find('</script>', duplicate_start)
        if duplicate_end > 0:
            # Include the closing tag
            duplicate_end += len('</script>')
            
            # Keep content before the duplicate block and after it
            new_content = content[:duplicate_start-1] + content[duplicate_end:]
            
            # Write the fixed content back to the file
            with open('rent.html', 'w', encoding='utf-8') as f:
                f.write(new_content)
            
            print("Duplicate script block removed successfully!")
        else:
            print("Could not find end of duplicate block.")
    else:
        print("Could not find start of duplicate block.")
else:
    print("No duplicate script block found.")